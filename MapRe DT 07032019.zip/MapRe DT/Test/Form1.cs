﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using DLLMapRe.Entidades;
using DLLMapRe.Entidades.EnvioRegistro;
using DLLMapRe.LogicaNegocio;
using System.IO;
using DLLMapRe.Entidades.Respuesta;
using DLLMapRe.LogicaProceso;

namespace Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviarArchivo_Click(object sender, EventArgs e)
        {
            //if (File.Exists(string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\Agentes_Aduana", @"\demo.zip")))
            //{
            //    File.Delete(string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\Agentes_Aduana", @"\demo.zip"));
            //}

            ////Copiamos el archivo de Envio a la Carpeta de Envios
            //File.Copy(string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\ArchivosPrueba", @"\demo.zip"),
            //                    string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\Agentes_Aduana", @"\demo.zip"), true);

            var requestEnvio = new ParametroEnvioMapRe();
            requestEnvio.Directorio = @"C:\TCI\STACE_GENERAMENSAJES\Agentes_Aduana";
            requestEnvio.DirectorioError = @"C:\TCI\STACE_GENERAMENSAJES\Agentes_Aduana_No_Procesados";
            requestEnvio.DirectorioProcesados = @"C:\TCI\STACE_GENERAMENSAJES\Agentes_Aduana_Procesados";
            requestEnvio.Casilla = "tcifcq";
            requestEnvio.CrearJeraquiaRespuesta = false;
            requestEnvio.Servidor = "192.168.4.40";
            requestEnvio.Dominio = "TCI";
            requestEnvio.GestorBaseDatos = "1";
            requestEnvio.GuardarRespuesta = true;
            requestEnvio.IdUsuarioSistema = -1;
            requestEnvio.IndicadorProxy = false;
            requestEnvio.BaseDatos = "DBAPPTAG";
            requestEnvio.IpProxy = "192.168.3.149";
            requestEnvio.ContraseniaBd = "d3sarrollo";
            requestEnvio.PuertoMySql = null;
            requestEnvio.PuertoProxy = 8080;
            requestEnvio.PwdCasilla = "12345";
            requestEnvio.PwdUsuarioProxy = "xd";
            requestEnvio.RegistrarDatos = true;
            requestEnvio.RutaCustomsDeclarationPeru =
                @"C:\TCI\STACE\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\CustomsDeclarationPeru_1p0.xsd";
            requestEnvio.RutaGuardarRespuesta = @"C:\TCI\STACE\Respuestas";
            //oEnEnvioRegistro.RutaLog = @"C:\TCI\STACE\Log";
            requestEnvio.RutaReusableAggregateBusiness1 =
                @"C:\TCI\STACE\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\SUNATReusableAggregateBusinessInformationEntity_D08b.xsd";
            requestEnvio.RutaReusableAggregateBusiness6 =
                @"C:\TCI\STACE\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\ReusableAggregateBusinessInformationEntity_D08b.xsd";
            requestEnvio.TipoAmbiente = false;
            requestEnvio.UrlSatServer = "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl";
            requestEnvio.UrlSatServerAlternativa = "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl";
            requestEnvio.UsuarioBd = "sa";
            requestEnvio.UsuarioProxy = "crios";
            requestEnvio.UsuarioSistema = "fcochachin";
            requestEnvio.TimeOut = 5000;

            LpMapReEnvio target = new LpMapReEnvio();
            List<ENRespuestaEnvio> lstRespuestaEnvios = new List<ENRespuestaEnvio>();
            string mensaje = string.Empty;
            var actual = target.TransmitirRegistro(requestEnvio, ref mensaje, ref lstRespuestaEnvios);
            if (actual != null)
            {
                
            }

        }

        string mensaje = string.Empty;
        private void btnRecepcionar_Click(object sender, EventArgs e)
        {

            LpMapReRespuesta target = new LpMapReRespuesta();
            List<ENRespuestaEnvio> listado = new List<ENRespuestaEnvio>();
            ParametroRespuestaMapRe oEnDatosGenerales = new ParametroRespuestaMapRe();

            oEnDatosGenerales.CrearJeraquiaRespuesta = false;
            oEnDatosGenerales.DataSource = "192.168.4.40";
            oEnDatosGenerales.Dominio = "TCI";
            oEnDatosGenerales.GestorBaseDatos = "1";
            oEnDatosGenerales.GuardarRespuesta = true;
            oEnDatosGenerales.IdUsuarioSistema = 12;
            //oEnDatosGenerales.IndicadorCredencialesDefault = false;
            oEnDatosGenerales.IndicadorProxy = false;
            oEnDatosGenerales.InitialCatalog = "DBAPPTAG";
            //oEnDatosGenerales.InsertarSaltosLineaRespuesta = false;
            oEnDatosGenerales.IpProxy = "192.168.3.149";
            oEnDatosGenerales.Password = "d3sarrollo";
            oEnDatosGenerales.Port = "3308";
            oEnDatosGenerales.PuertoProxy = 8080;
            oEnDatosGenerales.PwdUsuarioProxy = "karlitoz";
            oEnDatosGenerales.RegistrarDatos = true;
            oEnDatosGenerales.RutaCustomsDeclarationPeru = string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\CustomsDeclarationPeru_1p0.xsd");
            oEnDatosGenerales.RutaGuardarRespuesta = string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\Respuestas");
            //oEnDatosGenerales.RutaLog = string.Concat(AppDomain.CurrentDomain.BaseDirectory, @"\Test", @"\STACE", @"\LOG");
            oEnDatosGenerales.RutaReusableAggregateBusiness1 =
                @"C:\TCI\STACE\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\SUNATReusableAggregateBusinessInformationEntity_D08b.xsd";
            oEnDatosGenerales.RutaReusableAggregateBusiness6 =
                @"C:\TCI\STACE\EsquemaSDA\Esquemas_ManifiestoCarga\data\standard\ReusableAggregateBusinessInformationEntity_D08b.xsd";
            oEnDatosGenerales.TipoAmbiente = false;
            //oEnDatosGenerales.UrlSatServer = "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl";
            //oEnDatosGenerales.UrlSatServerAlternativa = "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl";
            oEnDatosGenerales.UrlSatServer = "http://200.106.52.143/Sat3/WSSDA?wsdl";
            oEnDatosGenerales.UrlSatServerAlternativa = "http://200.106.52.143/Sat3/WSSDA?wsdl";
            oEnDatosGenerales.UserId = "sa";
            oEnDatosGenerales.UsuarioProxy = "crios";
            oEnDatosGenerales.UsuarioSistema = "fcochachin";
            oEnDatosGenerales.ValidaEsquema = false;
            oEnDatosGenerales.NombreRespuesta = null;
            
            var actual = target.ProcesarRespuestasPendientesDeMarcacion(oEnDatosGenerales, ref mensaje, ref listado);
            if (actual != null)
            {
                
            }

        }
    }
}
