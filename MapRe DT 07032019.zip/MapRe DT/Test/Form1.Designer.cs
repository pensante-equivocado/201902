﻿namespace Test
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnviarArchivo = new System.Windows.Forms.Button();
            this.btnRecepcionar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEnviarArchivo
            // 
            this.btnEnviarArchivo.Location = new System.Drawing.Point(92, 53);
            this.btnEnviarArchivo.Name = "btnEnviarArchivo";
            this.btnEnviarArchivo.Size = new System.Drawing.Size(107, 23);
            this.btnEnviarArchivo.TabIndex = 0;
            this.btnEnviarArchivo.Text = "Enviar Archivo";
            this.btnEnviarArchivo.UseVisualStyleBackColor = true;
            this.btnEnviarArchivo.Click += new System.EventHandler(this.btnEnviarArchivo_Click);
            // 
            // btnRecepcionar
            // 
            this.btnRecepcionar.Location = new System.Drawing.Point(379, 53);
            this.btnRecepcionar.Name = "btnRecepcionar";
            this.btnRecepcionar.Size = new System.Drawing.Size(120, 23);
            this.btnRecepcionar.TabIndex = 1;
            this.btnRecepcionar.Text = "Recepcionar";
            this.btnRecepcionar.UseVisualStyleBackColor = true;
            this.btnRecepcionar.Click += new System.EventHandler(this.btnRecepcionar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 337);
            this.Controls.Add(this.btnRecepcionar);
            this.Controls.Add(this.btnEnviarArchivo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEnviarArchivo;
        private System.Windows.Forms.Button btnRecepcionar;
    }
}

