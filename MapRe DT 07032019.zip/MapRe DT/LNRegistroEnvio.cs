﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.EntityClient;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Transactions;
using System.Xml;
using System.Xml.Serialization;
using DLLMapRe.AccesoDatos;
using DLLMapRe.Configuracion.Entidad;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades;
using DLLMapRe.Entidades.Canal;
using DLLMapRe.Entidades.EnvioRegistro;
using DLLMapRe.Entidades.Maestro;
using DLLMapRe.Entidades.XmlOma;
using DLLMapRe.LogicaNegocio.Envio;
using DLLMapRe.LogicaNegocio.Maestro;
using DLLMapRe.LogicaProceso;
using DLLTransWeb.Entidades;
using DLLTransWeb.Entidades.Respuesta;
using DLLTransWeb.LogicaNegocio;
using Microsoft.VisualBasic.CompilerServices;
using SW_TransWeb.Entidades;
using SW_TransWeb.LN;
using tciUtilitarios;
using ENDatosGenerales = DLLMapRe.Entidades.ENDatosGenerales;
//using TciDLLLog;
//using TciDLLLog.EN;


namespace DLLMapRe.LogicaNegocio
{
    public class LNRegistroEnvio
    {

        #region "VARIABLES"

        private string CstrNombreSistema;
        private string CstrVersionSistema;
        private string CstrUsuarioSistema;
        private string CstrDireccionIPEquipo;
        private string CstrProyecto;
        private string CstrClase;
        private string strMensaje;
        private string nombreArchivoXmlConExtension;
        private string rutaDirectorioArchivoZip;
        private string strCadenaConexion;

        private Int32 intIdEnvio;
        private Int32 intTipoRespuesta;
        private Int32 intIdTransaccion;
        private Boolean bolValidar;
        private Boolean bolResultado;
        private List<string> lstErrores;
        private string strProvider;
        private byte[] strArchivoXML;
        private string strNombreArchivo;
        private Int32 strPesoArchivo;
        private string strNumeroOrden = "";

        private string strRutaConfiguracion = AppDomain.CurrentDomain.BaseDirectory + @"\ConfiguracionCom.xml";

        #endregion

        #region "OBJETOS"

        /// <summary>
        /// Variables de objetos propios del sistema
        /// </summary>
        private OACustomsManifestPeru oCustomsDeclarationPeruType = new OACustomsManifestPeru();

        private ResponsePeruType oResponsePeruType = new ResponsePeruType();
        private ENRecepcionRespuesta oEnRecepcionRespuesta = new ENRecepcionRespuesta();
        private clsValidacionDatos oclsValidacionDatos = new clsValidacionDatos();
        private LNEnvioRespuesta oLnEnvioRespuesta = new LNEnvioRespuesta();
        private ENDocumentoEnvio oEnDocumentoEnvio = new ENDocumentoEnvio();
        private clsUtilitarios oClsUtilitarios = new clsUtilitarios();
        private ENRespuesta oEnRespuesta = new ENRespuesta();
        //ENLogTci oEnLogTci = new ENLogTci();
        private ENEnvio oEnEnvio = new ENEnvio();
        //LogTCI oLogTCI = new LogTCI();
        private ENLstRespuestas oEnLstRespuestas = new ENLstRespuestas();
        private LNValidarXML oLnValidarXml = new LNValidarXML();
        private ENRespuesta oEnMarcarRespuesta = new ENRespuesta();

        /// <summary>
        /// Variables de objetos de las clases de la base de datos SQL
        /// </summary>
        private ENVIOS oEnviosSQL = new ENVIOS();

        private RESPUESTA oRespuestaSQL = new RESPUESTA();
        private DETALLERESPUESTA oDetalleRespuestaSQL = new DETALLERESPUESTA();
        private ENVIOS oEnvioSQLT = new ENVIOS();

        private INFORMACIONRESPUESTA oInformacionRespuestaSQL =
            new INFORMACIONRESPUESTA();

        private DATOSDOCASOCIADOSRESPUESTA oDatosDocAsociadosRespuestaSQL =
            new DATOSDOCASOCIADOSRESPUESTA();

        private DATOSDOCREFERENCIARESPUESTA oDatosDocReferenciaRespuestaSQL =
            new DATOSDOCREFERENCIARESPUESTA();

        private ERRORENVIO oErrorEnvioSQL = new ERRORENVIO();

        #endregion

        private string fstr_ObtenerValorEtiquetaHijoXML(XmlNode Nodo, String strEtiqueta)
        {
            try
            {
                string strValor = string.Empty;
                foreach (XmlNode NodoH in Nodo.ChildNodes)
                {
                    if (NodoH is XmlElement)
                    {
                        if (NodoH.Name.Equals(strEtiqueta.Trim()))
                        {
                            strValor = NodoH.InnerText;
                            break;
                        }
                    }
                }
                return strValor;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fint_ObtenerValorEtiquetaHijoXML", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return string.Empty;
            }
        }

        private int fint_ObtenerRepeticionesHijosXML(XmlNode Nodo, String strEtiqueta)
        {
            try
            {
                int intRep = 0;
                foreach (XmlNode NodoH in Nodo.ChildNodes)
                {
                    if (NodoH is XmlElement)
                    {
                        if (NodoH.Name.Equals(strEtiqueta.Trim()))
                        {
                            intRep += 1;
                            //break;
                        }
                    }
                }
                return intRep;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fint_ObtenerRepeticionesHijosXML", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return 0;
            }
        }

        private ResultCanal RegistrarCanalMaster(DBAPPTAGSQLEntities context, CanalMaster canalMaster)
        {
            try
            {
                using (context)
                {
                    var aduana = new SqlParameter("@aduana", canalMaster.CodigoAduana);
                    var anioManifiesto = new SqlParameter("@anio", canalMaster.AnioManifiesto);
                    var numeroManifiesto = new SqlParameter("@numero", canalMaster.NumeroManifiesto);
                    var blMaster = new SqlParameter("@blMaster", canalMaster.BlMaster);

                    var result = context
                        .ExecuteStoreQuery<ResultCanal>
                        (
                            "Exec APPTAG.Usp_RegistrarCanalMaster @aduana,@anio,@numero,@blMaster"
                            , aduana
                            , anioManifiesto
                            , numeroManifiesto
                            , blMaster
                        )
                        .Select(q => new ResultCanal
                        {
                            Clave = q.Clave,
                            Valor = q.Valor
                        }
                        )
                        .FirstOrDefault();

                    return result;
                }
            }
            catch (Exception e)
            {
                //p_RegistrarLog("RegistrarCanalMaster", ENLogTci.TipoMensaje.Error, e.Message);
                Logger.Log(Logger.Level.Error, e.Message);
                strMensaje = e.Message;
                return null;
            }
        }

        private Boolean fbol_RegistrarDetalleRespuesta(DBAPPTAGSQLEntities dbContext)
        {

            try
            {
                oDetalleRespuestaSQL = new DETALLERESPUESTA
                {
                    CODIGO = oRespuestaSQL.TDOCCDA,
                    DESCRIPCION = oRespuestaSQL.MENSAJENOTIFICACION,
                    NROMANIFIESTO = oRespuestaSQL.NUMECORRE,
                    TIPODOCCDA = oRespuestaSQL.TDOCCDA,
                    FECHAACEPTACION = oRespuestaSQL.FECHANUMERACION,
                    IDRESPUESTA = oRespuestaSQL.IDRESPUESTA,
                    TIPOMENSAJE = 3
                };
                dbContext.DETALLERESPUESTA.AddObject(oDetalleRespuestaSQL);
                dbContext.SaveChanges();

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean fbol_RegistrarInformacionDetalleRespuesta(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext)
        {
            try
            {
                string strID = string.Empty;
                Int32 intSecuencia = 0;
                string strInformation = string.Empty;
                string strIssueDateTime = string.Empty;
                string strIDIssue = string.Empty;

                //RECORRER EL DETALLE DE LA RESPUESTA CORRECTA
                foreach (object NodoREPS in xDoc.DocumentElement)
                {
                    if ((NodoREPS) is XmlElement)
                    {
                        if (((XmlElement) NodoREPS).Name.Equals("rsm:ReportedProcessingResult"))
                        {
                            foreach (object NodoEPS in ((XmlElement) NodoREPS).ChildNodes)
                            {
                                if ((NodoEPS) is XmlElement)
                                {
                                    if (((XmlElement) NodoEPS).Name.Equals("userram:SpecifiedSupplyChainConsignment"))
                                    {
                                        foreach (XmlNode NodoE in ((XmlElement) NodoEPS).ChildNodes)
                                        {
                                            if ((NodoE) is XmlElement)
                                            {
                                                if (((XmlElement) NodoE).Name.Equals("ram:SequenceNumeric"))
                                                {
                                                    if (!string.IsNullOrEmpty(((XmlElement) NodoE).InnerText))
                                                    {
                                                        intSecuencia =
                                                            Convert.ToInt32(
                                                                Conversions.ToDouble(((XmlElement) NodoE).InnerText));
                                                    }
                                                    //intSecuencia = oclsValidacionDatos.fint_ObtenDatoInt(((XmlElement)NodoE).InnerText);
                                                }

                                                if (NodoE.Name.Equals("ram:TransportContractReferencedDocument"))
                                                {
                                                    foreach (XmlNode Nodo in ((XmlElement) NodoE).ChildNodes)
                                                    {
                                                        if ((Nodo) is XmlElement)
                                                        {
                                                            if (Nodo.Name.Equals("ram:Information"))
                                                            {
                                                                strInformation = ((XmlElement) Nodo).InnerText;
                                                            }
                                                            if (Nodo.Name.Equals("ram:ID"))
                                                            {
                                                                strID =
                                                                    oclsValidacionDatos.fstr_ObtenDato(
                                                                        ((XmlElement) Nodo).InnerText);
                                                            }
                                                            if (Nodo.Name.Equals("ram:IssueDateTime"))
                                                            {
                                                                strIssueDateTime =
                                                                    oclsValidacionDatos.fstr_ObtenDato(
                                                                        ((XmlElement) Nodo).InnerText);
                                                            }
                                                            if (Nodo.Name.Equals("ram:IssueLogisticsLocation"))
                                                            {
                                                                foreach (XmlNode Nod in ((XmlElement) Nodo).ChildNodes)
                                                                {
                                                                    if ((Nod) is XmlElement)
                                                                    {
                                                                        if (Nod.Name.Equals("ram:ID"))
                                                                        {
                                                                            strIDIssue = ((XmlElement) Nod).InnerText;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                        }
                                                    }
                                                }

                                            }
                                        }

                                        /////////////////////////////////////////////////////////////////////////////////////////////
                                        /// REGISTRAR INFORMACION DE LA RESPUESTA
                                        oInformacionRespuestaSQL = new INFORMACIONRESPUESTA
                                        {
                                            IDRESPUESTA = oRespuestaSQL.IDRESPUESTA,
                                            NRODETALLE = intSecuencia,
                                            NRODOCUMENTOORIGEN = strID,
                                            INFORMACION = oclsValidacionDatos.fstr_ObtenDato(strInformation),
                                            CODPUERTO = oclsValidacionDatos.fstr_ObtenDato(strIDIssue)
                                        };

                                        if (!string.IsNullOrEmpty(strIssueDateTime))
                                        {
                                            oInformacionRespuestaSQL.FECHAEMISION = Convert.ToDateTime(strIssueDateTime);
                                        }

                                        dbContext.INFORMACIONRESPUESTA.AddObject(oInformacionRespuestaSQL);
                                        dbContext.SaveChanges();
                                        /////////////////////////////////////////////////////////////////////////////////////////////

                                    }
                                }
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarInformacionDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean fbol_RegistrarErroresDetalleRespuesta(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext)
        {
            try
            {
                //ERRORES DE LA RESPUESTA
                string strReasonCode = String.Empty, strInformation = String.Empty;
                foreach (object NodoREPS in xDoc.DocumentElement)
                {
                    if ((NodoREPS) is XmlElement)
                    {
                        if (((XmlElement) NodoREPS).Name.Equals("rsm:ReportedErrorProcessingStatus"))
                        {
                            foreach (object NodoEPS in ((XmlElement) NodoREPS).ChildNodes)
                            {
                                if ((NodoEPS) is XmlElement)
                                {
                                    if (((XmlElement) NodoEPS).Name.Equals("userram:ReportedErrorStatus"))
                                    {
                                        foreach (object NodoE in ((XmlElement) NodoEPS).ChildNodes)
                                        {
                                            if ((NodoE) is XmlElement)
                                            {
                                                if (((XmlElement) NodoE).Name.Equals("ram:ReasonCode") &&
                                                    strReasonCode.Trim().Length == 0)
                                                {
                                                    strReasonCode = ((XmlElement) NodoE).InnerText;
                                                }
                                                if (((XmlElement) NodoE).Name.Equals("ram:Information"))
                                                {
                                                    strInformation = ((XmlElement) NodoE).InnerText;
                                                }
                                            }
                                        }

                                        /////////////////////////////////////////////////////////////////////////////////////////////
                                        // REGISTRAR ERRORES EN LA RESPUESTA
                                        oDetalleRespuestaSQL = new DETALLERESPUESTA
                                        {
                                            CODIGO = strReasonCode,
                                            DESCRIPCION = strInformation,
                                            IDRESPUESTA = oRespuestaSQL.IDRESPUESTA,
                                            TIPOMENSAJE = 1
                                        };
                                        dbContext.DETALLERESPUESTA.AddObject(oDetalleRespuestaSQL);
                                        dbContext.SaveChanges();
                                    }
                                }
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarErroresDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean fbol_RegistrarWarningsDetalleRespuesta(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext)
        {
            try
            {

                ///  LAS ADVERTENCIAS DE LA RESPUESTA
                string strReasonCode = String.Empty, strInformation = String.Empty;
                foreach (object NodoREPS in xDoc.DocumentElement)
                {
                    if ((NodoREPS) is XmlElement)
                    {
                        if (((XmlElement) NodoREPS).Name.Equals("rsm:ReportedWarningProcessingStatus"))
                        {
                            foreach (object NodoEPS in ((XmlElement) NodoREPS).ChildNodes)
                            {
                                if ((NodoEPS) is XmlElement)
                                {
                                    if (((XmlElement) NodoEPS).Name.Equals("userram:ReportedErrorStatus"))
                                    {
                                        foreach (object NodoE in ((XmlElement) NodoEPS).ChildNodes)
                                        {
                                            if ((NodoE) is XmlElement)
                                            {
                                                if (((XmlElement) NodoE).Name.Equals("ram:ReasonCode"))
                                                {
                                                    strReasonCode =
                                                        oclsValidacionDatos.fstr_ObtenDato(
                                                            ((XmlElement) NodoE).InnerText);
                                                    break;
                                                }
                                                if (((XmlElement) NodoE).Name.Equals("ram:Information"))
                                                {
                                                    strInformation =
                                                        oclsValidacionDatos.fstr_ObtenDato(
                                                            ((XmlElement) NodoE).InnerText);
                                                }
                                            }
                                        }

                                        /////////////////////////////////////////////////////////////////////////////////////////////
                                        oDetalleRespuestaSQL = new DETALLERESPUESTA
                                        {
                                            CODIGO = strReasonCode,
                                            DESCRIPCION = strInformation,
                                            IDRESPUESTA = oRespuestaSQL.IDRESPUESTA,
                                            TIPOMENSAJE = 2
                                        };
                                        dbContext.DETALLERESPUESTA.AddObject(oDetalleRespuestaSQL);
                                        dbContext.SaveChanges();
                                        break;
                                        /////////////////////////////////////////////////////////////////////////////////////////////

                                    }
                                }
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarWarningsDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }

        public Boolean fbol_EnvioRegistro(ENEnvioRegistro oENEnvioRegistro, ref string strMensaje,
            ref List<ENRespuestaEnvio> lstRespuestaEnvio)
        {
            Boolean ErrorArchivo = false;
            try
            {
                p_InicializarConstantes(oENEnvioRegistro.UsuarioSistema, oENEnvioRegistro.GestorBaseDatos,
                    oENEnvioRegistro.DataSource, oENEnvioRegistro.Port, oENEnvioRegistro.InitialCatalog,
                    oENEnvioRegistro.UserID, oENEnvioRegistro.Password);

                Config conf = new Config
                {
                    Servidor = oENEnvioRegistro.DataSource,
                    BaseDatos = oENEnvioRegistro.InitialCatalog,
                    Usuario = oENEnvioRegistro.UserID,
                    Contrasenia = oENEnvioRegistro.Password
                };

                ConfigController.GetConfiguration(conf);

                //p_InicializarVariables(oENEnvioRegistro.RutaLog);

                if (!fbol_LeerConfiguracion(strRutaConfiguracion))
                {
                    //p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error,
                    //    "No se pudo cargar el Archivo de Configuración");
                    Logger.Log(Logger.Level.Error, "No se pudo cargar el Archivo de Configuración");
                    return false;
                }
                
                if (!ValidarRutasEsquemas(oENEnvioRegistro, ref strMensaje))
                {
                    //p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error, strMensaje);
                    Logger.Log(Logger.Level.Error, strMensaje);
                    return false;
                }

                //Consultar desde la base de datos, el parametro validaesquema
                LnConfiguracion lnConfiguracion = new LnConfiguracion();
                Entidades.Maestro.Configuracion entidadConfiguracion = lnConfiguracion.Obtener();
                if (entidadConfiguracion != null)
                {
                    oENEnvioRegistro.ValidaEsquema = entidadConfiguracion.ValidaEsquema;
                    oENEnvioRegistro.NombreRespuesta = entidadConfiguracion.TipoNombreArchivo;
                }
                else
                {
                    Logger.Log(Logger.Level.Error, strMensaje);
                    return false;
                }

                //if (!fbol_ObtenerConfiguracion(ref oENEnvioRegistro))
                //{
                    //p_RegistrarLog("fbol_ObtenerConfiguracion", ENLogTci.TipoMensaje.Error, strMensaje);
                //    Logger.Log(Logger.Level.Error, strMensaje);
                //    return false;
                //}

                //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info, "Inicio del método bol_EnvioRegistro");
                Logger.Log(Logger.Level.Info, "Inicio del método");
                string[] listaArchivosZip = Directory.GetFiles(oENEnvioRegistro.Directorio, "*.zip");
                //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info,
                //    String.Format("Se encontraron {0} archivos en la ruta : {1}", strArchivos.Length,
                //        oENEnvioRegistro.Directorio));
                Logger.Log(Logger.Level.Info,
                    String.Format("Se encontro {0} archivos en la ruta : {1}", listaArchivosZip.Length,
                        oENEnvioRegistro.Directorio));

                //string rutaCompletaArchivoXml = string.Empty;
                //string nombreArchivoZipConExtension = string.Empty;
                foreach (string rutaCompletaArchivoZip in listaArchivosZip)
                {
                    try
                    {

                        ENRespuestaEnvio oEnRespuestaEnvio = new ENRespuestaEnvio();

                        string nombreArchivoZipConExtension = Path.GetFileName(rutaCompletaArchivoZip);
                        rutaDirectorioArchivoZip = Path.GetDirectoryName(rutaCompletaArchivoZip);

                        //strNombreZIP = rutaCompletaArchivoZip.Substring(rutaCompletaArchivoZip.LastIndexOf(@"\") + 1, rutaCompletaArchivoZip.Length - rutaCompletaArchivoZip.LastIndexOf(@"\") - 1);
                        //strDirectorioXML = rutaCompletaArchivoZip.Substring(0, rutaCompletaArchivoZip.LastIndexOf(@"\"));
                        string rutaCompletaArchivoXml = oClsUtilitarios.decompressFile(rutaDirectorioArchivoZip, nombreArchivoZipConExtension).Replace(@"/", @"\");
                        //strNombreXML = strRutaXML.Substring(strRutaXML.LastIndexOf(@"/") + 1, strRutaXML.Length - strRutaXML.LastIndexOf(@"/") - 1);
                        nombreArchivoXmlConExtension = Path.GetFileName(rutaCompletaArchivoXml);


                        oEnRespuestaEnvio.NombreArchivoZIP = nombreArchivoZipConExtension;
                        oEnRespuestaEnvio.NombreArchivoXML = nombreArchivoXmlConExtension;

                        if (oENEnvioRegistro.ValidaEsquema)
                        {
                            oCustomsDeclarationPeruType = fnx_MapearXMLEnvioFile(rutaCompletaArchivoXml);


                            if (oCustomsDeclarationPeruType != null)
                            {
                                ErrorArchivo = true;
                                Logger.Log(Logger.Level.Info, String.Format("Se mapeo el archivo {0}", rutaCompletaArchivoXml));
                            }
                            else
                            {
                                strMensaje =
                                    string.Format("Error al Mapear el archivo {0}. Es incorrecto." + Environment.NewLine,
                                        rutaCompletaArchivoXml);

                                Logger.Log(Logger.Level.Info, String.Format("No se mapeo el archivo {0}", rutaCompletaArchivoXml));
                                fnx_EliminarArchivo(rutaCompletaArchivoXml);

                                MoveFile(rutaDirectorioArchivoZip, oENEnvioRegistro.DirectorioError, nombreArchivoZipConExtension);
                                Logger.Log(Logger.Level.Info,
                                    String.Format("Se movio el árchivo {0} a la ruta {1}", rutaCompletaArchivoZip,
                                        oENEnvioRegistro.DirectorioError));

                                continue;
                            }

                        }
                        
                        oEnEnvio = fnx_SetearDatosGeneralesEnvio(oENEnvioRegistro, objENxmlSW);

                        LpLecturaXmlOma lpLecturaXmlOma = new LpLecturaXmlOma();
                        LpLecturaXmlCustomsManifestPeru lpLecturaXmlCustomsManifestPeru = new LpLecturaXmlCustomsManifestPeru();
                        String codigoTransaccionDesdeXml = "";
                        Boolean esEstructuraOma = lpLecturaXmlOma.ValidarEstructura(rutaCompletaArchivoXml, ref codigoTransaccionDesdeXml);
                        //Boolean esEstructuraCustomsManifestPeru = false;
                        //if (!esEstructuraOma)
                        //{
                        //    esEstructuraCustomsManifestPeru =
                        //        lpLecturaXmlCustomsManifestPeru.ValidarEstructura(rutaCompletaArchivoXml,
                        //            ref codigoTransaccionDesdeXml);
                        //}

                        DeclarationMetaData lectura = null;
                        if (oENEnvioRegistro.ValidaEsquema)
                        {
                            if (!esEstructuraOma)
                            {
                                AsignarValoresConEsquemaCustomsManifestPeru(oCustomsDeclarationPeruType, null,
                                    rutaDirectorioArchivoZip, nombreArchivoXmlConExtension,
                                    fint_ObtenerTamanioArchivo(rutaCompletaArchivoXml), ref oEnDocumentoEnvio,
                                    ref oEnviosSQL,
                                    ref lstErrores);
                            }
                            //JPT - 27/11/2014
                            oEnRespuestaEnvio.NumeroOrden =
                                oclsValidacionDatos.fstr_ObtenDato(
                                    oCustomsDeclarationPeruType.HeaderExchangedDocument.TraderAssignedID[0].Value);
                        }
                        else
                        {
                            //oEnviosSQL se crea una instancia
                            AsignarValoresSinEsquemaCustomsManifestPeru(null, rutaDirectorioArchivoZip, nombreArchivoXmlConExtension,
                                fint_ObtenerTamanioArchivo(rutaCompletaArchivoXml), ref oEnDocumentoEnvio, ref oEnviosSQL,
                                ref lstErrores);

                            if (esEstructuraOma)
                            {
                                lectura = lpLecturaXmlOma.LeerArchivoXml(rutaCompletaArchivoXml, ref oEnviosSQL);
                            }

                        }

                        if (oEnEnvio.IdUsuarioSistema > 0)
                        {
                            oEnviosSQL.IDUSUARIO = oEnEnvio.IdUsuarioSistema;
                        }
                        oEnEnvio.DocumentoEnvio = oEnDocumentoEnvio;

                        if (oENEnvioRegistro.ValidaEsquema)
                        {
                            bolValidar = oLnValidarXml.fbol_ValidarXML(rutaCompletaArchivoXml,
                                oENEnvioRegistro.RutaCustomsDeclarationPeru,
                                oENEnvioRegistro.RutaReusableAggregateBusiness1,
                                oENEnvioRegistro.RutaReusableAggregateBusiness6, ref lstErrores);
                            Logger.Log(Logger.Level.Info, String.Format("Se validó el archivo {0}", rutaCompletaArchivoXml));
                        }
                        else
                        {
                            bolValidar = true;
                            Logger.Log(Logger.Level.Info, String.Format("No se validó el archivo {0}", rutaCompletaArchivoXml));
                        }

                        if (bolValidar)
                        {
                            try
                            {
                                oEnRespuesta = oLnEnvioRespuesta.bol_EnvioMensaje(oEnEnvio);
                                if (oEnRespuesta == null)
                                {
                                    oEnRespuestaEnvio.Transmitido = false;
                                    oENEnvioRegistro.RegistrarDatos = false;
                                    bolValidar = false;
                                    Logger.Log(Logger.Level.Info,
                                        String.Format("Se produjo un problema con el envío del archivo {0}", rutaCompletaArchivoXml));
                                }
                                else
                                {
                                    oEnRespuestaEnvio.Transmitido = true;
                                    Logger.Log(Logger.Level.Info, String.Format("Se envió el archivo {0}", rutaCompletaArchivoXml));
                                    Logger.Log(Logger.Level.Info, string.Format("Se obtuvo el id de transacción : {0}",
                                        oEnRespuesta.Resultado));
                                }
                            }
                            catch (Exception ee)
                            {
                                oEnRespuestaEnvio.Transmitido = false;
                                Logger.Log(Logger.Level.Error, ee.Message);
                            }
                        }
                        else
                        {
                            oEnRespuestaEnvio.Transmitido = false;

                            for (int i = 0; i <= lstErrores.Count - 1; i++)
                            {
                                Logger.Log(Logger.Level.Error, lstErrores[i]);
                            }
                        }

                        if (oENEnvioRegistro.RegistrarDatos)
                        {

                            if (fbol_RegistrarEnvioRespuestaSQL(oEnviosSQL, oEnRespuesta, bolValidar, lstErrores, oENEnvioRegistro.TipoAmbiente, lectura))
                            {
                                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                oEnRespuestaEnvio.Registrado = true;
                                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info,
                                //    String.Format("Se registró el archivo {0}", strRutaXML));
                                Logger.Log(Logger.Level.Info, String.Format("Se registró el archivo {0}", rutaCompletaArchivoXml));
                            }
                            else
                            {
                                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                oEnRespuestaEnvio.Registrado = false;
                                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info,
                                //    String.Format("Ocurrio un error al registrar el archivo {0}", strRutaXML));
                                Logger.Log(Logger.Level.Info,
                                    String.Format("Ocurrio un error al registrar el archivo {0}", rutaCompletaArchivoXml));
                            }

                        }
                        else
                        {
                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            oEnRespuestaEnvio.Registrado = false;
                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        }

                        lstRespuestaEnvio.Add(oEnRespuestaEnvio);

                        fnx_EliminarArchivo(rutaCompletaArchivoXml);
                        if (bolValidar)
                        {
                            MoveFile(rutaDirectorioArchivoZip, oENEnvioRegistro.DirectorioProcesados, nombreArchivoZipConExtension);
                            //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info,
                            //    String.Format("Se movio el árchivo {0} a la ruta {1}", strArchivo,
                            //        oENEnvioRegistro.DirectorioProcesados));
                            Logger.Log(Logger.Level.Info,
                                String.Format("Se movio el árchivo {0} a la ruta {1}", rutaCompletaArchivoZip,
                                    oENEnvioRegistro.DirectorioProcesados));
                        }
                        else
                        {
                            MoveFile(rutaDirectorioArchivoZip, oENEnvioRegistro.DirectorioError, nombreArchivoZipConExtension);
                            //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info,
                            //    String.Format("Se movio el árchivo {0} a la ruta {1}", strArchivo,
                            //        oENEnvioRegistro.DirectorioError));
                            Logger.Log(Logger.Level.Info,
                                String.Format("Se movio el árchivo {0} a la ruta {1}", rutaCompletaArchivoZip,
                                    oENEnvioRegistro.DirectorioError));
                        }

                    }
                    catch (FileNotFoundException e)
                    {
                        //p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error, e.Message);
                        Logger.Log(Logger.Level.Error, e.Message);
                    }
                }
                //p_RegistrarLog("bol_EnvioRegistro", ENLogTci.TipoMensaje.Info, "Fin del método bol_EnvioRegistro");
                Logger.Log(Logger.Level.Info, "Fin del método");
                return ErrorArchivo;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }


        private bool ValidarRutasEsquemas(ENEnvioRegistro oENEnvioRegistro, ref string mensaje)
        {
            if (!File.Exists(oENEnvioRegistro.RutaReusableAggregateBusiness1))
            {
                mensaje = "No existe el esquema en la ruta: " + oENEnvioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            if (!File.Exists(oENEnvioRegistro.RutaReusableAggregateBusiness6))
            {
                mensaje = "No existe el esquema en la ruta: " + oENEnvioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            if (!File.Exists(oENEnvioRegistro.RutaCustomsDeclarationPeru))
            {
                mensaje = "No existe el esquema en la ruta: " + oENEnvioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            return true;
        }

        private void fnx_EliminarArchivo(string filename)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            File.Delete(filename);
        }

        private Int64 fint_ObtenerTamanioArchivo(string strArchivo)
        {
            try
            {
                Int64 intLongitud = 0;
                FileInfo info = new FileInfo(strArchivo);
                intLongitud = info.Length;
                return intLongitud;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        private Boolean fbol_RegistrarEnvioRespuestaSQL(ENVIOS oEnviosSQL, ENRespuesta oEnRespuesta,
            Boolean bolValidacion, List<string> lstErrores, Boolean bolTipoAmbiente, DeclarationMetaData lectura = null)
        {

            try
            {
                using (TransactionScope transactionScope = new TransactionScope())
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(strCadenaConexion);
                    oEnviosSQL.FECHATCI = DateTime.Now;
                    if (bolValidacion)
                    {
                        oEnviosSQL.IDESTADOTCI = oEnRespuesta.Resultado > 0 ? 1 : 8;
                    }
                    else
                    {
                        oEnviosSQL.IDESTADOTCI = 0;
                    }

                    oEnviosSQL.IDESTADOACUSE = 0;
                    oEnviosSQL.IDESTADORESPUESTA = 0;
                    oEnviosSQL.IDTRANSACCION = oEnRespuesta.Resultado;
                    oEnviosSQL.PASOESQUEMA = bolValidacion ? 1 : 0;
                    oEnviosSQL.TIPOAMBIENTE = bolTipoAmbiente;
                    dbContext.ENVIOS.AddObject(oEnviosSQL);
                    dbContext.SaveChanges();
                    intTipoRespuesta = oEnRespuesta.Resultado > 0 ? 1 : 4;

                    if (bolValidacion)
                    {

                        fbol_RegistrarRespuestaSQL(oEnviosSQL.IDENVIO, oEnRespuesta, intTipoRespuesta);
                    }

                    if (lstErrores.Count > 0)
                    {
                        for (int i = 0; i <= lstErrores.Count - 1; i++)
                        {
                            oErrorEnvioSQL = new ERRORENVIO();
                            oErrorEnvioSQL.IDENVIO = oEnviosSQL.IDENVIO;
                            oErrorEnvioSQL.DESCRIPCION = lstErrores[i];
                            oErrorEnvioSQL.FECHAREGISTRO = DateTime.Now;
                            dbContext.ERRORENVIO.AddObject(oErrorEnvioSQL);
                            dbContext.SaveChanges();
                        }
                    }

                    //p_RegistrarLog("fbol_RegistrarEnvioRespuestaSQL", ENLogTci.TipoMensaje.Info, "Se registro el envio con estado : " + oEnviosSQL.IDESTADOTCI.ToString());
                    Logger.Log(Logger.Level.Info, "Se registro el envio con estado : " + oEnviosSQL.IDESTADOTCI);
                    dbContext.Dispose();
                    transactionScope.Complete();
                    
                }
                if (lectura != null)
                {
                    RegistrarDatosExtrasEnvio(oEnviosSQL.IDENVIO, lectura);
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarEnvioRespuesta", ENLogTci.TipoMensaje.Error, ex.Message + " - " + ex.InnerException);
                Logger.Log(Logger.Level.Error, ex.Message + " - " + ex.InnerException);
                return false;
            }
            
        }

        private void RegistrarDatosExtrasEnvio(Int32 idEnvio, DeclarationMetaData lectura)
        {
            try
            {
                LnTipoManifiesto lnTipoManifiesto = new LnTipoManifiesto();
                LnTipoOperador lnTipoOperador = new LnTipoOperador();
                LnTipoTransaccion lnTipoTransaccion = new LnTipoTransaccion();
                LnViaTransporte lnViaTransporte = new LnViaTransporte();

                var tipoManifiesto =
                    lnTipoManifiesto.ObtenerPorCodigo(lectura.Declaration.DeclarationAdditionalDocument.CategoryCode);
                var tipoOperador = lnTipoOperador.ObtenerPorCodigo(lectura.Declaration.DeclarationSubmitter.RoleCode);
                var tipoTransaccion = lnTipoTransaccion.ObtenerPorCodigo(lectura.FunctionalDefinition);
                ViaTransporte viaTransporte = null;
                if (lectura.Declaration.DeclarationBorderTransportMeans != null)
                {
                    viaTransporte =
                        lnViaTransporte.ObtenerPorCodigo(lectura.Declaration.DeclarationBorderTransportMeans.ModeCode);
                }
                    
                Int32? cantidadCarga = lectura.Declaration.CantidadDeclarationConsignment;

                if (tipoManifiesto != null || tipoOperador != null || tipoTransaccion != null || viaTransporte != null)
                {
                    LnEnvio lnEnvio = new LnEnvio();
                    int? idTipoManifiesto = null;
                    int? idTipoOperador = null;
                    string codTipoTransaccion = null;
                    int? idViaTransporte = null;
                    if (tipoManifiesto != null) idTipoManifiesto = tipoManifiesto.IdTipoManifiesto;
                    if (tipoOperador != null) idTipoOperador = tipoOperador.IdTipoOperador;
                    if (tipoTransaccion != null) codTipoTransaccion = tipoTransaccion.CodTipoTransaccion;
                    if (viaTransporte != null) idViaTransporte = viaTransporte.IdViaTransporte;

                    lnEnvio.ActualizarAnexos(idEnvio, idTipoOperador, idTipoManifiesto,
                        idViaTransporte, codTipoTransaccion, cantidadCarga, lectura.FunctionalDefinition);
                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarEnvioRespuesta", ENLogTci.TipoMensaje.Error, ex.Message + " - " + ex.InnerException);
                Logger.Log(Logger.Level.Error, ex.Message + " - " + ex.InnerException);
            }
        }

        private Boolean fbol_RegistrarRespuestaSQL(Int32 IdEnvio, ENRespuesta oEnRespuesta, Int32 intIdTipoRespuesta)
        {
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(strCadenaConexion);
                    oRespuestaSQL = new RESPUESTA();
                    oRespuestaSQL.FECHAACEPTACION = DateTime.Now;
                    oRespuestaSQL.FECHAREGISTRO = DateTime.Now;
                    oRespuestaSQL.IDENVIO = IdEnvio;
                    oRespuestaSQL.IDTIPORESPUESTA = intIdTipoRespuesta;
                    oRespuestaSQL.IDESTADORESPUESTA = oEnRespuesta.Resultado > 0 ? 1 : 8;
                    dbContext.RESPUESTA.AddObject(oRespuestaSQL);
                    dbContext.SaveChanges();

                    if (oEnRespuesta.LstErrores != null)
                    {
                        for (int i = 0; i <= oEnRespuesta.LstErrores.Count - 1; i++)
                        {
                            oDetalleRespuestaSQL = new DETALLERESPUESTA();
                            oDetalleRespuestaSQL.CODIGO = oEnRespuesta.LstErrores[i].Codigo;
                            oDetalleRespuestaSQL.DESCRIPCION = oEnRespuesta.LstErrores[i].Descripcion;
                            oDetalleRespuestaSQL.IDRESPUESTA = oRespuestaSQL.IDRESPUESTA;
                            dbContext.DETALLERESPUESTA.AddObject(oDetalleRespuestaSQL);
                            dbContext.SaveChanges();
                        }
                    }
                    //p_RegistrarLog("fbol_RegistrarRespuestaSQL", ENLogTci.TipoMensaje.Info, "Se registro la respuesta con estado : " + oRespuestaSQL.IDESTADORESPUESTA.ToString());
                    Logger.Log(Logger.Level.Info,
                        "Se registro la respuesta con estado : " + oRespuestaSQL.IDESTADORESPUESTA);
                    dbContext.Dispose();
                    transactionScope.Complete();
                    return true;
                }
                catch (Exception ex)
                {
                    //p_RegistrarLog("fbol_RegistrarEnvioRespuesta", ENLogTci.TipoMensaje.Error, ex.Message );
                    Logger.Log(Logger.Level.Error, ex.Message);
                    return false;
                }
            }
        }

        //public Boolean fbol_ReenviarDocumento(DLLMapRe.Entidades.EnvioRegistro.ENReenvio oEnReenvio)
        //{
        //    try
        //    {
        //        if (oEnReenvio.lstIdsDocumento == null)
        //        {
        //            p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, "No se han definido documentos para enviar");
        //            return false;
        //        }

        //        p_InicializarConstantes(oEnReenvio.UsuarioSistema, oEnReenvio.GestorBaseDatos, oEnReenvio.DataSource, oEnReenvio.Port, oEnReenvio.InitialCatalog, oEnReenvio.UserID, oEnReenvio.Password);
        //        p_InicializarVariables(oEnReenvio.RutaLog);
        //        p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, "Inicio del método bol_EnvioRegistro");

        //        if (!fbol_LeerConfiguracion(strRutaConfiguracion))
        //        {
        //            p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error, "No se pudo cargar el Archivo de Configuración");
        //            return false;
        //        }

        //        for (int i = 0; i <= oEnReenvio.lstIdsDocumento.Count-1; i++)
        //        {
        //            try
        //            {
        //                 //ACTUALIZAR ENVIO
        //                 intIdEnvio = oEnReenvio.lstIdsDocumento[i];
        //                if (!fnx_RecuperarDatosEnvios(Convert.ToInt32(oEnReenvio.GestorBaseDatos), intIdEnvio, ref strArchivoXML, ref  strNombreArchivo, ref  strPesoArchivo, ref  strMensaje))
        //                  {
        //                      p_RegistrarLog("fnx_RecuperarDatosEnvios", ENLogTci.TipoMensaje.Error, strMensaje);
        //                      return true;
        //                  }

        //                oCustomsDeclarationPeruType = fnx_MapearDocumentoEnvioByte(strArchivoXML);

        //                p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, String.Format("Se mapeo el archivo {0}", strNombreArchivo));
        //                oEnEnvio = fnx_SetearDatosGeneralesReenvio(oEnReenvio, objENxmlSW);

        //                fbol_SetearValores(oCustomsDeclarationPeruType, strArchivoXML, strDirectorioXML, strNombreArchivo, strPesoArchivo, ref oEnDocumentoEnvio, ref oEnviosSQL, ref lstErrores);
        //                oEnEnvio.DocumentoEnvio = oEnDocumentoEnvio;

        //                oEnRespuesta = oLnEnvioRespuesta.bol_EnvioMensaje(oEnEnvio);
        //                p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, String.Format("Se envió el archivo {0}", strNombreArchivo));

        //                intTipoRespuesta = oEnRespuesta.Resultado > 0 ? 1 : 4;

        //                fbol_RegistrarRespuestaSQL(intIdEnvio, oEnRespuesta, intTipoRespuesta);    

        //                p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, String.Format("Se registro el archivo {0}", strNombreArchivo));

        //            }
        //            catch (System.IO.FileNotFoundException e)
        //            {
        //                p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Error, e.Message);
        //            } 
        //        }

        //        p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Info, "Fin del método bol_EnvioRegistro");
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        p_RegistrarLog("fbol_ReenviarDocumento", ENLogTci.TipoMensaje.Error, ex.Message );
        //        return false;
        //    }
        //}

        private Boolean fnx_RecuperarDatosEnvios(Int32 intGestorBaseDatos, Int32 intIdEnvio, ref byte[] strArchivoXML,
            ref string strNombreArchivo, ref Int32 strPesoArchivo, ref string strMensaje)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                ENVIOS oEnvioSQL = (from result in dbContextSQL.ENVIOS
                    where result.IDENVIO == intIdEnvio
                    select result).FirstOrDefault();
                if (oEnvioSQL == null)
                {
                    strMensaje = "El envio no existe";
                    return false;
                }
                strArchivoXML = oEnvioSQL.ARCHIVOXML;
                strNombreArchivo = oEnvioSQL.NOMBREARCHIVO;
                strPesoArchivo = Convert.ToInt32(oEnvioSQL.PESOARCHIVO);
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_RecuperarDatosEnvios", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private TIPOOPERADOR p_ObtenerTipoOperador(string strCodigoTipoOperador)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                TIPOOPERADOR oTipoOperador = (from result in dbContextSQL.TIPOOPERADOR
                    where result.CODTIPOOPERADOR == strCodigoTipoOperador
                    select result).FirstOrDefault();
                if (oTipoOperador == null)
                {
                    return null;
                }

                return oTipoOperador;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("p_ObtenerTipoOperador", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        private TIPOMANIFIESTO p_ObtenerTipoManifiesto(string strCodigoTipoManifiesto)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                TIPOMANIFIESTO oTipoManifiesto = (from result in dbContextSQL.TIPOMANIFIESTO
                    where result.CODTIPOMANIFIESTO == strCodigoTipoManifiesto
                    select result).FirstOrDefault();
                if (oTipoManifiesto == null)
                {
                    return null;
                }

                return oTipoManifiesto;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("p_ObtenerTipoManifiesto", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        private INDULTIMOENVIO p_ObtenerINDUltimoEnvio(string strCodigoIndUltimoEnvio)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                INDULTIMOENVIO oIndUltimoEnvio = (from result in dbContextSQL.INDULTIMOENVIO
                    where result.CODINDULTIMOENVIO == strCodigoIndUltimoEnvio
                    select result).FirstOrDefault();
                if (oIndUltimoEnvio == null)
                {
                    return null;
                }

                return oIndUltimoEnvio;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("p_ObtenerINDUltimoEnvio", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        private VIATRANSPORTE p_ObtenerViaTransporte(string strCodigoViaTransporte)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                VIATRANSPORTE oViaTransporte = (from result in dbContextSQL.VIATRANSPORTE
                    where result.CODVIATRANSPORTE == strCodigoViaTransporte
                    select result).FirstOrDefault();
                if (oViaTransporte == null)
                {
                    return null;
                }

                return oViaTransporte;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("p_ObtenerViaTransporte", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        private TIPOCARGA p_ObtenerTipoCarga(string strCodigoTipoCarga)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);
                TIPOCARGA oTipoCarga = (from result in dbContextSQL.TIPOCARGA
                    where result.CODTIPOCARGA == strCodigoTipoCarga
                    select result).FirstOrDefault();
                if (oTipoCarga == null)
                {
                    return null;
                }

                return oTipoCarga;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("p_ObtenerTipoCarga", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        //public Boolean fbol_RecepcionarRespuestas(DLLMapRe.Entidades.ENDatosGenerales oEnDatosGenerales, ref string strMensaje, ref List<ENRespuestaEnvio> listadoRespuestas)
        //{
        //    try
        //    {

        //        p_InicializarConstantes(oEnDatosGenerales.UsuarioSistema, oEnDatosGenerales.GestorBaseDatos, oEnDatosGenerales.DataSource, oEnDatosGenerales.Port, oEnDatosGenerales.InitialCatalog, oEnDatosGenerales.UserID, oEnDatosGenerales.Password);
        //        p_InicializarVariables(oEnDatosGenerales.RutaLog);

        //        if (!fbol_LeerConfiguracion(strRutaConfiguracion))
        //        {
        //            p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error, "No se pudo cargar el Archivo de Configuración");
        //            return false;
        //        }


        //        oEnLstRespuestas = new ENLstRespuestas();
        //        oEnRespuesta = new ENRespuesta();
        //        oEnMarcarRespuesta = new ENRespuesta();
        //        oEnRecepcionRespuesta = fnx_SetearDatosGeneralesRespuesta(oEnDatosGenerales, objENxmlSW);
        //        oEnLstRespuestas = oLnEnvioRespuesta.bol_ObtenerListadoRespuestas(oEnRecepcionRespuesta);
        //        if (oEnLstRespuestas == null)
        //        {
        //            strMensaje = "Se produjo un problema con la recepción del listado de respuestas";
        //        }
        //        else if (oEnLstRespuestas.LstIdDocumento != null)
        //        {
        //            p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info, String.Format("Se recuperaron {0} respuestas", oEnLstRespuestas.LstIdDocumento.Count));
        //            //for (int i = 0; i <= oEnLstRespuestas.LstIdDocumento.Count - 1; i++)
        //            for (int i = 0; i <= 190; i++)
        //            {

        //                if (i == 188)
        //                {
        //                    String cadena = "forzando marcar la respuesta";
        //                    if (cadena.Length > 10)
        //                    {

        //                    }
        //                }

        //                //DECLARACION: OBJETO LISTADO DICC31/10/2014
        //                ENRespuestaEnvio objEnRespuestaEnvio = new ENRespuestaEnvio();
        //                ENVIOS objEnvios = new ENVIOS();
        //                oEnRecepcionRespuesta.IdTransaccion = oEnLstRespuestas.LstIdDocumento[i];
        //                intIdTransaccion = oEnRecepcionRespuesta.IdTransaccion;
        //                oEnRespuesta = oLnEnvioRespuesta.bol_ObtenerRespuesta(oEnRecepcionRespuesta);
        //                strNumeroOrden = "";

        //                if (oEnRespuesta == null)
        //                {

        //                }
        //                else if (oEnRespuesta.Resultado == -1)
        //                {

        //                }
        //                else
        //                {
        //                    oEnMarcarRespuesta = oLnEnvioRespuesta.bol_MarcarRespuesta(oEnRecepcionRespuesta);

        //                }
        //            }
        //        }
        //        else
        //        {
        //            strMensaje = "No se recuperaron respuestas";
        //        }
        //        strMensaje = "Termino sin errores";
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        strMensaje = ex.Message;
        //        p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Error, ex.Message);
        //        return false;
        //    }
        //}

        public Boolean fbol_RecepcionarRespuestas(ENDatosGenerales oEnDatosGenerales,
            ref string strMensaje, ref List<ENRespuestaEnvio> listadoRespuestas)
        {
            try
            {
               
                p_InicializarConstantes(oEnDatosGenerales.UsuarioSistema, oEnDatosGenerales.GestorBaseDatos,
                    oEnDatosGenerales.DataSource, oEnDatosGenerales.Port, oEnDatosGenerales.InitialCatalog,
                    oEnDatosGenerales.UserID, oEnDatosGenerales.Password);
                //p_InicializarVariables(oEnDatosGenerales.RutaLog);

                Config conf = new Config
                {
                    Servidor = oEnDatosGenerales.DataSource,
                    BaseDatos = oEnDatosGenerales.InitialCatalog,
                    Usuario = oEnDatosGenerales.UserID,
                    Contrasenia = oEnDatosGenerales.Password
                };

                ConfigController.GetConfiguration(conf);

                if (!fbol_LeerConfiguracion(strRutaConfiguracion))
                {
                    //p_RegistrarLog("fbol_EnvioRegistro", ENLogTci.TipoMensaje.Error,
                    //    "No se pudo cargar el Archivo de Configuración");
                    Logger.Log(Logger.Level.Error, "No se pudo cargar el Archivo de Configuración");
                    return false;
                }

                

                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                //    "Inicio del método fbol_RecepcionarRespuestas");
                Logger.Log(Logger.Level.Info, "Inicio del método fbol_RecepcionarRespuestas");

                oEnLstRespuestas = new ENLstRespuestas();
                oEnRespuesta = new ENRespuesta();
                oEnMarcarRespuesta = new ENRespuesta();
                oEnRecepcionRespuesta = fnx_SetearDatosGeneralesRespuesta(oEnDatosGenerales, objENxmlSW);
                oEnLstRespuestas = oLnEnvioRespuesta.bol_ObtenerListadoRespuestas(oEnRecepcionRespuesta);
                if (oEnLstRespuestas == null)
                {
                    strMensaje = "Se produjo un problema con la recepción del listado de respuestas";
                    //p_RegistrarLog("bol_ObtenerListadoRespuestas", ENLogTci.TipoMensaje.Info,
                    //    "Se produjo un problema con la recepción del listado de respuestas");
                    Logger.Log(Logger.Level.Info, "Se produjo un problema con la recepción del listado de respuestas");
                }
                else if (oEnLstRespuestas.LstIdDocumento != null)
                {
                    //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                    //    String.Format("Se recuperaron {0} respuestas", oEnLstRespuestas.LstIdDocumento.Count));
                    Logger.Log(Logger.Level.Info,
                        String.Format("Se recuperaron {0} respuestas", oEnLstRespuestas.LstIdDocumento.Count));
                    for (int i = 0; i <= oEnLstRespuestas.LstIdDocumento.Count - 1; i++)
                    {
                        //DECLARACION: OBJETO LISTADO DICC31/10/2014
                        ENRespuestaEnvio objEnRespuestaEnvio = new ENRespuestaEnvio();
                        ENVIOS objEnvios = new ENVIOS();
                        oEnRecepcionRespuesta.IdTransaccion = oEnLstRespuestas.LstIdDocumento[i];
                        intIdTransaccion = oEnRecepcionRespuesta.IdTransaccion;
                        oEnRespuesta = oLnEnvioRespuesta.bol_ObtenerRespuesta(oEnRecepcionRespuesta);
                        strNumeroOrden = "";

                        if (oEnRespuesta == null)
                        {
                            //p_RegistrarLog("bol_ObtenerRespuesta", ENLogTci.TipoMensaje.Info,
                            //    "Se produjo un problema con la obtención de respuestas");
                            Logger.Log(Logger.Level.Info, "Se produjo un problema con la obtención de respuestas");
                        }
                        else if (oEnRespuesta.Resultado == -1)
                        {
                            //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                            //    String.Format("No se recupero DLLMapRe.Entidades.respuesta para la transacción :  {0}",
                            //        oEnRecepcionRespuesta.IdTransaccion));
                            Logger.Log(Logger.Level.Info,
                                String.Format("No se recupero DLLMapRe.Entidades.respuesta para la transacción :  {0}",
                                    oEnRecepcionRespuesta.IdTransaccion));

                            if (oEnDatosGenerales.RegistrarDatos)
                            {
                                if (
                                    !fnx_RecuperarIdEnvio(Convert.ToInt32(oEnDatosGenerales.GestorBaseDatos),
                                        intIdTransaccion, ref intIdEnvio, ref strMensaje))
                                {
                                    //p_RegistrarLog("fnx_RecuperarIdEnvio", ENLogTci.TipoMensaje.Info, strMensaje);
                                    Logger.Log(Logger.Level.Info, strMensaje);
                                    continue;
                                }
                                fbol_RegistrarRespuestaSQL(intIdEnvio, oEnRespuesta, 4);
                            }

                        }
                        else
                        {

                            if (oEnDatosGenerales.RegistrarDatos)
                            {
                                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                //    String.Format("Se procesará el archivo : {0} ", oEnRespuesta.NombreDocumentoRespuesta));
                                Logger.Log(Logger.Level.Info,
                                    String.Format("Se procesará el archivo : {0} ",
                                        oEnRespuesta.NombreDocumentoRespuesta));
                                // INICIALIZACION DE INDICADOR DE REGISTRO DICC 31/10/2014
                                objEnRespuestaEnvio.Registrado = false;


                                if (oEnRespuesta.NombreDocumentoRespuesta.ToLower().StartsWith("acuse"))
                                {
                                    //oEnRespuesta.DocumentoRespuesta = File.ReadAllBytes(@"C:\Users\dcastillo\Desktop\dinet\acuse_1131964.xml");

                                    if (fbol_RegistrarAcuse(Convert.ToInt32(oEnDatosGenerales.GestorBaseDatos),
                                        oEnRespuesta.NombreDocumentoRespuesta, oEnRespuesta.DocumentoRespuesta,
                                        oEnRespuesta.Resultado, ref objEnvios))
                                    {
                                        oEnMarcarRespuesta = oLnEnvioRespuesta.bol_MarcarRespuesta(oEnRecepcionRespuesta);
                                        //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                        //    String.Format(
                                        //        "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                        //        oEnRecepcionRespuesta.IdTransaccion.ToString()));

                                        Logger.Log(Logger.Level.Info, String.Format(
                                            "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                            oEnRecepcionRespuesta.IdTransaccion));

                                        //SETEO DE NOMBRE DE RESPUESTA XML DICC 31/10/2014
                                        objEnRespuestaEnvio.Registrado = true;
                                        objEnRespuestaEnvio.NombreArchivoXML = oEnRespuesta.NombreDocumentoRespuesta;
                                    }
                                }
                                else if (oEnRespuesta.NombreDocumentoRespuesta.ToLower().StartsWith("nsigad"))
                                {

                                    //////Pruebas ////////////////////////////////////////////
                                    //oEnRespuesta.DocumentoRespuesta = File.ReadAllBytes(@"C:\Users\rbolanos\Downloads\nsigad_response_201514363666800401153063.xml");
                                    ///////////////////////////////////////////////////////

                                    //oResponsePeruType = fnx_MapearXMLRespuesta(oEnRespuesta.DocumentoRespuesta);

                                    //if (oResponsePeruType != null)
                                    //{
                                    bolResultado = fbol_RegistrarArchivoRespuestaSQL(oResponsePeruType,
                                        oEnRespuesta.NombreDocumentoRespuesta, oEnRespuesta.DocumentoRespuesta,
                                        oEnRespuesta.Resultado, ref objEnvios);

                                    if (bolResultado)
                                    {
                                        oEnMarcarRespuesta = oLnEnvioRespuesta.bol_MarcarRespuesta(oEnRecepcionRespuesta);
                                        //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                        //    String.Format(
                                        //        "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                        //        oEnRecepcionRespuesta.IdTransaccion.ToString()));

                                        Logger.Log(Logger.Level.Info, String.Format(
                                            "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                            oEnRecepcionRespuesta.IdTransaccion));

                                        //SETEO INDICADOR DEL REGISTRO DICC 31/10/2014
                                        objEnRespuestaEnvio.Registrado = true;


                                    }
                                    else
                                    {
                                        //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Error,
                                        //    String.Format("El archivo : {0}  no ha sido generado correctamente ",
                                        //        oEnRespuesta.NombreDocumentoRespuesta));
                                        Logger.Log(Logger.Level.Error,
                                            String.Format("El archivo : {0}  no ha sido generado correctamente ",
                                                oEnRespuesta.NombreDocumentoRespuesta));
                                        oEnMarcarRespuesta = oLnEnvioRespuesta.bol_MarcarRespuesta(oEnRecepcionRespuesta);
                                        //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                        //    String.Format(
                                        //        "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                        //        oEnRecepcionRespuesta.IdTransaccion.ToString()));
                                        Logger.Log(Logger.Level.Info, String.Format(
                                            "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                            oEnRecepcionRespuesta.IdTransaccion));
                                    }
                                }
                                //JPT - 27/11/2014
                                if (objEnvios != null)
                                    objEnRespuestaEnvio.NumeroOrden = objEnvios.NUMEROORDEN;
                            }
                            else
                            {
                                oEnMarcarRespuesta = oLnEnvioRespuesta.bol_MarcarRespuesta(oEnRecepcionRespuesta);
                                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                //    String.Format("Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                //        oEnRecepcionRespuesta.IdTransaccion.ToString()));
                                Logger.Log(Logger.Level.Info,
                                    String.Format("Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                        oEnRecepcionRespuesta.IdTransaccion));

                            }



                            if (oEnDatosGenerales.GuardarRespuesta)
                            {
                                string nombreArchivo = oEnRespuesta.NombreDocumentoRespuesta;
                                fnx_WriteFile(oEnDatosGenerales.RutaGuardarRespuesta, ref nombreArchivo,
                                    oEnRespuesta.DocumentoRespuesta, objEnvios, oEnDatosGenerales.CrearJeraquiaRespuesta);
                                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info,
                                //    String.Format("Se guardo el archivo : {0} en la ruta : {1} ",
                                //        oEnRespuesta.NombreDocumentoRespuesta, oEnDatosGenerales.RutaGuardarRespuesta));

                                Logger.Log(Logger.Level.Info,
                                    String.Format("Se guardo el archivo : {0} en la ruta : {1} ",
                                        oEnRespuesta.NombreDocumentoRespuesta, oEnDatosGenerales.RutaGuardarRespuesta));

                                //SETEO RESPUESTA DESCARGADA ,NOMBRE DE LA RESPUESTA DICC 31/10/2014
                                objEnRespuestaEnvio.NombreArchivoXML = nombreArchivo;
                                objEnRespuestaEnvio.Descargado = true;
                            }
                            else
                            {
                                //SETEO RESPUESTA NO DESCARGADA DICC 31/10/2014
                                objEnRespuestaEnvio.Descargado = false;
                            }



                            listadoRespuestas.Add(objEnRespuestaEnvio);
                        }
                    }
                }
                else
                {
                    strMensaje = "No se recuperaron respuestas";
                    //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info, "No se recuperaron respuestas");
                    Logger.Log(Logger.Level.Info, "No se recuperaron respuestas");
                }
                strMensaje = "Termino sin errores";
                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Info, "Fin del método fbol_RecepcionarRespuestas");
                Logger.Log(Logger.Level.Info, "Fin del método fbol_RecepcionarRespuestas");
                return true;
            }
            catch (Exception ex)
            {
                strMensaje = ex.Message;
                //p_RegistrarLog("fbol_RecepcionarRespuestas", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private Boolean fnx_RecuperarIdEnvio(Int32 intGestorBaseDatos, Int32 IdTransaccion, ref Int32 intIdEnvio,
            ref string strMensaje)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSQL = new DBAPPTAGSQLEntities(strCadenaConexion);

                ENVIOS oEnvioSQL =
                    (from result in dbContextSQL.ENVIOS where result.IDTRANSACCION == IdTransaccion select result)
                        .FirstOrDefault();
                if (oEnvioSQL == null)
                {
                    strMensaje = "El envio no existe";
                    return false;
                }
                intIdEnvio = oEnvioSQL.IDENVIO;

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_RecuperarIdEnvio", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }

        }

        private Boolean fbol_RegistrarAcuse(Int32 intGestorBaseDatos, string strNombreArchivo, byte[] byteArchivo,
            Int32 intIdTransaccion, ref ENVIOS objEnvios)
        {
            try
            {
                string fechaRecepcion = string.Empty;
                string ticketEnvio = string.Empty;
                DataTable dtErrores = new DataTable();
                DataRow drError;
                XmlDocument xmlAcuse = new XmlDocument();
                MemoryStream msAcuse = new MemoryStream(byteArchivo);
                xmlAcuse.Load(msAcuse);

                dtErrores.Columns.Add("codigo");
                dtErrores.Columns.Add("descripcion");
                foreach (XmlNode NodoPadre in xmlAcuse.ChildNodes)
                {
                    if (NodoPadre is XmlElement)
                    {
                        foreach (XmlNode NodoHijo in NodoPadre.ChildNodes)
                        {
                            if (NodoHijo is XmlElement)
                            {
                                if (NodoHijo.Name.ToLower().Equals("anhoenvio"))
                                {
                                    ticketEnvio = NodoHijo.InnerText;
                                }
                                if (NodoHijo.Name.ToLower().Equals("fecharecepcion"))
                                {
                                    fechaRecepcion = NodoHijo.InnerText;
                                }
                                if (NodoHijo.Name.ToLower().Equals("ticketenvio"))
                                {
                                    ticketEnvio = ticketEnvio + NodoHijo.InnerText;
                                }
                                if (NodoHijo.Name.ToLower().Equals("listaerrores"))
                                {

                                    foreach (XmlNode NodoError in NodoHijo.ChildNodes)
                                    {
                                        if (NodoError is XmlElement)
                                        {
                                            drError = dtErrores.NewRow();
                                            foreach (XmlNode NodoDetalles in NodoError.ChildNodes)
                                            {
                                                if (NodoDetalles is XmlElement)
                                                {

                                                    if (NodoDetalles.Name.ToLower().Equals("codigo"))
                                                    {
                                                        drError["codigo"] = NodoDetalles.InnerText;
                                                    }
                                                    if (NodoDetalles.Name.ToLower().Equals("descripcion"))
                                                    {
                                                        drError["descripcion"] = NodoDetalles.InnerText;
                                                    }

                                                }
                                            }
                                            dtErrores.Rows.Add(drError);
                                            dtErrores.AcceptChanges();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                fbol_RegistrarAcuseSQL(intIdTransaccion, fechaRecepcion, ticketEnvio, dtErrores, strNombreArchivo,
                    byteArchivo, ref objEnvios);

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }

        }

        private Boolean fbol_RegistrarAcuseSQL(Int32 intIdTransaccion, string strfechaRecepcion, string strticketEnvio,
            DataTable dtErrores, string strNombreArchivo, byte[] byteArchivo, ref ENVIOS objEnvios)
        {
            try
            {
                using (TransactionScope transactionScope = new TransactionScope())
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(strCadenaConexion);
                    oRespuestaSQL = new RESPUESTA();
                    oDetalleRespuestaSQL = new DETALLERESPUESTA();

                    //ACTUALIZAR ENVIO
                    ENVIOS oEnvio = (from result in dbContext.ENVIOS
                        where result.IDTRANSACCION == intIdTransaccion
                        select result).FirstOrDefault();

                    objEnvios = oEnvio;

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarAcuse", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return true;
                    }
                    //strNumeroOrden = oEnvio.NUMEROORDEN;

                    if (!String.IsNullOrEmpty(strfechaRecepcion))
                    {
                        oEnvio.FECHAACUSE = Convert.ToDateTime(strfechaRecepcion);
                    }

                    oEnvio.NROTICKET = strticketEnvio;
                    oEnvio.IDESTADOACUSE = dtErrores.Rows.Count > 0 ? 8 : 1;
                    dbContext.SaveChanges();
                    //FIN ACTUALIZAR ENVIO

                    //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                    oRespuestaSQL.IDENVIO = oEnvio.IDENVIO;
                    oRespuestaSQL.IDESTADORESPUESTA = dtErrores.Rows.Count > 0 ? 8 : 1;
                    if (!string.IsNullOrEmpty(strfechaRecepcion))
                    {
                        oRespuestaSQL.FECHAACEPTACION = Convert.ToDateTime(strfechaRecepcion);
                    }
                    oRespuestaSQL.IDTIPORESPUESTA = 2;
                    oRespuestaSQL.NOMBREARCHIVO = strNombreArchivo;
                    oRespuestaSQL.ARCHIVOXML = byteArchivo;
                    dbContext.RESPUESTA.AddObject(oRespuestaSQL);
                    dbContext.SaveChanges();
                    //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA

                    for (int i = 0; i <= dtErrores.Rows.Count - 1; i++)
                    {
                        oDetalleRespuestaSQL = new DETALLERESPUESTA();
                        oDetalleRespuestaSQL.IDRESPUESTA = oRespuestaSQL.IDRESPUESTA;
                        oDetalleRespuestaSQL.TIPOMENSAJE = 1;
                        oDetalleRespuestaSQL.CODIGO = dtErrores.Rows[i][0].ToString();
                        oDetalleRespuestaSQL.DESCRIPCION = dtErrores.Rows[i][1].ToString();
                        dbContext.DETALLERESPUESTA.AddObject(oDetalleRespuestaSQL);
                        dbContext.SaveChanges();
                    }

                    dbContext.Dispose();
                    transactionScope.Complete();
                    //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, "se registro correctamente : " + strNombreArchivo);
                    Logger.Log(Logger.Level.Error, "Se registro correctamente : " + strNombreArchivo);
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private Boolean fbol_RegistrarArchivoRespuestaSQL(ResponsePeruType oResponsePeruType, string strNombreArchivo,
            byte[] byteArchivo, Int32 intIdTransaccion, ref ENVIOS objEnvios)
        {

            string strNodoIDEstadoRespuestaEnvio = string.Empty;
            string strNodoIDEstadoRespuesta = string.Empty;
            string strNodoFechaAceptacion = string.Empty;
            string strNodoFechaRespuesta = string.Empty;


            try
            {
                using (TransactionScope transactionScope = new TransactionScope())
                {

                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(strCadenaConexion);
                    oRespuestaSQL = new RESPUESTA();
                    oDetalleRespuestaSQL = new DETALLERESPUESTA();

                    Boolean bolValidacion = false;
                    Boolean bol0101 = false;
                    Boolean bolReportedProcessingResult = false;

                    //ACTUALIZAR DATOS DEL ENVIO
                    ENVIOS oEnvio = (from result in dbContext.ENVIOS
                        where result.IDTRANSACCION == intIdTransaccion
                        select result).FirstOrDefault();

                    objEnvios = oEnvio;

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return true;
                    }



                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////////////////////////////////////////////////////////// LECTURA DEL ARCHIVO RESPUESTA POR NODOS ////////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    // Cargar el archivo XML                              
                    XmlDocument xDoc = new XmlDocument();
                    MemoryStream ms = new MemoryStream(byteArchivo);

                    xDoc.Load(ms);

                    foreach (XmlNode NodoPadre in xDoc.ChildNodes)
                    {
                        if (NodoPadre is XmlElement && NodoPadre.Name.Equals("rsm:ResponsePeru"))
                        {

                            // TAG "rsm:SpecifiedExchangedDocumentContext"
                            if (fint_ObtenerRepeticionesHijosXML(NodoPadre, "rsm:SpecifiedExchangedDocumentContext") ==
                                0)
                            {
                                strMensaje =
                                    "Tag Mandatorio no fue encontrado: rsm:SpecifiedExchangedDocumentContext en " +
                                    NodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, strMensaje);
                                return false;
                            }

                            // TAG "rsm:ReportedProcessingResult"
                            if (fint_ObtenerRepeticionesHijosXML(NodoPadre, "rsm:ReportedProcessingResult") > 0)
                            {
                                bolReportedProcessingResult = true;
                            }

                            // TAG "rsm:HeaderExchangedDocument"
                            if (fint_ObtenerRepeticionesHijosXML(NodoPadre, "rsm:HeaderExchangedDocument") == 0)
                            {
                                strMensaje = "Tag Mandatorio no fue encontrado: rsm:HeaderExchangedDocument en " +
                                             NodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, strMensaje);
                                return false;
                            }

                            foreach (XmlNode NodoH1 in NodoPadre.ChildNodes)
                            {
                                if (NodoH1 is XmlElement)
                                {
                                    switch (NodoH1.Name)
                                    {
                                        case "rsm:SpecifiedExchangedDocumentContext":

                                            if (
                                                fint_ObtenerRepeticionesHijosXML(NodoH1, "ram:SpecifiedTransactionID") ==
                                                0)
                                            {
                                                strMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:SpecifiedTransactionID en " +
                                                    NodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                return false;
                                            }
                                            else
                                            {
                                                foreach (XmlNode NodoH2 in NodoH1.ChildNodes)
                                                {
                                                    if (NodoH2 is XmlElement &&
                                                        NodoH2.Name.ToString().Equals("ram:SpecifiedTransactionID"))
                                                    {
                                                        if (NodoH2.InnerText.Equals("0101"))
                                                        {
                                                            bol0101 = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }

                                            break;
                                        case "rsm:HeaderExchangedDocument":



                                            if (fint_ObtenerRepeticionesHijosXML(NodoH1, "ram:StatusCode") == 0)
                                            {
                                                strMensaje = "Tag Mandatorio no fue encontrado: ram:StatusCode en " +
                                                             NodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                return false;
                                            }
                                            else
                                            {



                                                strNodoIDEstadoRespuestaEnvio =
                                                    fstr_ObtenerValorEtiquetaHijoXML(NodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");
                                                strNodoIDEstadoRespuesta =
                                                    fstr_ObtenerValorEtiquetaHijoXML(NodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuestaEnvio))
                                                {
                                                    oEnvio.IDESTADORESPUESTA =
                                                        Convert.ToInt32(strNodoIDEstadoRespuestaEnvio);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuesta))
                                                {
                                                    oRespuestaSQL.IDESTADORESPUESTA =
                                                        Convert.ToInt32(strNodoIDEstadoRespuesta);
                                                }

                                            }

                                            if (fint_ObtenerRepeticionesHijosXML(NodoH1, "ram:AcceptanceDateTime") == 0)
                                            {
                                                strMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:AcceptanceDateTime en " +
                                                    NodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Info, strMensaje);
                                                Logger.Log(Logger.Level.Info, strMensaje);
                                                oRespuestaSQL.FECHAACEPTACION = null;
                                                oEnvio.FECHARESPUESTA = null;
                                            }
                                            else
                                            {
                                                strNodoFechaAceptacion = fstr_ObtenerValorEtiquetaHijoXML(NodoH1,
                                                    "ram:AcceptanceDateTime");
                                                strNodoFechaRespuesta = fstr_ObtenerValorEtiquetaHijoXML(NodoH1,
                                                    "ram:AcceptanceDateTime");

                                                if (!string.IsNullOrEmpty(strNodoFechaAceptacion))
                                                {
                                                    oRespuestaSQL.FECHAACEPTACION =
                                                        Convert.ToDateTime(strNodoFechaAceptacion);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoFechaRespuesta))
                                                {
                                                    oEnvio.FECHARESPUESTA = Convert.ToDateTime(strNodoFechaRespuesta);
                                                }

                                            }
                                            break;

                                        case "rsm:ReportedProcessingResult":

                                            // TAG SpecifiedGoodsClearanceResult
                                            if (
                                                fint_ObtenerRepeticionesHijosXML(NodoH1,
                                                    "userram:SpecifiedGoodsClearanceResult") == 0)
                                            {
                                                strMensaje =
                                                    "Tag Mandatorio no fue encontrado: userram:SpecifiedGoodsClearanceResult en " +
                                                    NodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                return false;
                                            }


                                            foreach (XmlNode NodoH2 in NodoH1.ChildNodes)
                                            {
                                                if (NodoH2 is XmlElement)
                                                {
                                                    switch (NodoH2.Name)
                                                    {
                                                        case "userram:SpecifiedGoodsClearanceResult":

                                                            // Número de declaración /manifiesto generada por aduanas  
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(NodoH2,
                                                                    "userram:CustomsID") == 0)
                                                            {
                                                                strMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:CustomsID en " +
                                                                    NodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (bol0101 = true)
                                                                {
                                                                    oEnvio.NROCORRELATIVO =
                                                                        fstr_ObtenerValorEtiquetaHijoXML(NodoH2,
                                                                            "userram:CustomsID");
                                                                }
                                                                oRespuestaSQL.NUMECORRE =
                                                                    fstr_ObtenerValorEtiquetaHijoXML(NodoH2,
                                                                        "userram:CustomsID");
                                                            }

                                                            // Mensaje de notificación
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(NodoH2,
                                                                    "userram:Information") == 0)
                                                            {
                                                                strMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:Information en " +
                                                                    NodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                oRespuestaSQL.MENSAJENOTIFICACION =
                                                                    oclsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(NodoH2,
                                                                            "userram:Information"));
                                                            }

                                                            // Tipo de documento según CDA
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(NodoH2,
                                                                    "userram:TypeCode") == 0)
                                                            {
                                                                strMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:TypeCode en " +
                                                                    NodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                oRespuestaSQL.TDOCCDA =
                                                                    oclsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(NodoH2,
                                                                            "userram:TypeCode"));
                                                            }

                                                            // Año de la declaración / manifiesto generada por aduanas
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(NodoH2,
                                                                    "userram:AcceptanceDateTime") == 0)
                                                            {
                                                                strMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:AcceptanceDateTime en " +
                                                                    NodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, strMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (
                                                                    IsDate(
                                                                        oclsValidacionDatos.fstr_ObtenDato(
                                                                            fstr_ObtenerValorEtiquetaHijoXML(NodoH2,
                                                                                "userram:AcceptanceDateTime")),
                                                                        ref strMensaje))
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        oEnvio.FECHADECLARACION =
                                                                            Convert.ToDateTime(
                                                                                oclsValidacionDatos.fstr_ObtenDato(
                                                                                    fstr_ObtenerValorEtiquetaHijoXML(
                                                                                        NodoH2,
                                                                                        "userram:AcceptanceDateTime")));
                                                                    }
                                                                    oRespuestaSQL.FECHANUMERACION =
                                                                        Convert.ToDateTime(
                                                                            oclsValidacionDatos.fstr_ObtenDato(
                                                                                fstr_ObtenerValorEtiquetaHijoXML(
                                                                                    NodoH2, "userram:AcceptanceDateTime")));
                                                                }
                                                                else
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        oErrorEnvioSQL =
                                                                            new ERRORENVIO();
                                                                        oErrorEnvioSQL.IDENVIO = oEnvio.IDENVIO;
                                                                        oErrorEnvioSQL.DESCRIPCION = strMensaje;
                                                                        oErrorEnvioSQL.FECHAREGISTRO = DateTime.Now;
                                                                        dbContext.ERRORENVIO.AddObject(oErrorEnvioSQL);
                                                                        dbContext.SaveChanges();
                                                                    }
                                                                }
                                                            }
                                                            break;

                                                    }
                                                }
                                            }

                                            break;

                                    }
                                }
                            }


                            //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                            oRespuestaSQL.IDENVIO = oEnvio.IDENVIO;
                            oRespuestaSQL.IDTIPORESPUESTA = 3; //RESPUESTA
                            oRespuestaSQL.NOMBREARCHIVO = strNombreArchivo;
                            oRespuestaSQL.ARCHIVOXML = byteArchivo;
                            oRespuestaSQL.FECHAREGISTRO = DateTime.Now;

                            dbContext.RESPUESTA.AddObject(oRespuestaSQL);
                            dbContext.SaveChanges();
                            //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA



                            //SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            if (oEnvio.IDESTADORESPUESTA != 8 && oEnvio.IDESTADORESPUESTA != 24)
                            {
                                if (!bolReportedProcessingResult)
                                {
                                    strMensaje = "Tag Mandatorio no fue encontrado: rsm:ReportedProcessingResult en " +
                                                 NodoPadre.Name;
                                    bolValidacion = false;
                                }
                                else
                                {
                                    // Detalle de la RPTA Correcta
                                    if (!fbol_RegistrarDetalleRespuesta(dbContext))
                                    {
                                        //p_RegistrarLog("fbol_RegistrarDetalleRespuesta", ENLogTci.TipoMensaje.Error, "Ocurrió un problema durante el registro del detalle de la respuesta");
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro del detalle de la respuesta");
                                        return false;
                                    }

                                    //Informacion de RPTA Correcta
                                    if (!fbol_RegistrarInformacionDetalleRespuesta(xDoc, dbContext))
                                    {
                                        //p_RegistrarLog("fbol_RegistrarInformacionDetalleRespuesta", ENLogTci.TipoMensaje.Error, "Ocurrió un problema durante el registro de la información de la respuesta");
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro de la información de la respuesta");
                                        return false;
                                    }

                                    //Registrar CanalMaster
                                    if (oEnvio.CODADUANADECLARACION.Equals(@"118") &&
                                        oEnvio.CODTIPOTRANSACCION.Equals(@"0109"))
                                    {
                                        var canalMaster = new CanalMaster()
                                        {
                                            CodigoAduana = oEnvio.CODADUANADECLARACION,
                                            AnioManifiesto = oEnvio.ANIOMANIFIESTO,
                                            NumeroManifiesto = oEnvio.NROMANIFIESTO,
                                            BlMaster = oEnvio.NRODOCUMENTOTRANSPORTE
                                        };
                                        var result = RegistrarCanalMaster(dbContext, canalMaster);
                                        //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Info,
                                        //    result.Valor.Equals("success")
                                        //        ? string.Format(@"Manifiesto {0}-{1}-{2} registrado en CanalMaster.",
                                        //            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                                        //            canalMaster.NumeroManifiesto)
                                        //        : string.Format(
                                        //            @"El manifiesto {0}-{1}-{2} ya se encuentra registrado en CanalMaster.",
                                        //            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                                        //            canalMaster.NumeroManifiesto));

                                        Logger.Log(Logger.Level.Info, result.Valor.Equals("success")
                                            ? string.Format(@"Manifiesto {0}-{1}-{2} registrado en CanalMaster.",
                                                canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                                                canalMaster.NumeroManifiesto)
                                            : string.Format(
                                                @"El manifiesto {0}-{1}-{2} ya se encuentra registrado en CanalMaster.",
                                                canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                                                canalMaster.NumeroManifiesto));
                                    }
                                }
                            }
                            else
                            {
                                if (!fbol_RegistrarErroresDetalleRespuesta(xDoc, dbContext))
                                {
                                    //p_RegistrarLog("fbol_RegistrarErroresDetalleRespuesta", ENLogTci.TipoMensaje.Error, "Ocurrió un problema durante el registro de errores de la respuesta");
                                    Logger.Log(Logger.Level.Error,
                                        "Ocurrió un problema durante el registro de errores de la respuesta");
                                    return false;
                                }
                            }


                            //REGISTRO DE ADVERTENCIAS
                            if (!fbol_RegistrarWarningsDetalleRespuesta(xDoc, dbContext))
                            {
                                //p_RegistrarLog("fbol_RegistrarWarningsDetalleRespuesta", ENLogTci.TipoMensaje.Error, "Ocurrió un problema durante el registro de advertencias de la respuesta");
                                Logger.Log(Logger.Level.Error,
                                    "Ocurrió un problema durante el registro de advertencias de la respuesta");
                                return false;
                            }


                            //FIN SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            dbContext.Dispose();
                            transactionScope.Complete();
                            //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Info, "se registro correctamente : " + strNombreArchivo);
                            Logger.Log(Logger.Level.Info, "Se registro correctamente : " + strNombreArchivo);

                        }
                    }
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////////////////////////////////////////////////////// FIN LECTURA DEL ARCHIVO RESPUESTA POR NODOS ////////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                    return true;
                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }


        #region "SETEAR VALORES"

        private bool IsDate(string sdate, ref string strMensaje)
        {
            bool isDate = true;
            try
            {
                DateTime.Parse(sdate);
            }
            catch (Exception ex)
            {
                strMensaje = ex.Message;
                isDate = false;
            }

            return isDate;
        }



        private void AsignarValoresConEsquemaCustomsManifestPeru(OACustomsManifestPeru oCustomsDeclarationPeruType, byte[] byteArchivo,
            string strDirectorioXML, string strNombreXML, long? intLongitud, ref ENDocumentoEnvio oEnDocumentoEnvio,
            ref ENVIOS oEnviosSQL, ref List<string> strLstError)
        {
            try
            {
                oEnviosSQL = new ENVIOS(); // Objeto Envios EF
                Int32 intIdTipoOperador;
                Int32 intIdTipoManifiesto;
                Int32? intIdIndUltimoEnvio;
                Int32? intIdTipoCarga;
                Int32 intIdViaTransporte;
                Int32 intCantidad = 0;

                oEnDocumentoEnvio = new ENDocumentoEnvio // Objeto TransWeb
                {
                    CodTransaccion =
                        oclsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext.SpecifiedTransactionID.Value),
                    FechaCreacion = DateTime.Now,
                    Documento = byteArchivo ?? FileToByteArray(strDirectorioXML + @"\" + strNombreXML),
                    NombreDocumento = strNombreXML,
                    Longitud = Convert.ToInt32(intLongitud)
                };

                oEnviosSQL.FECHAIMPORTACION = DateTime.Now;
                oEnviosSQL.PESOARCHIVO = Convert.ToInt32(intLongitud);
                oEnviosSQL.ARCHIVOXML = oEnDocumentoEnvio.Documento;
                oEnviosSQL.NOMBREARCHIVO = strNombreXML;

                if (oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext != null)
                {
                    oEnviosSQL.CODTIPOTRANSACCION =
                        oclsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext.SpecifiedTransactionID.Value);
                }

                if (oCustomsDeclarationPeruType.HeaderExchangedDocument != null)
                {
                    if (IsDate(oCustomsDeclarationPeruType.HeaderExchangedDocument.IssueDateTime.ToString(),
                        ref strMensaje))
                    {
                        oEnviosSQL.FECHAGENERACION = oCustomsDeclarationPeruType.HeaderExchangedDocument.IssueDateTime;
                    }
                    else
                    {
                        strLstError.Add(strMensaje);
                    }

                    oEnviosSQL.NUMEROORDEN =
                        oclsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.HeaderExchangedDocument.TraderAssignedID[0].Value);
                    oEnviosSQL.RUCAGENTEADUANA =
                        oclsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.HeaderExchangedDocument.SenderTradeParty.ID[0].Value);

                    intIdTipoOperador =
                        p_ObtenerTipoOperador(
                            oclsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.HeaderExchangedDocument.SenderTradeParty.TypeCode[0].Value))
                            .IDTIPOOPERADOR;
                    oEnviosSQL.IDTIPOOPERADOR = intIdTipoOperador;

                }

                if (oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement != null)
                {
                    intIdViaTransporte =
                        p_ObtenerViaTransporte(
                            oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement.ModeCode.Value.ToString()
                                .Replace("Item", "")).IDVIATRANSPORTE;
                    oEnviosSQL.IDVIATRANSPORTE = intIdViaTransporte;

                    if (
                        oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                            .ManifestRelatedReferencedDocument != null)
                    {
                        oEnviosSQL.NROMANIFIESTO =
                            oclsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].ID[0].Value);
                        oEnviosSQL.ANIOMANIFIESTO =
                            oclsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].AcceptanceDateTime.Year.ToString(
                                        CultureInfo.InvariantCulture));

                        intIdTipoManifiesto =
                            p_ObtenerTipoManifiesto(
                                oclsValidacionDatos.fstr_ObtenDato(
                                    oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                        .ManifestRelatedReferencedDocument[0].CategoryCode.Value)).IDTIPOMANIFIESTO;
                        oEnviosSQL.IDTIPOMANIFIESTO = intIdTipoManifiesto;

                        oEnviosSQL.CODADUANADECLARACION =
                            oclsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].LodgementLogisticsLocation.ID[0].Value);
                    }
                }


                if (oCustomsDeclarationPeruType.SpecifiedSupplyChainConsignment != null)
                {
                    foreach (
                        SupplyChainConsignmentType objSpecifiedSupplyChainConsignment in
                            oCustomsDeclarationPeruType.SpecifiedSupplyChainConsignment)
                    {
                        oEnviosSQL.NRODETALLE = (int?) objSpecifiedSupplyChainConsignment.SequenceNumeric;

                        if (objSpecifiedSupplyChainConsignment.TransportContractReferencedDocument != null)
                        {
                            oEnviosSQL.NRODOCUMENTOTRANSPORTE =
                                objSpecifiedSupplyChainConsignment.TransportContractReferencedDocument.ID[0].Value;
                        }

                        if (objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus != null)
                        {
                            if (
                                !string.IsNullOrEmpty(
                                    objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus[0].ConditionCode.Value))
                            {
                                intIdIndUltimoEnvio =
                                    p_ObtenerINDUltimoEnvio(
                                        objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus[0].ConditionCode
                                            .Value).IDINDULTIMOENVIO;
                                oEnviosSQL.IDINDULTIMOENVIO = intIdIndUltimoEnvio;
                            }
                            if (
                                !string.IsNullOrEmpty(
                                    objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value))
                            {
                                intIdTipoCarga =
                                    p_ObtenerTipoCarga(
                                        objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value)
                                        .IDTIPOCARGA;
                                oEnviosSQL.IDTIPOCARGA = intIdTipoCarga;

                                switch (objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value)
                                {
                                    case "07": //Chasis
                                        if (objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem !=
                                            null)
                                        {
                                            intCantidad =
                                                objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem
                                                    .Count();
                                        }
                                        break;
                                    case "09": //Contenerizada
                                        if (objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem !=
                                            null)
                                        {
                                            intCantidad =
                                                objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem
                                                    .Count();
                                        }
                                        break;

                                }
                                oEnviosSQL.CANTIDADCARGA = intCantidad;
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_SetearValores", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }


        private Boolean AsignarValoresSinEsquemaCustomsManifestPeru(byte[] byteArchivo, string strDirectorioXML, string strNombreXML,
            Nullable<Int64> intLongitud, ref ENDocumentoEnvio oEnDocumentoEnvio,
            ref ENVIOS oEnviosSQL, ref List<string> strLstError)
        {
            try
            {
                oEnviosSQL = new ENVIOS();
                oEnDocumentoEnvio = new ENDocumentoEnvio();

                strLstError = new List<string>();

                ///Setear Datos para el Envio
                oEnDocumentoEnvio.CodTransaccion = "";
                oEnDocumentoEnvio.FechaCreacion = DateTime.Now;
                oEnDocumentoEnvio.Documento = byteArchivo != null
                    ? byteArchivo
                    : FileToByteArray(strDirectorioXML + @"\" + strNombreXML);
                oEnDocumentoEnvio.NombreDocumento = strNombreXML;
                oEnDocumentoEnvio.Longitud = Convert.ToInt32(intLongitud);
                ///Fin Setear Datos para el Envio

                ///Setear Datos para el Registro
                oEnviosSQL.FECHAIMPORTACION = DateTime.Now;
                oEnviosSQL.PESOARCHIVO = Convert.ToInt32(intLongitud);
                oEnviosSQL.NUMEROORDEN = "";

                //DICC 30032015
                oEnviosSQL.RUCAGENTEADUANA = "";

                oEnviosSQL.ARCHIVOXML = oEnDocumentoEnvio.Documento;
                oEnviosSQL.NOMBREARCHIVO = strNombreXML;

                oEnviosSQL.NROMANIFIESTO = "";
                oEnviosSQL.ANIOMANIFIESTO = "";
                oEnviosSQL.NRODOCUMENTOTRANSPORTE = "";

                ///Fin Setear Datos para el Registro 

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_SetearValores", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private ENEnvio fnx_SetearDatosGeneralesEnvio(ENEnvioRegistro oENEnvioRegistro, ENxmlSW objENxmlSW)
        {
            oEnEnvio = new ENEnvio();
            oEnEnvio.Casilla = ConfigController.Conf.Casilla; //objENxmlSW.Casilla;
            oEnEnvio.PwdCasilla = ConfigController.Conf.Pwdcasilla; //objENxmlSW.PwdCasilla;
            oEnEnvio.UsuarioSistema = oENEnvioRegistro.UsuarioSistema;
            oEnEnvio.IdUsuarioSistema = oENEnvioRegistro.IdUsuarioSistema;
            oEnEnvio.IndicadorProxy = oENEnvioRegistro.IndicadorProxy;
            oEnEnvio.IpProxy = oENEnvioRegistro.IpProxy;
            oEnEnvio.PuertoProxy = oENEnvioRegistro.PuertoProxy;
            oEnEnvio.UsuarioProxy = oENEnvioRegistro.UsuarioProxy;
            oEnEnvio.PwdUsuarioProxy = oENEnvioRegistro.PwdUsuarioProxy;
            oEnEnvio.Dominio = oENEnvioRegistro.Dominio;
            oEnEnvio.UrlSatServer = ConfigController.Conf.UrlSatServer; //objENxmlSW.UrlSatServer;
            oEnEnvio.UrlSatServerAlternativa = ConfigController.Conf.UrlSatServerAlternativa; //objENxmlSW.UrlSatServerAlternativa;
            oEnEnvio.RutaLog = ConfigController.Conf.RutaLog;  //oENEnvioRegistro.RutaLog;
            oEnEnvio.TimeOut = ConfigController.Conf.TimeOut; //objENxmlSW.TimeOut;
            return oEnEnvio;
        }

        private ENEnvio fnx_SetearDatosGeneralesReenvio(ENReenvio oENReenvio, ENxmlSW objENxmlSW)
        {
            oEnEnvio = new ENEnvio();
            oEnEnvio.Casilla = objENxmlSW.Casilla;
            oEnEnvio.PwdCasilla = objENxmlSW.PwdCasilla;
            oEnEnvio.UsuarioSistema = oENReenvio.UsuarioSistema;
            oEnEnvio.IdUsuarioSistema = oENReenvio.IdUsuarioSistema;
            oEnEnvio.IndicadorProxy = oENReenvio.IndicadorProxy;
            oEnEnvio.IpProxy = oENReenvio.IpProxy;
            oEnEnvio.UsuarioProxy = oENReenvio.UsuarioProxy;
            oEnEnvio.PwdUsuarioProxy = oENReenvio.PwdUsuarioProxy;
            oEnEnvio.Dominio = oENReenvio.Dominio;
            oEnEnvio.UrlSatServer = objENxmlSW.UrlSatServer;
            oEnEnvio.UrlSatServerAlternativa = objENxmlSW.UrlSatServerAlternativa;
            oEnEnvio.RutaLog = oENReenvio.RutaLog;
            return oEnEnvio;
        }

        private ENRecepcionRespuesta fnx_SetearDatosGeneralesRespuesta(
            ENDatosGenerales oEnDatosGenerales, ENxmlSW objENxmlSW)
        {
            oEnRecepcionRespuesta = new ENRecepcionRespuesta();
            oEnRecepcionRespuesta.Casilla = ConfigController.Conf.Casilla;//objENxmlSW.Casilla;
            oEnRecepcionRespuesta.PwdCasilla = ConfigController.Conf.Pwdcasilla; //objENxmlSW.PwdCasilla;
            oEnRecepcionRespuesta.UsuarioSistema = oEnDatosGenerales.UsuarioSistema;
            oEnRecepcionRespuesta.IdUsuarioSistema = oEnDatosGenerales.IdUsuarioSistema;
            oEnRecepcionRespuesta.IndicadorProxy = oEnDatosGenerales.IndicadorProxy;
            oEnRecepcionRespuesta.IpProxy = oEnDatosGenerales.IpProxy;
            oEnRecepcionRespuesta.UsuarioProxy = oEnDatosGenerales.UsuarioProxy;
            oEnRecepcionRespuesta.PwdUsuarioProxy = oEnDatosGenerales.PwdUsuarioProxy;
            oEnRecepcionRespuesta.Dominio = oEnDatosGenerales.Dominio;
            oEnRecepcionRespuesta.UrlSatServer = ConfigController.Conf.UrlSatServer; //objENxmlSW.UrlSatServer;
            oEnRecepcionRespuesta.UrlSatServerAlternativa = ConfigController.Conf.UrlSatServerAlternativa; //objENxmlSW.UrlSatServerAlternativa;
            oEnRecepcionRespuesta.RutaLog = ConfigController.Conf.RutaLog;  //oEnDatosGenerales.RutaLog;
            oEnRecepcionRespuesta.TimeOut = ConfigController.Conf.TimeOut; //objENxmlSW.TimeOut;
            return oEnRecepcionRespuesta;
        }

        #endregion

        #region "MAPEO DE XML"


        private OACustomsManifestPeru fnx_MapearXMLEnvioFile(string strRutaXML)
        {
            try
            {
                OACustomsManifestPeru oCustomsDeclarationPeruType = new OACustomsManifestPeru();
                using (FileStream xmlStream = new FileStream(strRutaXML, FileMode.Open))
                {
                    using (XmlReader xmlReader = XmlReader.Create(xmlStream))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof (OACustomsManifestPeru));
                        oCustomsDeclarationPeruType = serializer.Deserialize(xmlReader) as OACustomsManifestPeru;
                    }
                }
                return oCustomsDeclarationPeruType;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_MapearXMLEnvioFile", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error,
                    (String.IsNullOrEmpty(ex.InnerException.Message) ? ex.Message : ex.InnerException.Message));
                return null;
            }
        }


        private CustomsDeclarationPeruType fnx_MapearDocumentoEnvioByte(byte[] byteDocumento)
        {
            try
            {
                CustomsDeclarationPeruType oCustomsDeclarationPeruType = new CustomsDeclarationPeruType();
                using (var ms = new MemoryStream(byteDocumento))
                {
                    using (XmlReader xmlReader = XmlReader.Create(ms))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof (CustomsDeclarationPeruType));
                        oCustomsDeclarationPeruType = serializer.Deserialize(xmlReader) as CustomsDeclarationPeruType;
                    }
                }
                return oCustomsDeclarationPeruType;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_MapearDocumentoEnvioByte", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }
        }

        private ResponsePeruType fnx_MapearXMLRespuesta(byte[] byteDocumento)
        {
            try
            {
                ResponsePeruType oResponsePeruType = new ResponsePeruType();
                using (var ms = new MemoryStream(byteDocumento))
                {
                    using (XmlReader xmlReader = XmlReader.Create(ms))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof (ResponsePeruType));
                        oResponsePeruType = serializer.Deserialize(xmlReader) as ResponsePeruType;
                    }
                }
                return oResponsePeruType;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_MapearXMLRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }

        }

        #endregion

        #region "METODOS UTILES"

        private void fnx_WriteFile(string strRutaDirectorio, ref string strNombreArchivo, byte[] byteArchivo,
            ENVIOS objEnvios, Boolean bolCrearJerarquia = false)
        {
            try
            {
                string strFecha = "";
                if (bolCrearJerarquia)
                {
                    strFecha = @"\" + DateTime.Now.Year + @"\" + Right("0" + DateTime.Now.Month, 2) + @"\" +
                               Right("0" + DateTime.Now.Day, 2);
                }
                oClsUtilitarios.fbol_CrearRuta(strRutaDirectorio + strFecha, ref strMensaje);
                string strtempo = Right("0" + DateTime.Now.Hour, 2) + Right("0" + DateTime.Now.Minute, 2) +
                                  Right("0" + DateTime.Now.Second, 2) + Right("00" + DateTime.Now.Millisecond, 3);

                if (objEnvios != null)
                {

                    strtempo = objEnvios.RUCAGENTEADUANA + "_" + objEnvios.CODADUANADECLARACION +
                               "_" +
                               (objEnvios.CODTIPOTRANSACCION != "" ? objEnvios.CODTIPOTRANSACCION.Substring(0, 2) : "") +
                               "_" + objEnvios.NUMEROORDEN +
                               "_" +
                               (objEnvios.CODTIPOTRANSACCION != "" ? objEnvios.CODTIPOTRANSACCION.Substring(2, 2) : "")
                               + "_" + strtempo + "_" +
                               oclsValidacionDatos.fstr_ObtenDato(objEnvios.NROTICKET);
                }

                if (strNombreArchivo.ToLower().StartsWith("acuse"))
                {
                    strNombreArchivo = "tci_" + strNombreArchivo;
                    strNombreArchivo = strNombreArchivo.Replace(".xml", "_" + strtempo + ".xml");
                }
                else if (strNombreArchivo.ToLower().StartsWith("nsigad"))
                {
                    strNombreArchivo = strNombreArchivo.Replace("nsigad", "tci");
                    strNombreArchivo = strNombreArchivo.Replace(".xml", "_" + strtempo + ".xml");
                    strNombreArchivo = strNombreArchivo.Replace(strNombreArchivo.Split('_')[2] + "_", string.Empty);
                }

                //strNombreArchivo = strNombreArchivo.Replace(".xml", "_" + strtempo + ".xml");
                StreamWriter sw = new StreamWriter(strRutaDirectorio + strFecha + @"\" + strNombreArchivo, false,
                    Encoding.GetEncoding("ISO-8859-1"));

                string write = Encoding.GetEncoding("ISO-8859-1").GetString(byteArchivo);
                sw.Write(write);
                sw.Close();
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_WriteFile", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }

        }

        private byte[] FileToByteArray(string fileName)
        {
            try
            {
                byte[] buff = null;
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(fileName).Length;
                buff = br.ReadBytes((int) numBytes);
                fs.Dispose();
                fs.Close();
                br.Dispose();
                br.Close();
                return buff;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("FileToByteArray", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }

        }

        private Boolean MoveFile(string strRutaArchivo, string strRutaProcesados, string strNombreArchivo)
        {
            try
            {
                string strMensaje = string.Empty;
                if (oClsUtilitarios.fbol_CrearRuta(strRutaProcesados, ref strMensaje) == false)
                {
                    //p_RegistrarLog("MoveFile", ENLogTci.TipoMensaje.Error, strMensaje);
                    Logger.Log(Logger.Level.Error, strMensaje);
                    return false;
                }
                string strtempo = DateTime.Now.Year + Right("0" + DateTime.Now.Month, 2) +
                                  Right("0" + DateTime.Now.Day, 2) + Right("0" + DateTime.Now.Hour, 2) +
                                  Right("0" + DateTime.Now.Minute, 2) + Right("0" + DateTime.Now.Second, 2) +
                                  Right("00" + DateTime.Now.Millisecond, 3);
                GC.Collect();
                File.Move(strRutaArchivo + @"\" + strNombreArchivo,
                    strRutaProcesados + @"\" + strNombreArchivo.Replace(".zip", "") + strtempo + @".zip");
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("MoveFile", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private void p_InicializarVariables(string strRutaLog)
        {
            //oLogTCI = new LogTCI();
            //oLogTCI.RutaDirectorioLogTCI = strRutaLog;
        }

        private static string Right(string original, int numberCharacters)
        {
            return original.Substring(original.Length - numberCharacters);
        }

        #endregion

        #region "CADENA DE CONEXIÓN"

        public static string getConStrSQL(string strProvider, string strDataSource, string strInitialCatalog,
            string strUserID, string strPassword)
        {
            string connectionString = new EntityConnectionStringBuilder
            {
                Metadata =
                    "res://*/AccesoDatos.APPTAGSQL.csdl|res://*/AccesoDatos.APPTAGSQL.ssdl|res://*/AccesoDatos.APPTAGSQL.msl",
                Provider = strProvider,
                ProviderConnectionString = new SqlConnectionStringBuilder
                {
                    InitialCatalog = strInitialCatalog,
                    DataSource = strDataSource,
                    IntegratedSecurity = false,
                    UserID = strUserID,
                    Password = strPassword,
                }.ConnectionString
            }.ConnectionString;

            return connectionString;
        }

        public static string getConStrMYSQL(string strProvider, string strDataSource, string strPort,
            string strInitialCatalog, string strUserID, string strPassword)
        {
            string connectionString;
            string strRutaAplicacion = AppDomain.CurrentDomain.BaseDirectory;
            connectionString = "metadata=" + strRutaAplicacion +
                               "/AccesoDatos/APPTAGMYSQL.ssdl|res://*/AccesoDatos.APPTAGSQL.csdl|res://*/AccesoDatos.APPTAGSQL.msl;provider=" +
                               strProvider + ";provider connection string='server=" + strDataSource + ";Port=" + strPort +
                               ";user id=" + strUserID + ";password=" + strPassword +
                               ";persist security info=True;database=" + strInitialCatalog + "'";
            return connectionString;

        }

        #endregion

        #region "FUNCIONES LOG"

        //private void p_RegistrarLog(string strMetodo, ENLogTci.TipoMensaje tipoMensaje, string strDescripcion)
        //{
        //    oEnLogTci = new ENLogTci();
        //    oEnLogTci.p_EstablecerParametros(CstrNombreSistema, CstrVersionSistema, CstrUsuarioSistema, CstrDireccionIPEquipo, CstrProyecto, CstrClase, strMetodo, tipoMensaje, strDescripcion);
        //    oLogTCI.fbol_RegistrarLogArchivo(oEnLogTci);
        //}

        private void p_InicializarConstantes(string strUsuarioSistema, string GestorBaseDatos, string strDataSource,
            string strPort, string strInitialCatalog, string strUserID, string strPassword)
        {
            CstrNombreSistema = "DLLMapRe";
            ;
            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            CstrVersionSistema = fvi.FileVersion;
            CstrUsuarioSistema = strUsuarioSistema;
            CstrDireccionIPEquipo = oClsUtilitarios.fstr_ObtenerIPLocal();
            CstrProyecto = "DLLMapRe";
            CstrClase = "LNRegistroEnvio";
            if (GestorBaseDatos.Equals("1"))
            {
                strProvider = "System.Data.SqlClient";
                strCadenaConexion = getConStrSQL(strProvider, strDataSource, strInitialCatalog, strUserID, strPassword);
            }
            else
            {
                strProvider = "MySql.Data.MySqlClient";
                strCadenaConexion = getConStrMYSQL(strProvider, strDataSource, strPort, strInitialCatalog, strUserID,
                    strPassword);
            }


        }

        #endregion

        #region  "METODOS DE CONFIGURACION"

        // Declarar los objetos
        private ENxmlSW objENxmlSW = new ENxmlSW();

        private void p_AgregarVariableConfiguracion(string strVariable, string strRuta, DataTable objDataTable,
            Boolean bolSobreescribir)
        {
            try
            {
                DataColumn objDataColumn = new DataColumn();
                objDataColumn.ColumnName = strVariable;

                if (!objDataTable.Columns.Contains(strVariable))
                {
                    objDataTable.Columns.Add(objDataColumn);
                }

                if (bolSobreescribir)
                {
                    objDataTable.Rows[0][strVariable] = strRuta;
                }
                else
                {
                    if (String.IsNullOrEmpty(objDataTable.Rows[0][strVariable].ToString()))
                    {
                        objDataTable.Rows[0][strVariable] = strRuta;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private Boolean fbol_LeerConfiguracion(String strRutaXML)
        {
            try
            {
                if (fbol_ValidarArchivoConfiguracion(strRutaXML))
                {
                    DataSet ods = new DataSet();
                    ods.ReadXml(strRutaXML);

                    if (ods.Tables.Count > 0)
                    {
                        //+++++++++++++++++++++++++++ PARA LECTURA DE ACCESO PARA LA BASE DE DATOS ++++++++++++++++++++++
                        // Cargar las entidades del objeto objENxmlSW
                        objENxmlSW.Casilla = ods.Tables[0].Rows[0]["Casilla"].ToString();
                        objENxmlSW.PwdCasilla =
                            oClsUtilitarios.fstr_Desencriptar(ods.Tables[0].Rows[0]["PwdCasilla"].ToString());
                        objENxmlSW.UrlSatServer = ods.Tables[0].Rows[0]["UrlSatServer"].ToString();
                        objENxmlSW.UrlSatServerAlternativa = ods.Tables[0].Rows[0]["UrlSatServerAlternativa"].ToString();
                        objENxmlSW.TimeOut = Convert.ToInt32(ods.Tables[0].Rows[0]["TimeOut"].ToString());
                        LNxmlSW oLNConfigXml = new LNxmlSW();
                        oLNConfigXml.fbol_ObtenerConfiguracion(objENxmlSW);
                        //p_RegistrarLog("fbol_LeerConfiguracion", ENLogTci.TipoMensaje.Info, "Se cargaron los parametros del archivo de configuración correctamente");
                        //Logger.Log(Logger.Level.Info,
                        //    "Se cargaron los parametros del archivo de configuración correctamente");
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_LeerConfiguracion", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private Boolean fbol_ValidarArchivoConfiguracion(String strRutaXML)
        {
            try
            {

                if (File.Exists(strRutaXML))
                {
                    DataSet ods = new DataSet();
                    ods.ReadXml(strRutaXML);


                    if (ods.Tables.Count > 0)
                    {
                        p_AgregarVariableConfiguracion("Casilla", "demo", ods.Tables[0], false);
                        p_AgregarVariableConfiguracion("Pwdcasilla", "xxxx", ods.Tables[0], false);
                        p_AgregarVariableConfiguracion("UrlSatServer",
                            "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl", ods.Tables[0], false);
                        p_AgregarVariableConfiguracion("UrlSatServerAlternativa",
                            "http://200.106.52.136/satwebserviceDEV/WSSDA?wsdl", ods.Tables[0], false);
                        p_AgregarVariableConfiguracion("TimeOut", "5000", ods.Tables[0], false);
                        File.SetAttributes(strRutaXML, FileAttributes.Normal);
                        ods.WriteXml(strRutaXML);
                        File.SetAttributes(strRutaXML, FileAttributes.ReadOnly);
                        return true;

                    }
                    else
                    {
                        //p_RegistrarLog("fbol_LeerConfiguracion", ENLogTci.TipoMensaje.Error, "Archivo de configuración con estructura inválida");
                        Logger.Log(Logger.Level.Error, "Archivo de configuración con estructura inválida");
                        return false;
                    }

                }
                else
                {
                    //p_RegistrarLog("fbol_LeerConfiguracion", ENLogTci.TipoMensaje.Error, "No se encontró el Archivo de Configuración " + strRutaXML);
                    Logger.Log(Logger.Level.Error, "No se encontró el Archivo de Configuración " + strRutaXML);
                    return false;
                }

            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_LeerConfiguracion", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private Boolean fbol_ObtenerConfiguracion(ref ENEnvioRegistro oEnEnvioRegistro)
        {
            DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(strCadenaConexion);

            //OBTENER LA CONFIGURACION
            CONFIGURACION oConfiguracion = (from result in dbContext.CONFIGURACION
                select result).FirstOrDefault();
            if (oConfiguracion != null)
            {
                oEnEnvioRegistro.ValidaEsquema = oConfiguracion.VALIDAESQUEMA;
                oEnEnvioRegistro.NombreRespuesta = oConfiguracion.TIPONOMBREARCHIVO;
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion


    }
}
