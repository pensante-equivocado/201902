﻿using System;
using DLLMapRe.AccesoDatos.AppTagRespuesta;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.LogicaNegocio.Respuesta
{
    public class LnCanalMaster
    {
        private readonly AdCanalMaster _adCanalMaster = new AdCanalMaster();

        public Int32 Registrar(CanalMaster canalMaster, ref Int32 idCanalMasterNuevo)
        {
            return _adCanalMaster.Registrar(canalMaster, ref idCanalMasterNuevo);
        }
    }
}
