﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Transactions;
using System.Xml;
using DLLMapRe.AccesoDatos;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades;
using DLLMapRe.Entidades.Canal;
using DLLTransWeb.Entidades.Respuesta;
using Microsoft.VisualBasic.CompilerServices;
using tciUtilitarios;
using System.Text;
using DLLMapRe.AccesoDatos.AppTagRespuesta;
using DLLMapRe.LogicaNegocio.Envio;

namespace DLLMapRe.LogicaNegocio.Respuesta
{
    public class LnRespuesta
    {
        private readonly clsValidacionDatos _clsValidacionDatos = new clsValidacionDatos();
        private readonly clsUtilitarios _clsUtilitarios = new clsUtilitarios();
        public Boolean LeerXmlRespuestaAcuse(string strNombreArchivo, byte[] byteArchivo, Int32 idTransaccionEnvio, ref ENVIOS objEnvios, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            try
            {
                Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se procede a leer las etiquetas del acuse XML obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                string fechaRecepcion = string.Empty;
                string ticketEnvio = string.Empty;
                DataTable dtErrores = new DataTable();
                DataRow drError;
                XmlDocument xmlAcuse = new XmlDocument();
                MemoryStream msAcuse = new MemoryStream(byteArchivo);
                xmlAcuse.Load(msAcuse);

                dtErrores.Columns.Add("codigo");
                dtErrores.Columns.Add("descripcion");
                foreach (XmlNode nodoPadre in xmlAcuse.ChildNodes)
                {
                    if (nodoPadre is XmlElement)
                    {
                        foreach (XmlNode nodoHijo in nodoPadre.ChildNodes)
                        {
                            if (nodoHijo is XmlElement)
                            {
                                if (nodoHijo.Name.ToLower().Equals("anhoenvio"))
                                {
                                    ticketEnvio = nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("fecharecepcion"))
                                {
                                    fechaRecepcion = nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("ticketenvio"))
                                {
                                    ticketEnvio = ticketEnvio + nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("listaerrores"))
                                {

                                    foreach (XmlNode nodoError in nodoHijo.ChildNodes)
                                    {
                                        if (nodoError is XmlElement)
                                        {
                                            drError = dtErrores.NewRow();
                                            foreach (XmlNode nodoDetalles in nodoError.ChildNodes)
                                            {
                                                if (nodoDetalles is XmlElement)
                                                {

                                                    if (nodoDetalles.Name.ToLower().Equals("codigo"))
                                                    {
                                                        drError["codigo"] = nodoDetalles.InnerText;
                                                    }
                                                    if (nodoDetalles.Name.ToLower().Equals("descripcion"))
                                                    {
                                                        drError["descripcion"] = nodoDetalles.InnerText;
                                                    }

                                                }
                                            }
                                            dtErrores.Rows.Add(drError);
                                            dtErrores.AcceptChanges();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                RegistrarRespuestaAcuseSql(idTransaccionEnvio, fechaRecepcion, ticketEnvio, dtErrores, strNombreArchivo,
                    byteArchivo, ref objEnvios , idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql, ref detalleRespuestaSql);

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }

        }

        public Boolean LeerXmlRespuestaAcuseTemp(string strNombreArchivo, byte[] byteArchivo, Int32 idTransaccionEnvio, ref Entidades.AppTag.Envio objEnvios, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            try
            {
                Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se procede a leer las etiquetas del acuse XML obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                string fechaRecepcion = string.Empty;
                string ticketEnvio = string.Empty;
                DataTable dtErrores = new DataTable();
                DataRow drError;
                XmlDocument xmlAcuse = new XmlDocument();
                MemoryStream msAcuse = new MemoryStream(byteArchivo);
                xmlAcuse.Load(msAcuse);

                dtErrores.Columns.Add("codigo");
                dtErrores.Columns.Add("descripcion");
                foreach (XmlNode nodoPadre in xmlAcuse.ChildNodes)
                {
                    if (nodoPadre is XmlElement)
                    {
                        foreach (XmlNode nodoHijo in nodoPadre.ChildNodes)
                        {
                            if (nodoHijo is XmlElement)
                            {
                                if (nodoHijo.Name.ToLower().Equals("anhoenvio"))
                                {
                                    ticketEnvio = nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("fecharecepcion"))
                                {
                                    fechaRecepcion = nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("ticketenvio"))
                                {
                                    ticketEnvio = ticketEnvio + nodoHijo.InnerText;
                                }
                                if (nodoHijo.Name.ToLower().Equals("listaerrores"))
                                {

                                    foreach (XmlNode nodoError in nodoHijo.ChildNodes)
                                    {
                                        if (nodoError is XmlElement)
                                        {
                                            drError = dtErrores.NewRow();
                                            foreach (XmlNode nodoDetalles in nodoError.ChildNodes)
                                            {
                                                if (nodoDetalles is XmlElement)
                                                {

                                                    if (nodoDetalles.Name.ToLower().Equals("codigo"))
                                                    {
                                                        drError["codigo"] = nodoDetalles.InnerText;
                                                    }
                                                    if (nodoDetalles.Name.ToLower().Equals("descripcion"))
                                                    {
                                                        drError["descripcion"] = nodoDetalles.InnerText;
                                                    }

                                                }
                                            }
                                            dtErrores.Rows.Add(drError);
                                            dtErrores.AcceptChanges();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                RegistrarRespuestaAcuseSqlTemp(idTransaccionEnvio, fechaRecepcion, ticketEnvio, dtErrores, strNombreArchivo,
                    byteArchivo, ref objEnvios, idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql, ref detalleRespuestaSql);

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }

        }

        private void RegistrarRespuestaAcuseSql(Int32 idTransaccionEnvio, string strfechaRecepcion, string strticketEnvio,
            DataTable dtErrores, string strNombreArchivo, byte[] byteArchivo, ref ENVIOS objEnvios, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            try
            {
                using (TransactionScope transactionScope = new TransactionScope())
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);
                    respuestaSql = new RESPUESTA();
                    detalleRespuestaSql = new DETALLERESPUESTA();

                    //ACTUALIZAR ENVIO
                    ENVIOS oEnvio = (from result in dbContext.ENVIOS
                                     where result.IDTRANSACCION == idTransaccionEnvio
                                     select result).FirstOrDefault();

                    objEnvios = oEnvio;

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarAcuse", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return;
                    }
                    //strNumeroOrden = oEnvio.NUMEROORDEN;

                    if (!String.IsNullOrEmpty(strfechaRecepcion))
                    {
                        oEnvio.FECHAACUSE = Convert.ToDateTime(strfechaRecepcion);
                    }

                    oEnvio.NROTICKET = strticketEnvio;
                    oEnvio.IDESTADOACUSE = dtErrores.Rows.Count > 0 ? 8 : 1;
                    dbContext.SaveChanges();
                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se actualizó el [ENVIO] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    //FIN ACTUALIZAR ENVIO

                    //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                    respuestaSql.IDENVIO = oEnvio.IDENVIO;
                    respuestaSql.IDESTADORESPUESTA = dtErrores.Rows.Count > 0 ? 8 : 1;
                    if (!string.IsNullOrEmpty(strfechaRecepcion))
                    {
                        respuestaSql.FECHAACEPTACION = Convert.ToDateTime(strfechaRecepcion);
                    }
                    respuestaSql.IDTIPORESPUESTA = 2;
                    respuestaSql.NOMBREARCHIVO = strNombreArchivo;
                    respuestaSql.ARCHIVOXML = byteArchivo;
                    dbContext.RESPUESTA.AddObject(respuestaSql);
                    dbContext.SaveChanges();
                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se registro la [RESPUESTA] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA

                    for (int i = 0; i <= dtErrores.Rows.Count - 1; i++)
                    {
                        detalleRespuestaSql = new DETALLERESPUESTA();
                        detalleRespuestaSql.IDRESPUESTA = respuestaSql.IDRESPUESTA;
                        detalleRespuestaSql.TIPOMENSAJE = 1;
                        detalleRespuestaSql.CODIGO = dtErrores.Rows[i][0].ToString();
                        detalleRespuestaSql.DESCRIPCION = dtErrores.Rows[i][1].ToString();
                        dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                        dbContext.SaveChanges();
                    }
                    if (dtErrores.Rows.Count > 0)
                    {
                        Logger.Log(Logger.Level.Info,
                            String.Format(
                                "IdTransaccion {0} ; Se registro el [DETALLERESPUESTA] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}",
                                idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    }

                    dbContext.Dispose();
                    transactionScope.Complete();
                    //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, "se registro correctamente : " + strNombreArchivo);
                    //Logger.Log(Logger.Level.Info, "Se registro correctamente : " + strNombreArchivo);
                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }

        private void RegistrarRespuestaAcuseSqlTemp(Int32 idTransaccionEnvio, string strfechaRecepcion, string strticketEnvio,
            DataTable dtErrores, string strNombreArchivo, byte[] byteArchivo, ref Entidades.AppTag.Envio objEnvios, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            try
            {
                LnEnvio lnEnvio = new LnEnvio();
                Entidades.AppTag.Envio oEnvio = lnEnvio.ObtenerPorIdTransaccion(idTransaccionEnvio);
                    //(from result in dbContext.ENVIOS
                    //             where result.IDTRANSACCION == idTransaccionEnvio
                    //             select result).FirstOrDefault();

                objEnvios = oEnvio;

                using (TransactionScope transactionScope = new TransactionScope())
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);
                    respuestaSql = new RESPUESTA();
                    detalleRespuestaSql = new DETALLERESPUESTA();

                    //ACTUALIZAR ENVIO
                    

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarAcuse", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return;
                    }
                    //strNumeroOrden = oEnvio.NUMEROORDEN;

                    if (!String.IsNullOrEmpty(strfechaRecepcion))
                    {
                        oEnvio.FechaAcuse = Convert.ToDateTime(strfechaRecepcion);
                    }

                    oEnvio.NroTicket = strticketEnvio;
                    oEnvio.IdEstadoAcuse = dtErrores.Rows.Count > 0 ? 8 : 1;
                    dbContext.SaveChanges();
                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se actualizó el [ENVIO] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    //FIN ACTUALIZAR ENVIO

                    //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                    respuestaSql.IDENVIO = oEnvio.IdEnvio;
                    respuestaSql.IDESTADORESPUESTA = dtErrores.Rows.Count > 0 ? 8 : 1;
                    if (!string.IsNullOrEmpty(strfechaRecepcion))
                    {
                        respuestaSql.FECHAACEPTACION = Convert.ToDateTime(strfechaRecepcion);
                    }
                    respuestaSql.IDTIPORESPUESTA = 2;
                    respuestaSql.NOMBREARCHIVO = strNombreArchivo;
                    respuestaSql.ARCHIVOXML = byteArchivo;
                    dbContext.RESPUESTA.AddObject(respuestaSql);
                    dbContext.SaveChanges();
                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se registro la [RESPUESTA] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA

                    for (int i = 0; i <= dtErrores.Rows.Count - 1; i++)
                    {
                        detalleRespuestaSql = new DETALLERESPUESTA();
                        detalleRespuestaSql.IDRESPUESTA = respuestaSql.IDRESPUESTA;
                        detalleRespuestaSql.TIPOMENSAJE = 1;
                        detalleRespuestaSql.CODIGO = dtErrores.Rows[i][0].ToString();
                        detalleRespuestaSql.DESCRIPCION = dtErrores.Rows[i][1].ToString();
                        dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                        dbContext.SaveChanges();
                    }
                    if (dtErrores.Rows.Count > 0)
                    {
                        Logger.Log(Logger.Level.Info,
                            String.Format(
                                "IdTransaccion {0} ; Se registro el [DETALLERESPUESTA] en la base de datos segun el ACUSE obtenido; el IdTransaccion del envio es: {1}",
                                idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
                    }

                    dbContext.Dispose();
                    transactionScope.Complete();
                    //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, "se registro correctamente : " + strNombreArchivo);
                    //Logger.Log(Logger.Level.Info, "Se registro correctamente : " + strNombreArchivo);
                }
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarAcuseSQL", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }

        public Boolean LeerXmlRespuestaNsigad(string strNombreArchivo, byte[] byteArchivo, Int32 idTransaccionEnvio, ref ENVIOS objEnvios, 
            ref string refMensaje, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            //LeerXmlRespuestaAcuse
            string strNodoIDEstadoRespuestaEnvio = string.Empty;
            string strNodoIDEstadoRespuesta = string.Empty;
            string strNodoFechaAceptacion = string.Empty;
            string strNodoFechaRespuesta = string.Empty;

            Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se procede a leer las etiquetas del nsigad XML obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
            try
            {
                using (TransactionScope transactionScope = new TransactionScope())
                {

                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);
                    respuestaSql = new RESPUESTA();
                    detalleRespuestaSql = new DETALLERESPUESTA();

                    //Boolean bolValidacion = false;
                    Boolean bol0101 = false;
                    Boolean bolReportedProcessingResult = false;

                    //ACTUALIZAR DATOS DEL ENVIO
                    ENVIOS oEnvio = (from result in dbContext.ENVIOS
                                     where result.IDTRANSACCION == idTransaccionEnvio
                                     select result).FirstOrDefault();

                    objEnvios = oEnvio;

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return true;
                    }



                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////////////////////////////////////////////////////////// LECTURA DEL ARCHIVO RESPUESTA POR NODOS ////////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    // Cargar el archivo XML                              
                    XmlDocument xDoc = new XmlDocument();
                    MemoryStream ms = new MemoryStream(byteArchivo);

                    xDoc.Load(ms);

                    foreach (XmlNode nodoPadre in xDoc.ChildNodes)
                    {
                        if (nodoPadre is XmlElement && nodoPadre.Name.Equals("rsm:ResponsePeru"))
                        {

                            // TAG "rsm:SpecifiedExchangedDocumentContext"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:SpecifiedExchangedDocumentContext") ==
                                0)
                            {
                                refMensaje =
                                    "Tag Mandatorio no fue encontrado: rsm:SpecifiedExchangedDocumentContext en " +
                                    nodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, refMensaje);
                                return false;
                            }

                            // TAG "rsm:ReportedProcessingResult"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:ReportedProcessingResult") > 0)
                            {
                                bolReportedProcessingResult = true;
                            }

                            // TAG "rsm:HeaderExchangedDocument"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:HeaderExchangedDocument") == 0)
                            {
                                refMensaje = "Tag Mandatorio no fue encontrado: rsm:HeaderExchangedDocument en " +
                                             nodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, refMensaje);
                                return false;
                            }

                            foreach (XmlNode nodoH1 in nodoPadre.ChildNodes)
                            {
                                if (nodoH1 is XmlElement)
                                {
                                    switch (nodoH1.Name)
                                    {
                                        case "rsm:SpecifiedExchangedDocumentContext":

                                            if (
                                                fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:SpecifiedTransactionID") ==
                                                0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:SpecifiedTransactionID en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }
                                            else
                                            {
                                                foreach (XmlNode nodoH2 in nodoH1.ChildNodes)
                                                {
                                                    if (nodoH2 is XmlElement &&
                                                        nodoH2.Name.ToString().Equals("ram:SpecifiedTransactionID"))
                                                    {
                                                        if (nodoH2.InnerText.Equals("0101"))
                                                        {
                                                            bol0101 = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }

                                            break;
                                        case "rsm:HeaderExchangedDocument":



                                            if (fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:StatusCode") == 0)
                                            {
                                                refMensaje = "Tag Mandatorio no fue encontrado: ram:StatusCode en " +
                                                             nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }
                                            else
                                            {



                                                strNodoIDEstadoRespuestaEnvio =
                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");
                                                strNodoIDEstadoRespuesta =
                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuestaEnvio))
                                                {
                                                    oEnvio.IDESTADORESPUESTA =
                                                        Convert.ToInt32(strNodoIDEstadoRespuestaEnvio);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuesta))
                                                {
                                                    respuestaSql.IDESTADORESPUESTA =
                                                        Convert.ToInt32(strNodoIDEstadoRespuesta);
                                                }

                                            }

                                            if (fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:AcceptanceDateTime") == 0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:AcceptanceDateTime en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Info, strMensaje);
                                                Logger.Log(Logger.Level.Info, refMensaje);
                                                respuestaSql.FECHAACEPTACION = null;
                                                oEnvio.FECHARESPUESTA = null;
                                            }
                                            else
                                            {
                                                strNodoFechaAceptacion = fstr_ObtenerValorEtiquetaHijoXML(nodoH1,
                                                    "ram:AcceptanceDateTime");
                                                strNodoFechaRespuesta = fstr_ObtenerValorEtiquetaHijoXML(nodoH1,
                                                    "ram:AcceptanceDateTime");

                                                if (!string.IsNullOrEmpty(strNodoFechaAceptacion))
                                                {
                                                    respuestaSql.FECHAACEPTACION =
                                                        Convert.ToDateTime(strNodoFechaAceptacion);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoFechaRespuesta))
                                                {
                                                    oEnvio.FECHARESPUESTA = Convert.ToDateTime(strNodoFechaRespuesta);
                                                }

                                            }
                                            break;

                                        case "rsm:ReportedProcessingResult":

                                            // TAG SpecifiedGoodsClearanceResult
                                            if (
                                                fint_ObtenerRepeticionesHijosXML(nodoH1,
                                                    "userram:SpecifiedGoodsClearanceResult") == 0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: userram:SpecifiedGoodsClearanceResult en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }


                                            foreach (XmlNode nodoH2 in nodoH1.ChildNodes)
                                            {
                                                if (nodoH2 is XmlElement)
                                                {
                                                    switch (nodoH2.Name)
                                                    {
                                                        case "userram:SpecifiedGoodsClearanceResult":

                                                            // Número de declaración /manifiesto generada por aduanas  
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:CustomsID") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:CustomsID en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (bol0101 = true)
                                                                {
                                                                    oEnvio.NROCORRELATIVO =
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:CustomsID");
                                                                }
                                                                respuestaSql.NUMECORRE =
                                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                        "userram:CustomsID");
                                                            }

                                                            // Mensaje de notificación
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:Information") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:Information en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                respuestaSql.MENSAJENOTIFICACION =
                                                                    _clsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:Information"));
                                                            }

                                                            // Tipo de documento según CDA
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:TypeCode") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:TypeCode en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                respuestaSql.TDOCCDA =
                                                                    _clsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:TypeCode"));
                                                            }

                                                            // Año de la declaración / manifiesto generada por aduanas
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:AcceptanceDateTime") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:AcceptanceDateTime en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (
                                                                    ValidarFecha(
                                                                        _clsValidacionDatos.fstr_ObtenDato(
                                                                            fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                                "userram:AcceptanceDateTime")),
                                                                        ref refMensaje))
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        oEnvio.FECHADECLARACION =
                                                                            Convert.ToDateTime(
                                                                                _clsValidacionDatos.fstr_ObtenDato(
                                                                                    fstr_ObtenerValorEtiquetaHijoXML(
                                                                                        nodoH2,
                                                                                        "userram:AcceptanceDateTime")));
                                                                    }
                                                                    respuestaSql.FECHANUMERACION =
                                                                        Convert.ToDateTime(
                                                                            _clsValidacionDatos.fstr_ObtenDato(
                                                                                fstr_ObtenerValorEtiquetaHijoXML(
                                                                                    nodoH2, "userram:AcceptanceDateTime")));
                                                                }
                                                                else
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        ERRORENVIO errorEnvioSql = new ERRORENVIO();
                                                                        errorEnvioSql.IDENVIO = oEnvio.IDENVIO;
                                                                        errorEnvioSql.DESCRIPCION = refMensaje;
                                                                        errorEnvioSql.FECHAREGISTRO = DateTime.Now;
                                                                        dbContext.ERRORENVIO.AddObject(errorEnvioSql);
                                                                        dbContext.SaveChanges();
                                                                    }
                                                                }
                                                            }
                                                            break;

                                                    }
                                                }
                                            }

                                            break;

                                    }
                                }
                            }


                            //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                            respuestaSql.IDENVIO = oEnvio.IDENVIO;
                            respuestaSql.IDTIPORESPUESTA = 3; //RESPUESTA
                            respuestaSql.NOMBREARCHIVO = strNombreArchivo;
                            respuestaSql.ARCHIVOXML = byteArchivo;
                            respuestaSql.FECHAREGISTRO = DateTime.Now;

                            dbContext.RESPUESTA.AddObject(respuestaSql);
                            dbContext.SaveChanges();

                            Logger.Log(Logger.Level.Info,
                                String.Format(
                                    "IdTransaccion {0} ; Se registro la [RESPUESTA] en la base de datos segun el NSIGAD obtenido; el IdTransaccion del envio es: {1}",
                                    idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));


                            //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA



                            //SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            if (oEnvio.IDESTADORESPUESTA != 8 && oEnvio.IDESTADORESPUESTA != 24)
                            {
                                if (!bolReportedProcessingResult)
                                {
                                    refMensaje = "Tag Mandatorio no fue encontrado: rsm:ReportedProcessingResult en " +
                                                 nodoPadre.Name;
                                    //bolValidacion = false;
                                }
                                else
                                {
                                    // Detalle de la RPTA Correcta
                                    if (!RegistrarDetalleRespuestaSql(dbContext, idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql, ref detalleRespuestaSql))
                                    {
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro del detalle de la respuesta");
                                        return false;
                                    }

                                    //Informacion de RPTA Correcta
                                    if (!RegistrarInformacionRespuestaSql(xDoc, dbContext, idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql))
                                    {
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro de la información de la respuesta");
                                        return false;
                                    }

                                    //Registrar CanalMaster
                                    RegistrarCanalMaster(ref dbContext, oEnvio, idTransaccionRespuestaObtenidaDesdeWs);
                                    
                                }
                            }
                            else
                            {
                                if (!RegistrarErroresDetalleRespuestaSql(xDoc, dbContext, ref respuestaSql))
                                {
                                    Logger.Log(Logger.Level.Error,
                                        "Ocurrió un problema durante el registro de errores de la respuesta");
                                    return false;
                                }
                            }


                            //REGISTRO DE ADVERTENCIAS
                            if (!fbol_RegistrarWarningsDetalleRespuesta(xDoc, dbContext, ref respuestaSql))
                            {
                                Logger.Log(Logger.Level.Error,
                                    "Ocurrió un problema durante el registro de advertencias de la respuesta");
                                return false;
                            }


                            //FIN SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            dbContext.Dispose();
                            transactionScope.Complete();

                        }//fin rsm:ResponsePeru
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        public Boolean LeerXmlRespuestaNsigadTemp(string strNombreArchivo, byte[] byteArchivo, Int32 idTransaccionEnvio, ref Entidades.AppTag.Envio objEnvios,
            ref string refMensaje, int idTransaccionRespuestaObtenidaDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            //LeerXmlRespuestaAcuse
            string strNodoIDEstadoRespuestaEnvio = string.Empty;
            string strNodoIDEstadoRespuesta = string.Empty;
            string strNodoFechaAceptacion = string.Empty;
            string strNodoFechaRespuesta = string.Empty;

            Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se procede a leer las etiquetas del nsigad XML obtenido; el IdTransaccion del envio es: {1}", idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));
            try
            {
                LnEnvio lnEnvio = new LnEnvio();
                Entidades.AppTag.Envio oEnvio = lnEnvio.ObtenerPorIdTransaccion(idTransaccionEnvio);
                                   
                //(from result in dbContext.ENVIOS
                //                 where result.IDTRANSACCION == idTransaccionEnvio
                //                 select result).FirstOrDefault();

                objEnvios = oEnvio;

                using (TransactionScope transactionScope = new TransactionScope())
                {

                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);
                    respuestaSql = new RESPUESTA();
                    detalleRespuestaSql = new DETALLERESPUESTA();

                    //Boolean bolValidacion = false;
                    Boolean bol0101 = false;
                    Boolean bolReportedProcessingResult = false;

                    //ACTUALIZAR DATOS DEL ENVIO
                    

                    if (oEnvio == null)
                    {
                        //p_RegistrarLog("fbol_RegistrarRespuesta", ENLogTci.TipoMensaje.Error, "No existe el Envio");
                        Logger.Log(Logger.Level.Error, "No existe el Envio");
                        return true;
                    }



                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////////////////////////////////////////////////////////// LECTURA DEL ARCHIVO RESPUESTA POR NODOS ////////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    // Cargar el archivo XML                              
                    XmlDocument xDoc = new XmlDocument();
                    MemoryStream ms = new MemoryStream(byteArchivo);

                    xDoc.Load(ms);

                    foreach (XmlNode nodoPadre in xDoc.ChildNodes)
                    {
                        if (nodoPadre is XmlElement && nodoPadre.Name.Equals("rsm:ResponsePeru"))
                        {

                            // TAG "rsm:SpecifiedExchangedDocumentContext"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:SpecifiedExchangedDocumentContext") ==
                                0)
                            {
                                refMensaje =
                                    "Tag Mandatorio no fue encontrado: rsm:SpecifiedExchangedDocumentContext en " +
                                    nodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, refMensaje);
                                return false;
                            }

                            // TAG "rsm:ReportedProcessingResult"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:ReportedProcessingResult") > 0)
                            {
                                bolReportedProcessingResult = true;
                            }

                            // TAG "rsm:HeaderExchangedDocument"
                            if (fint_ObtenerRepeticionesHijosXML(nodoPadre, "rsm:HeaderExchangedDocument") == 0)
                            {
                                refMensaje = "Tag Mandatorio no fue encontrado: rsm:HeaderExchangedDocument en " +
                                             nodoPadre.Name.ToString();
                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                Logger.Log(Logger.Level.Error, refMensaje);
                                return false;
                            }

                            foreach (XmlNode nodoH1 in nodoPadre.ChildNodes)
                            {
                                if (nodoH1 is XmlElement)
                                {
                                    switch (nodoH1.Name)
                                    {
                                        case "rsm:SpecifiedExchangedDocumentContext":

                                            if (
                                                fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:SpecifiedTransactionID") ==
                                                0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:SpecifiedTransactionID en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }
                                            else
                                            {
                                                foreach (XmlNode nodoH2 in nodoH1.ChildNodes)
                                                {
                                                    if (nodoH2 is XmlElement &&
                                                        nodoH2.Name.ToString().Equals("ram:SpecifiedTransactionID"))
                                                    {
                                                        if (nodoH2.InnerText.Equals("0101"))
                                                        {
                                                            bol0101 = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }

                                            break;
                                        case "rsm:HeaderExchangedDocument":



                                            if (fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:StatusCode") == 0)
                                            {
                                                refMensaje = "Tag Mandatorio no fue encontrado: ram:StatusCode en " +
                                                             nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }
                                            else
                                            {



                                                strNodoIDEstadoRespuestaEnvio =
                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");
                                                strNodoIDEstadoRespuesta =
                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH1, "ram:StatusCode")
                                                        .Replace("Item", "");

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuestaEnvio))
                                                {
                                                    oEnvio.IdEstadoRespuesta =
                                                        Convert.ToInt32(strNodoIDEstadoRespuestaEnvio);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoIDEstadoRespuesta))
                                                {
                                                    respuestaSql.IDESTADORESPUESTA =
                                                        Convert.ToInt32(strNodoIDEstadoRespuesta);
                                                }

                                            }

                                            if (fint_ObtenerRepeticionesHijosXML(nodoH1, "ram:AcceptanceDateTime") == 0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: ram:AcceptanceDateTime en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Info, strMensaje);
                                                Logger.Log(Logger.Level.Info, refMensaje);
                                                respuestaSql.FECHAACEPTACION = null;
                                                oEnvio.FechaRespuesta = null;
                                            }
                                            else
                                            {
                                                strNodoFechaAceptacion = fstr_ObtenerValorEtiquetaHijoXML(nodoH1,
                                                    "ram:AcceptanceDateTime");
                                                strNodoFechaRespuesta = fstr_ObtenerValorEtiquetaHijoXML(nodoH1,
                                                    "ram:AcceptanceDateTime");

                                                if (!string.IsNullOrEmpty(strNodoFechaAceptacion))
                                                {
                                                    respuestaSql.FECHAACEPTACION =
                                                        Convert.ToDateTime(strNodoFechaAceptacion);
                                                }

                                                if (!string.IsNullOrEmpty(strNodoFechaRespuesta))
                                                {
                                                    oEnvio.FechaRespuesta = Convert.ToDateTime(strNodoFechaRespuesta);
                                                }

                                            }
                                            break;

                                        case "rsm:ReportedProcessingResult":

                                            // TAG SpecifiedGoodsClearanceResult
                                            if (
                                                fint_ObtenerRepeticionesHijosXML(nodoH1,
                                                    "userram:SpecifiedGoodsClearanceResult") == 0)
                                            {
                                                refMensaje =
                                                    "Tag Mandatorio no fue encontrado: userram:SpecifiedGoodsClearanceResult en " +
                                                    nodoH1.Name.ToString();
                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                return false;
                                            }


                                            foreach (XmlNode nodoH2 in nodoH1.ChildNodes)
                                            {
                                                if (nodoH2 is XmlElement)
                                                {
                                                    switch (nodoH2.Name)
                                                    {
                                                        case "userram:SpecifiedGoodsClearanceResult":

                                                            // Número de declaración /manifiesto generada por aduanas  
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:CustomsID") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:CustomsID en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (bol0101 = true)
                                                                {
                                                                    oEnvio.NroCorrelativo =
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:CustomsID");
                                                                }
                                                                respuestaSql.NUMECORRE =
                                                                    fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                        "userram:CustomsID");
                                                            }

                                                            // Mensaje de notificación
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:Information") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:Information en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                respuestaSql.MENSAJENOTIFICACION =
                                                                    _clsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:Information"));
                                                            }

                                                            // Tipo de documento según CDA
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:TypeCode") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:TypeCode en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                respuestaSql.TDOCCDA =
                                                                    _clsValidacionDatos.fstr_ObtenDato(
                                                                        fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                            "userram:TypeCode"));
                                                            }

                                                            // Año de la declaración / manifiesto generada por aduanas
                                                            if (
                                                                fint_ObtenerRepeticionesHijosXML(nodoH2,
                                                                    "userram:AcceptanceDateTime") == 0)
                                                            {
                                                                refMensaje =
                                                                    "Tag Mandatorio no fue encontrado: userram:AcceptanceDateTime en " +
                                                                    nodoH2.Name.ToString();
                                                                //p_RegistrarLog("fbol_RegistrarArchivoRespuestaSQL", ENLogTci.TipoMensaje.Error, strMensaje);
                                                                Logger.Log(Logger.Level.Error, refMensaje);
                                                                return false;
                                                            }
                                                            else
                                                            {
                                                                if (
                                                                    ValidarFecha(
                                                                        _clsValidacionDatos.fstr_ObtenDato(
                                                                            fstr_ObtenerValorEtiquetaHijoXML(nodoH2,
                                                                                "userram:AcceptanceDateTime")),
                                                                        ref refMensaje))
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        oEnvio.FechaDeclaracion =
                                                                            Convert.ToDateTime(
                                                                                _clsValidacionDatos.fstr_ObtenDato(
                                                                                    fstr_ObtenerValorEtiquetaHijoXML(
                                                                                        nodoH2,
                                                                                        "userram:AcceptanceDateTime")));
                                                                    }
                                                                    respuestaSql.FECHANUMERACION =
                                                                        Convert.ToDateTime(
                                                                            _clsValidacionDatos.fstr_ObtenDato(
                                                                                fstr_ObtenerValorEtiquetaHijoXML(
                                                                                    nodoH2, "userram:AcceptanceDateTime")));
                                                                }
                                                                else
                                                                {
                                                                    if (bol0101 = true)
                                                                    {
                                                                        ERRORENVIO errorEnvioSql = new ERRORENVIO();
                                                                        errorEnvioSql.IDENVIO = oEnvio.IdEnvio;
                                                                        errorEnvioSql.DESCRIPCION = refMensaje;
                                                                        errorEnvioSql.FECHAREGISTRO = DateTime.Now;
                                                                        dbContext.ERRORENVIO.AddObject(errorEnvioSql);
                                                                        dbContext.SaveChanges();
                                                                    }
                                                                }
                                                            }
                                                            break;

                                                    }
                                                }
                                            }

                                            break;

                                    }
                                }
                            }


                            //SETEAR DATOS DE LA CABECERA DE LA RESPUESTA
                            respuestaSql.IDENVIO = oEnvio.IdEnvio;
                            respuestaSql.IDTIPORESPUESTA = 3; //RESPUESTA
                            respuestaSql.NOMBREARCHIVO = strNombreArchivo;
                            respuestaSql.ARCHIVOXML = byteArchivo;
                            respuestaSql.FECHAREGISTRO = DateTime.Now;

                            dbContext.RESPUESTA.AddObject(respuestaSql);
                            dbContext.SaveChanges();

                            Logger.Log(Logger.Level.Info,
                                String.Format(
                                    "IdTransaccion {0} ; Se registro la [RESPUESTA] en la base de datos segun el NSIGAD obtenido; el IdTransaccion del envio es: {1}",
                                    idTransaccionRespuestaObtenidaDesdeWs, idTransaccionEnvio));


                            //FIN SETEAR DATOS DE LA CABECERA DE LA RESPUESTA



                            //SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            if (oEnvio.IdEstadoRespuesta != 8 && oEnvio.IdEstadoRespuesta != 24)
                            {
                                if (!bolReportedProcessingResult)
                                {
                                    refMensaje = "Tag Mandatorio no fue encontrado: rsm:ReportedProcessingResult en " +
                                                 nodoPadre.Name;
                                    //bolValidacion = false;
                                }
                                else
                                {
                                    // Detalle de la RPTA Correcta
                                    if (!RegistrarDetalleRespuestaSql(dbContext, idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql, ref detalleRespuestaSql))
                                    {
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro del detalle de la respuesta");
                                        return false;
                                    }

                                    //Informacion de RPTA Correcta
                                    if (!RegistrarInformacionRespuestaSql(xDoc, dbContext, idTransaccionRespuestaObtenidaDesdeWs, ref respuestaSql))
                                    {
                                        Logger.Log(Logger.Level.Error,
                                            "Ocurrió un problema durante el registro de la información de la respuesta");
                                        return false;
                                    }

                                    //Registrar CanalMaster
                                    RegistrarCanalMasterTemp(ref dbContext, oEnvio, idTransaccionRespuestaObtenidaDesdeWs);

                                }
                            }
                            else
                            {
                                if (!RegistrarErroresDetalleRespuestaSql(xDoc, dbContext, ref respuestaSql))
                                {
                                    Logger.Log(Logger.Level.Error,
                                        "Ocurrió un problema durante el registro de errores de la respuesta");
                                    return false;
                                }
                            }


                            //REGISTRO DE ADVERTENCIAS
                            if (!fbol_RegistrarWarningsDetalleRespuesta(xDoc, dbContext, ref respuestaSql))
                            {
                                Logger.Log(Logger.Level.Error,
                                    "Ocurrió un problema durante el registro de advertencias de la respuesta");
                                return false;
                            }


                            //FIN SETEAR DATOS DE LOS DETALLES DE LA RESPUESTA
                            dbContext.Dispose();
                            transactionScope.Complete();

                        }//fin rsm:ResponsePeru
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private void RegistrarCanalMaster(ref DBAPPTAGSQLEntities dbContext, ENVIOS envio, Int32 idTransaccionRespuestaObtenidaDesdeWs)
        {
            try
            {
                if (envio.CODADUANADECLARACION.Equals(@"118") && (envio.CODTIPOTRANSACCION.Equals(@"0109") || envio.CODTIPOTRANSACCION.Equals(@"0125")))
                {
                    var canalMaster = new CanalMaster
                    {
                        CodigoAduana = envio.CODADUANADECLARACION,
                        AnioManifiesto = envio.ANIOMANIFIESTO,
                        NumeroManifiesto = envio.NROMANIFIESTO,
                        BlMaster = envio.NRODOCUMENTOTRANSPORTE
                    };

                    AdCanalMaster adCanalMaster = new AdCanalMaster();
                    var result = adCanalMaster.RegistrarCanalMasterSql(dbContext, canalMaster, idTransaccionRespuestaObtenidaDesdeWs);

                    Logger.Log(Logger.Level.Info, result.Valor.Equals("success")

                        ? string.Format(@"Manifiesto {0}-{1}-{2} registrado en CanalMaster.",
                            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                            canalMaster.NumeroManifiesto)
                        : string.Format(
                            @"El manifiesto {0}-{1}-{2} ya se encuentra registrado en CanalMaster.",
                            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                            canalMaster.NumeroManifiesto));
                }
            }
            catch (Exception ex)
            {

                Logger.Log(Logger.Level.Error,
                    (String.IsNullOrEmpty(ex.InnerException.Message) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void RegistrarCanalMasterTemp(ref DBAPPTAGSQLEntities dbContext, Entidades.AppTag.Envio envio, Int32 idTransaccionRespuestaObtenidaDesdeWs)
        {
            try
            {
                if (envio.CodAduanaDeclaracion.Equals(@"118") && (envio.CodTipoTransaccion.Equals(@"0109") || envio.CodTipoTransaccion.Equals(@"0125")))
                {
                    

                    var canalMaster = new CanalMaster
                    {
                        CodigoAduana = envio.CodAduanaDeclaracion,
                        AnioManifiesto = envio.AnioManifiesto,
                        NumeroManifiesto = envio.Nromanifiesto,
                        BlMaster = envio.NroDocumentoTransporte
                    };

                    AdCanalMaster adCanalMaster = new AdCanalMaster();
                    var result = adCanalMaster.RegistrarCanalMasterSql(dbContext, canalMaster, idTransaccionRespuestaObtenidaDesdeWs);

                    Logger.Log(Logger.Level.Info, result.Valor.Equals("success")

                        ? string.Format(@"Manifiesto {0}-{1}-{2} registrado en CanalMaster.",
                            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                            canalMaster.NumeroManifiesto)
                        : string.Format(
                            @"El manifiesto {0}-{1}-{2} ya se encuentra registrado en CanalMaster.",
                            canalMaster.CodigoAduana, canalMaster.AnioManifiesto,
                            canalMaster.NumeroManifiesto));
                }
            }
            catch (Exception ex)
            {

                Logger.Log(Logger.Level.Error,
                    (String.IsNullOrEmpty(ex.InnerException.Message) ? ex.Message : ex.InnerException.Message));
            }
        }

        private string fstr_ObtenerValorEtiquetaHijoXML(XmlNode nodo, String strEtiqueta)
        {
            try
            {
                string strValor = string.Empty;
                foreach (XmlNode nodoH in nodo.ChildNodes)
                {
                    if (nodoH is XmlElement)
                    {
                        if (nodoH.Name.Equals(strEtiqueta.Trim()))
                        {
                            strValor = nodoH.InnerText;
                            break;
                        }
                    }
                }
                return strValor;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return string.Empty;
            }
        }

        private int fint_ObtenerRepeticionesHijosXML(XmlNode nodo, String strEtiqueta)
        {
            try
            {
                int intRep = 0;
                foreach (XmlNode nodoH in nodo.ChildNodes)
                {
                    if (nodoH is XmlElement)
                    {
                        if (nodoH.Name.Equals(strEtiqueta.Trim()))
                        {
                            intRep += 1;
                            //break;
                        }
                    }
                }
                return intRep;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return 0;
            }
        }
        
        private Boolean RegistrarDetalleRespuestaSql(DBAPPTAGSQLEntities dbContext, Int32 idTransaccionRespuestaObtenidoDesdeWs, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {

            try
            {
                detalleRespuestaSql = new DETALLERESPUESTA
                {
                    CODIGO = respuestaSql.TDOCCDA,
                    DESCRIPCION = respuestaSql.MENSAJENOTIFICACION,
                    NROMANIFIESTO = respuestaSql.NUMECORRE,
                    TIPODOCCDA = respuestaSql.TDOCCDA,
                    FECHAACEPTACION = respuestaSql.FECHANUMERACION,
                    IDRESPUESTA = respuestaSql.IDRESPUESTA,
                    TIPOMENSAJE = 3
                };
                dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                dbContext.SaveChanges();
                Logger.Log(Logger.Level.Info,
                                String.Format(
                                    "{0} ; Se actualizó [DETALLERESPUESTA] en la base de datos segun el NSIGAD obtenido",
                                    idTransaccionRespuestaObtenidoDesdeWs));

                return true;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean RegistrarInformacionRespuestaSql(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext, Int32 idTransaccionRespuestaObtenidoDesdeWs, ref RESPUESTA respuestaSql)
        {
            try
            {
                string strID = string.Empty;
                Int32 intSecuencia = 0;
                string strInformation = string.Empty;
                string strIssueDateTime = string.Empty;
                string strIDIssue = string.Empty;

                //RECORRER EL DETALLE DE LA RESPUESTA CORRECTA
                if (xDoc.DocumentElement != null)
                {
                    foreach (object nodoReps in xDoc.DocumentElement)
                    {
                        if ((nodoReps) is XmlElement)
                        {
                            if (((XmlElement) nodoReps).Name.Equals("rsm:ReportedProcessingResult"))
                            {
                                foreach (object nodoEps in ((XmlElement) nodoReps).ChildNodes)
                                {
                                    if ((nodoEps) is XmlElement)
                                    {
                                        if (((XmlElement) nodoEps).Name.Equals("userram:SpecifiedSupplyChainConsignment"))
                                        {
                                            foreach (XmlNode nodoE in ((XmlElement) nodoEps).ChildNodes)
                                            {
                                                if ((nodoE) is XmlElement)
                                                {
                                                    if (((XmlElement) nodoE).Name.Equals("ram:SequenceNumeric"))
                                                    {
                                                        if (!string.IsNullOrEmpty(((XmlElement) nodoE).InnerText))
                                                        {
                                                            intSecuencia =
                                                                Convert.ToInt32(
                                                                    Conversions.ToDouble(((XmlElement) nodoE).InnerText));
                                                        }
                                                        //intSecuencia = oclsValidacionDatos.fint_ObtenDatoInt(((XmlElement)NodoE).InnerText);
                                                    }

                                                    if (nodoE.Name.Equals("ram:TransportContractReferencedDocument"))
                                                    {
                                                        foreach (XmlNode nodo in ((XmlElement) nodoE).ChildNodes)
                                                        {
                                                            if ((nodo) is XmlElement)
                                                            {
                                                                if (nodo.Name.Equals("ram:Information"))
                                                                {
                                                                    strInformation = ((XmlElement) nodo).InnerText;
                                                                }
                                                                if (nodo.Name.Equals("ram:ID"))
                                                                {
                                                                    strID =
                                                                        _clsValidacionDatos.fstr_ObtenDato(
                                                                            ((XmlElement) nodo).InnerText);
                                                                }
                                                                if (nodo.Name.Equals("ram:IssueDateTime"))
                                                                {
                                                                    strIssueDateTime =
                                                                        _clsValidacionDatos.fstr_ObtenDato(
                                                                            ((XmlElement) nodo).InnerText);
                                                                }
                                                                if (nodo.Name.Equals("ram:IssueLogisticsLocation"))
                                                                {
                                                                    foreach (
                                                                        XmlNode nod in ((XmlElement) nodo).ChildNodes)
                                                                    {
                                                                        if ((nod) is XmlElement)
                                                                        {
                                                                            if (nod.Name.Equals("ram:ID"))
                                                                            {
                                                                                strIDIssue =
                                                                                    ((XmlElement) nod).InnerText;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                            }
                                                        }
                                                    }

                                                }
                                            }

                                            /////////////////////////////////////////////////////////////////////////////////////////////
                                            // REGISTRAR INFORMACION DE LA RESPUESTA
                                            INFORMACIONRESPUESTA informacionRespuestaSql = new INFORMACIONRESPUESTA
                                            {
                                                IDRESPUESTA = respuestaSql.IDRESPUESTA,
                                                NRODETALLE = intSecuencia,
                                                NRODOCUMENTOORIGEN = strID,
                                                INFORMACION = _clsValidacionDatos.fstr_ObtenDato(strInformation),
                                                CODPUERTO = _clsValidacionDatos.fstr_ObtenDato(strIDIssue)
                                            };

                                            if (!string.IsNullOrEmpty(strIssueDateTime))
                                            {
                                                informacionRespuestaSql.FECHAEMISION =
                                                    Convert.ToDateTime(strIssueDateTime);
                                            }

                                            dbContext.INFORMACIONRESPUESTA.AddObject(informacionRespuestaSql);
                                            dbContext.SaveChanges();
                                            /////////////////////////////////////////////////////////////////////////////////////////////

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Logger.Log(Logger.Level.Info,
                                String.Format(
                                    "{0} ; Se proceso [INFORMACIONRESPUESTA] en la base de datos segun el NSIGAD obtenido",
                                    idTransaccionRespuestaObtenidoDesdeWs));
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarInformacionDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean RegistrarErroresDetalleRespuestaSql(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext, ref RESPUESTA respuestaSql)
        {
            try
            {
                //ERRORES DE LA RESPUESTA
                string strReasonCode = String.Empty, strInformation = String.Empty;

                if (xDoc.DocumentElement != null)
                {
                    foreach (object nodoReps in xDoc.DocumentElement)
                    {
                        if ((nodoReps) is XmlElement)
                        {
                            if (((XmlElement) nodoReps).Name.Equals("rsm:ReportedErrorProcessingStatus"))
                            {
                                foreach (object nodoEps in ((XmlElement) nodoReps).ChildNodes)
                                {
                                    if ((nodoEps) is XmlElement)
                                    {
                                        if (((XmlElement) nodoEps).Name.Equals("userram:ReportedErrorStatus"))
                                        {
                                            foreach (object nodoE in ((XmlElement) nodoEps).ChildNodes)
                                            {
                                                if ((nodoE) is XmlElement)
                                                {
                                                    if (((XmlElement) nodoE).Name.Equals("ram:ReasonCode") &&
                                                        strReasonCode.Trim().Length == 0)
                                                    {
                                                        strReasonCode = ((XmlElement) nodoE).InnerText;
                                                    }
                                                    if (((XmlElement) nodoE).Name.Equals("ram:Information"))
                                                    {
                                                        strInformation = ((XmlElement) nodoE).InnerText;
                                                    }
                                                }
                                            }

                                            /////////////////////////////////////////////////////////////////////////////////////////////
                                            // REGISTRAR ERRORES EN LA RESPUESTA
                                            DETALLERESPUESTA detalleRespuestaSql = new DETALLERESPUESTA
                                            {
                                                CODIGO = strReasonCode,
                                                DESCRIPCION = strInformation,
                                                IDRESPUESTA = respuestaSql.IDRESPUESTA,
                                                TIPOMENSAJE = 1
                                            };
                                            dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                                            dbContext.SaveChanges();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarErroresDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return false;
            }
        }

        private Boolean fbol_RegistrarWarningsDetalleRespuesta(XmlDocument xDoc, DBAPPTAGSQLEntities dbContext, ref RESPUESTA respuestaSql)
        {
            try
            {

                //  LAS ADVERTENCIAS DE LA RESPUESTA
                string strReasonCode = String.Empty, strInformation = String.Empty;
                if (xDoc.DocumentElement != null)
                {
                    foreach (object nodoReps in xDoc.DocumentElement)
                    {
                        if ((nodoReps) is XmlElement)
                        {
                            if (((XmlElement) nodoReps).Name.Equals("rsm:ReportedWarningProcessingStatus"))
                            {
                                foreach (object nodoEps in ((XmlElement) nodoReps).ChildNodes)
                                {
                                    if ((nodoEps) is XmlElement)
                                    {
                                        if (((XmlElement) nodoEps).Name.Equals("userram:ReportedErrorStatus"))
                                        {
                                            foreach (object nodoE in ((XmlElement) nodoEps).ChildNodes)
                                            {
                                                if ((nodoE) is XmlElement)
                                                {
                                                    if (((XmlElement) nodoE).Name.Equals("ram:ReasonCode"))
                                                    {
                                                        strReasonCode =
                                                            _clsValidacionDatos.fstr_ObtenDato(
                                                                ((XmlElement) nodoE).InnerText);
                                                        break;
                                                    }
                                                    if (((XmlElement) nodoE).Name.Equals("ram:Information"))
                                                    {
                                                        strInformation =
                                                            _clsValidacionDatos.fstr_ObtenDato(
                                                                ((XmlElement) nodoE).InnerText);
                                                    }
                                                }
                                            }

                                            /////////////////////////////////////////////////////////////////////////////////////////////
                                            DETALLERESPUESTA detalleRespuestaSql = new DETALLERESPUESTA
                                            {
                                                CODIGO = strReasonCode,
                                                DESCRIPCION = strInformation,
                                                IDRESPUESTA = respuestaSql.IDRESPUESTA,
                                                TIPOMENSAJE = 2
                                            };
                                            dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                                            dbContext.SaveChanges();
                                            break;
                                            /////////////////////////////////////////////////////////////////////////////////////////////

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fbol_RegistrarWarningsDetalleRespuesta", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                //strMensaje = ex.Message;
                return false;
            }
        }

        private bool ValidarFecha(string sdate, ref string strMensaje)
        {
            bool isDate = true;
            try
            {
                DateTime.Parse(sdate);
            }
            catch (Exception ex)
            {
                strMensaje = ex.Message;
                isDate = false;
            }

            return isDate;
        }

        public void RegistrarRespuestaSql(Int32 idEnvio, RespuestaTransWeb oEnRespuesta, Int32 intIdTipoRespuesta, ref RESPUESTA respuestaSql, ref DETALLERESPUESTA detalleRespuestaSql)
        {
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);
                    respuestaSql = new RESPUESTA();
                    respuestaSql.FECHAACEPTACION = DateTime.Now;
                    respuestaSql.FECHAREGISTRO = DateTime.Now;
                    respuestaSql.IDENVIO = idEnvio;
                    respuestaSql.IDTIPORESPUESTA = intIdTipoRespuesta;
                    respuestaSql.IDESTADORESPUESTA = oEnRespuesta.IdTransaccionEnvio > 0 ? 1 : 8;
                    dbContext.RESPUESTA.AddObject(respuestaSql);
                    dbContext.SaveChanges();

                    if (oEnRespuesta.LstErrores != null)
                    {
                        for (int i = 0; i <= oEnRespuesta.LstErrores.Count - 1; i++)
                        {
                            detalleRespuestaSql = new DETALLERESPUESTA();
                            detalleRespuestaSql.CODIGO = oEnRespuesta.LstErrores[i].Codigo;
                            detalleRespuestaSql.DESCRIPCION = oEnRespuesta.LstErrores[i].Descripcion;
                            detalleRespuestaSql.IDRESPUESTA = respuestaSql.IDRESPUESTA;
                            dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                            dbContext.SaveChanges();
                        }
                    }

                    Logger.Log(Logger.Level.Info,
                        "Se registro la respuesta con estado : " + respuestaSql.IDESTADORESPUESTA);
                    dbContext.Dispose();
                    transactionScope.Complete();
                    //return true;
                }
                catch (Exception ex)
                {
                    Logger.Log(Logger.Level.Error, ex.Message);
                    //return false;
                }
            }
        }

        public Boolean ObtenerEnvioSqlPorTransaccion(Int32 idTransaccionEnvio, ref Int32 refIdEnvio, ref string refMensaje)
        {
            try
            {
                DBAPPTAGSQLEntities dbContextSql = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);

                ENVIOS envioSql =
                    (from result in dbContextSql.ENVIOS where result.IDTRANSACCION == idTransaccionEnvio select result)
                        .FirstOrDefault();
                if (envioSql == null)
                {
                    refMensaje = "El envio no existe";
                    return false;
                }
                refIdEnvio = envioSql.IDENVIO;

                return true;
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_RecuperarIdEnvio", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }

        }

        public void GuardarArchivoXmlEnDirectorio(string rutaDirectorio, ref string nombreArchivoXml, byte[] byteArchivo,
            ENVIOS envioSql, ref string refMensaje, Boolean bolCrearJerarquia = false)
        {
            try
            {
                string strFecha = "";
                if (bolCrearJerarquia)
                {
                    strFecha = @"\" + DateTime.Now.Year + @"\" + Right("0" + DateTime.Now.Month, 2) + @"\" +
                               Right("0" + DateTime.Now.Day, 2);
                }
                _clsUtilitarios.fbol_CrearRuta(rutaDirectorio + strFecha, ref refMensaje);
                string strtempo = Right("0" + DateTime.Now.Hour, 2) + Right("0" + DateTime.Now.Minute, 2) +
                                  Right("0" + DateTime.Now.Second, 2) + Right("00" + DateTime.Now.Millisecond, 3);

                if (envioSql != null)
                {

                    strtempo = envioSql.RUCAGENTEADUANA + "_" +
                               envioSql.CODADUANADECLARACION + "_" +
                               (envioSql.CODTIPOTRANSACCION != "" ? envioSql.CODTIPOTRANSACCION.Substring(0, 2) : "") + "_" +
                               envioSql.NUMEROORDEN + "_" +
                               (envioSql.CODTIPOTRANSACCION != "" ? envioSql.CODTIPOTRANSACCION.Substring(2, 2) : "") + "_" +
                               strtempo + "_" +
                               _clsValidacionDatos.fstr_ObtenDato(envioSql.NROTICKET);
                }

                if (nombreArchivoXml.ToLower().StartsWith("acuse"))
                {
                    nombreArchivoXml = "tci_" + nombreArchivoXml;
                    nombreArchivoXml = nombreArchivoXml.Replace(".xml", "_" + strtempo + ".xml");
                }
                else if (nombreArchivoXml.ToLower().StartsWith("nsigad"))
                {
                    nombreArchivoXml = nombreArchivoXml.Replace("nsigad", "tci");
                    nombreArchivoXml = nombreArchivoXml.Replace(".xml", "_" + strtempo + ".xml");
                    nombreArchivoXml = nombreArchivoXml.Replace(nombreArchivoXml.Split('_')[2] + "_", string.Empty);
                }

                //strNombreArchivo = strNombreArchivo.Replace(".xml", "_" + strtempo + ".xml");
                StreamWriter sw = new StreamWriter(rutaDirectorio + strFecha + @"\" + nombreArchivoXml, false,
                    Encoding.GetEncoding("ISO-8859-1"));

                string write = Encoding.GetEncoding("ISO-8859-1").GetString(byteArchivo);
                sw.Write(write);
                sw.Close();
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_WriteFile", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }

        }

        public void GuardarArchivoXmlEnDirectorioTemp(string rutaDirectorio, ref string nombreArchivoXml, byte[] byteArchivo,
            Entidades.AppTag.Envio envioSql, ref string refMensaje, Boolean bolCrearJerarquia = false)
        {
            try
            {
                string strFecha = "";
                if (bolCrearJerarquia)
                {
                    strFecha = @"\" + DateTime.Now.Year + @"\" + Right("0" + DateTime.Now.Month, 2) + @"\" +
                               Right("0" + DateTime.Now.Day, 2);
                }
                _clsUtilitarios.fbol_CrearRuta(rutaDirectorio + strFecha, ref refMensaje);
                string strtempo = Right("0" + DateTime.Now.Hour, 2) + Right("0" + DateTime.Now.Minute, 2) +
                                  Right("0" + DateTime.Now.Second, 2) + Right("00" + DateTime.Now.Millisecond, 3);

                if (envioSql != null)
                {

                    strtempo = envioSql.RucAgenteAduana + "_" +
                               envioSql.CodAduanaDeclaracion + "_" +
                               (envioSql.CodTipoTransaccion != "" ? envioSql.CodTipoTransaccion.Substring(0, 2) : "") + "_" +
                               envioSql.NumeroOrden + "_" +
                               (envioSql.CodTipoTransaccion != "" ? envioSql.CodTipoTransaccion.Substring(2, 2) : "") + "_" +
                               strtempo + "_" +
                               _clsValidacionDatos.fstr_ObtenDato(envioSql.NroTicket);
                }

                if (nombreArchivoXml.ToLower().StartsWith("acuse"))
                {
                    nombreArchivoXml = "tci_" + nombreArchivoXml;
                    nombreArchivoXml = nombreArchivoXml.Replace(".xml", "_" + strtempo + ".xml");
                }
                else if (nombreArchivoXml.ToLower().StartsWith("nsigad"))
                {
                    nombreArchivoXml = nombreArchivoXml.Replace("nsigad", "tci");
                    nombreArchivoXml = nombreArchivoXml.Replace(".xml", "_" + strtempo + ".xml");
                    nombreArchivoXml = nombreArchivoXml.Replace(nombreArchivoXml.Split('_')[2] + "_", string.Empty);
                }

                //strNombreArchivo = strNombreArchivo.Replace(".xml", "_" + strtempo + ".xml");
                StreamWriter sw = new StreamWriter(rutaDirectorio + strFecha + @"\" + nombreArchivoXml, false,
                    Encoding.GetEncoding("ISO-8859-1"));

                string write = Encoding.GetEncoding("ISO-8859-1").GetString(byteArchivo);
                sw.Write(write);
                sw.Close();
            }
            catch (Exception ex)
            {
                //p_RegistrarLog("fnx_WriteFile", ENLogTci.TipoMensaje.Error, ex.Message);
                Logger.Log(Logger.Level.Error, ex.Message);
            }

        }

        private static string Right(string original, int numberCharacters)
        {
            return original.Substring(original.Length - numberCharacters);
        }

    }
}
