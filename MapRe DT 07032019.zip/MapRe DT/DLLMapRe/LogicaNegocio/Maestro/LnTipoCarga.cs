﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnTipoCarga
    {
        private readonly AdTipoCarga _adTipoCarga = new AdTipoCarga();

        public TipoCarga ObtenerPorCodigo(string codigoTipoCarga)
        {
            return _adTipoCarga.ObtenerPorCodigo(codigoTipoCarga);
        }
    }
}
