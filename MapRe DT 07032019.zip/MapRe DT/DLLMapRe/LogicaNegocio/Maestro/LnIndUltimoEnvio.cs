﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnIndUltimoEnvio
    {
        private readonly AdIndUltimoEnvio _adTipoCarga = new AdIndUltimoEnvio();

        public IndUltimoEnvio ObtenerPorCodigo(string codigoTipoCarga)
        {
            return _adTipoCarga.ObtenerPorCodigo(codigoTipoCarga);
        }
    }
}
