﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnTipoTransaccion
    {
        private readonly AdTipoTransaccion _adTipoTransaccion = new AdTipoTransaccion();

        public TipoTransaccion ObtenerPorCodigo(string codigoTipoTransaccion)
        {
            return _adTipoTransaccion.ObtenerPorCodigo(codigoTipoTransaccion);
        }
    }
}
