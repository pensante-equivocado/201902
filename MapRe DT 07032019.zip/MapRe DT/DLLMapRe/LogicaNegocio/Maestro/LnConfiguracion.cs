﻿using System;
using DLLMapRe.AccesoDatos.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnConfiguracion
    {
        private readonly AdConfiguracion _adConfiguracion = new AdConfiguracion();

        public Entidades.Maestro.Configuracion ObtenerPorId(Int32 idConfiguracion)
        {
            return _adConfiguracion.ObtenerPorId(idConfiguracion);
        }
    }
}
