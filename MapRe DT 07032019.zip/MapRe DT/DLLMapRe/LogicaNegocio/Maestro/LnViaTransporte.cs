﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnViaTransporte
    {
        private readonly AdViaTransporte _adViaTransporte = new AdViaTransporte();

        public ViaTransporte ObtenerPorCodigo(string codigoViaTransporte)
        {
            return _adViaTransporte.ObtenerPorCodigo(codigoViaTransporte);
        }
    }
}
