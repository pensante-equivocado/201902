﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnTipoManifiesto
    {
        private readonly AdTipoManifiesto _adTipoManifiesto = new AdTipoManifiesto();

        public TipoManifiesto ObtenerPorCodigo(string codigoTipoManifiesto)
        {
            return _adTipoManifiesto.ObtenerPorCodigo(codigoTipoManifiesto);
        }
    }
}
