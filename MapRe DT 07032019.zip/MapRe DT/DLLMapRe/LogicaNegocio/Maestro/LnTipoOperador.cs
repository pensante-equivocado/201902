﻿using DLLMapRe.AccesoDatos.Maestro;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.LogicaNegocio.Maestro
{
    public class LnTipoOperador
    {
        private readonly AdTipoOperador _adTipoOperador = new AdTipoOperador();

        public TipoOperador ObtenerPorCodigo(string codigoTipoOperador)
        {
            return _adTipoOperador.ObtenerPorCodigo(codigoTipoOperador);
        }
    }
}
