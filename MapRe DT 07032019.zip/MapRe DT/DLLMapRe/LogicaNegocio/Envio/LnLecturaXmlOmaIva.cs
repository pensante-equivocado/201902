﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Xml;
using System.Xml.XPath;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.XmlOma;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnLecturaXmlOmaIva: Logger
    {
        private DeclarationMetaData _declarationMetaData;
        public DeclarationMetaData LeerAreaDeclaration(XPathNavigator nav, string rutaPrincipal)
        {
            _declarationMetaData = new DeclarationMetaData();
            try
            {
                XmlNamespaceManager ns = null;
                if (nav.NameTable != null)
                {
                    ns = new XmlNamespaceManager(nav.NameTable);
                    ns.AddNamespace("root", "urn:wco:datamodel:PE:DocumentMetaData:1");
                    ns.AddNamespace("dec", "urn:wco:datamodel:PE:Declaration:1");
                    ns.AddNamespace("ds", "urn:wco:datamodel:PE:Declaration_DS:1");
                }

                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:Declaration");

                Declaration declaration = new Declaration
                {
                    NumeroReferenciaEmisor = SelectNodeValue(rutaPrincipal, "/dec:FunctionalReferenceID", nav, ns)
                };
                _declarationMetaData.Declaration = declaration;

                LeerAreaDeclarationSubmitter(nav, ns, rutaPrincipal);
                LeerAreaDeclarationAdditionalDocument(nav, ns);
                LeerAreaDeclarationBorderTransportMeans(nav, ns, rutaPrincipal);
                LeerAreaDeclarationConsignment(nav, ns);//, rutaPrincipal);
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
            return _declarationMetaData;

        }

        private void LeerAreaDeclarationSubmitter(XPathNavigator nav, XmlNamespaceManager ns, string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:Submitter");
                DeclarationSubmitter declarationSubmitter = new DeclarationSubmitter
                {
                    IdentificacionDelQueEnvia = SelectNodeValue(rutaPrincipal, "/dec:ID", nav, ns),
                    TipoOperadorQueEnviaMensaje = SelectNodeValue(rutaPrincipal, "/dec:RoleCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationSubmitter = declarationSubmitter;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationAdditionalDocument(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                XPathNodeIterator nodosDeclarationAdditionalDocument =
                                    nav.Select("descendant::dec:AdditionalDocument", ns);
                while (nodosDeclarationAdditionalDocument.MoveNext())
                {
                    var typeCode = SelectNodeValue("", "dec:TypeCode", nodosDeclarationAdditionalDocument.Current, ns);

                    switch (typeCode)
                    {
                        case "785":
                            LeerAreaDeclarationAdditionalDocument785(nodosDeclarationAdditionalDocument.Current, ns);
                            break;
                        case "14":
                            LeerAreaDeclarationAdditionalDocument14(nodosDeclarationAdditionalDocument.Current, ns);
                            break;
                    }

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }

        }

        private void LeerAreaDeclarationAdditionalDocument785(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                DeclarationAdditionalDocument785 declarationAdditionalDocument785 = new DeclarationAdditionalDocument785
                {
                    TipoManifiestoCarga = SelectNodeValue("", "dec:CategoryCode", nav, ns),
                    AnioManifiestoCarga = SelectNodeValue("", "dec:IssueDateTime/ds:DateTimeString", nav, ns),
                    CodigoAduanaManifiestoCarga = SelectNodeValue("", "dec:issueLocationID", nav, ns),
                    NumeroManifiestoCarga = SelectNodeValue("", "dec:ID", nav, ns),
                    TypeCode = SelectNodeValue("", "dec:TypeCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationAdditionalDocument785 =
                    declarationAdditionalDocument785;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationAdditionalDocument14(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                DeclarationAdditionalDocument14 declarationAdditionalDocument14 = new DeclarationAdditionalDocument14
                {
                    NumeroManifiestoCarga = SelectNodeValue("", "dec:ID", nav, ns),
                    TypeCode = SelectNodeValue("", "dec:TypeCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationAdditionalDocument14 = declarationAdditionalDocument14;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationBorderTransportMeans(XPathNavigator nav, XmlNamespaceManager ns,
            string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:BorderTransportMeans");
                DeclarationBorderTransportMeans declarationBorderTransportMeans = new DeclarationBorderTransportMeans
                {
                    ViaTransporte = SelectNodeValue(rutaPrincipal, "/dec:ModeCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationBorderTransportMeans = declarationBorderTransportMeans;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationConsignment(XPathNavigator nav, XmlNamespaceManager ns)//, string rutaPrincipal)
        {
            try
            {
                List<DeclarationConsignmentIva> listaDeclarationConsignment = new List<DeclarationConsignmentIva>();
                XPathNodeIterator nodosDeclarationConsignment1 = nav.Select("descendant::dec:Consignment", ns);
                while (nodosDeclarationConsignment1.MoveNext())
                {
                    DeclarationConsignmentIva declarationConsignment = new DeclarationConsignmentIva();
                    declarationConsignment.NumeroDetalle = SelectNodeValue("", "dec:SequenceNumeric", nodosDeclarationConsignment1.Current, ns);
                    declarationConsignment.NumeroDocumentoTransporte =
                        LeerAreaDeclarationConsignmentTransportContractDocument(nodosDeclarationConsignment1.Current, ns);
                    declarationConsignment.CodigoTipoCarga =
                        LeerAreaDeclarationConsignmentAdditionalInformation(nodosDeclarationConsignment1.Current, ns);
                    LeerAreaDeclarationConsignmentConsignmentItem(nodosDeclarationConsignment1.Current, ns,
                            ref declarationConsignment);//, rutaPrincipal);
                    listaDeclarationConsignment.Add(declarationConsignment);
                }

                _declarationMetaData.Declaration.CantidadDeclarationConsignment = 0;
                //if (listaDeclarationConsignment.Any())
                //{
                //    _declarationMetaData.Declaration.CantidadDeclarationConsignment = listaDeclarationConsignment.Count;
                //}

                _declarationMetaData.Declaration.ListaDeclarationConsignmentIva = listaDeclarationConsignment;
                
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationConsignmentConsignmentItem(XPathNavigator nav, XmlNamespaceManager ns, ref DeclarationConsignmentIva declarationConsignment)//, string rutaPrincipal)
        {
            try
            {
                string vinVehiculo = string.Empty;
                string numeroEquipamiento = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentConsignmentItem = nav.Select("descendant::dec:ConsignmentItem", ns);
                while (nodosDeclarationConsignmentConsignmentItem.MoveNext())
                {
                    //Número chasis o VIN de vehiculos
                    //Commodity
                    if (String.IsNullOrEmpty(vinVehiculo))
                    {
                        vinVehiculo = LeerAreaDeclarationConsignmentConsignmentItemCommodity(
                            nodosDeclarationConsignmentConsignmentItem.Current, ns);
                    }

                    //Numero de Equipamiento
                    //TransportEquipment
                    if (String.IsNullOrEmpty(numeroEquipamiento))
                    {
                        numeroEquipamiento = LeerAreaDeclarationConsignmentConsignmentItemTransportEquipment(
                            nodosDeclarationConsignmentConsignmentItem.Current, ns);
                    }

                }

                declarationConsignment.VinDeVehiculo = vinVehiculo;
                declarationConsignment.NumeroDeEquipamiento = numeroEquipamiento;

            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }

        }

        private string LeerAreaDeclarationConsignmentConsignmentItemCommodity(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                string vinVehiculo = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentConsignmentItemCommodity =
                                    nav.Select("descendant::dec:Commodity", ns);
                while (nodosDeclarationConsignmentConsignmentItemCommodity.MoveNext())
                {
                    vinVehiculo = LeerAreaDeclarationConsignmentConsignmentItemCommodityProductCharacteristics(
                        nodosDeclarationConsignmentConsignmentItemCommodity.Current, ns);
                    if (!String.IsNullOrEmpty(vinVehiculo))
                    {
                        return vinVehiculo;
                    }
                }
                return vinVehiculo;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return string.Empty;
            }

        }

        private string LeerAreaDeclarationConsignmentConsignmentItemCommodityProductCharacteristics(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                string description = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentConsignmentItemCommodityProductCharacteristics =
                                    nav.Select("descendant::dec:ProductCharacteristics", ns);
                while (nodosDeclarationConsignmentConsignmentItemCommodityProductCharacteristics.MoveNext())
                {
                    var qualifierCode = SelectNodeValue("", "dec:QualifierCode",
                        nodosDeclarationConsignmentConsignmentItemCommodityProductCharacteristics.Current, ns);
                    if (qualifierCode.Equals("140"))
                    {
                        description = SelectNodeValue("", "dec:Description",
                            nodosDeclarationConsignmentConsignmentItemCommodityProductCharacteristics.Current, ns);
                    }
                }

                return description;

            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return string.Empty;
            }

        }

        private string LeerAreaDeclarationConsignmentConsignmentItemTransportEquipment(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                string numeroEquipamiento = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentConsignmentItemTransportAquipment =
                                    nav.Select("descendant::dec:TransportEquipment", ns);
                while (nodosDeclarationConsignmentConsignmentItemTransportAquipment.MoveNext())
                {

                    numeroEquipamiento = SelectNodeValue("", "dec:ID",
                        nodosDeclarationConsignmentConsignmentItemTransportAquipment.Current, ns);
                    if (!String.IsNullOrEmpty(numeroEquipamiento))
                    {
                        return numeroEquipamiento;
                    }
                }

                return numeroEquipamiento;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return string.Empty;
            }

        }

        private string LeerAreaDeclarationConsignmentAdditionalInformation(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                string codigoTipoCarga = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentAdditionalInformation =
                    nav.Select("descendant::dec:AdditionalInformation", ns);
                while (nodosDeclarationConsignmentAdditionalInformation.MoveNext())
                {
                    string tipo = SelectNodeValue("", "dec:StatementTypeCode", nodosDeclarationConsignmentAdditionalInformation.Current, ns);
                    if (!String.IsNullOrEmpty(tipo))
                    {
                        codigoTipoCarga = SelectNodeValue("", "dec:StatementCode", nodosDeclarationConsignmentAdditionalInformation.Current, ns);    
                    }
                    if (!String.IsNullOrEmpty(codigoTipoCarga))
                    {
                        return codigoTipoCarga;
                    }
                }

                return codigoTipoCarga;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return string.Empty;
            }

        }

        private string LeerAreaDeclarationConsignmentTransportContractDocument(XPathNavigator nav, XmlNamespaceManager ns)
        {
            try
            {
                string id = string.Empty;
                XPathNodeIterator nodosDeclarationConsignmentTransportContractDocument =
                    nav.Select("descendant::dec:TransportContractDocument", ns);
                while (nodosDeclarationConsignmentTransportContractDocument.MoveNext())
                {
                    id = SelectNodeValue("", "dec:ID", nodosDeclarationConsignmentTransportContractDocument.Current, ns);
                }

                return id;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return string.Empty;
            }

        }

        private static string SelectNodeValue(string rutaPrincipal, string rutaComplemento, XPathNavigator nav, XmlNamespaceManager ns)
        {
            var nodo = nav.SelectSingleNode(String.Concat(rutaPrincipal, rutaComplemento), ns);
            return NodeValue(nodo);
        }

        public static string NodeValue(XPathItem node)
        {
            string defaultValue = string.Empty;
            if (node != null)
            {
                return node.Value ?? defaultValue;
            }

            return defaultValue;
        }
    }
}
