﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.XPath;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.XmlOma;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnLecturaXmlOmaIrm: Logger
    {
        private DeclarationMetaData _declarationMetaData;
        public DeclarationMetaData LeerAreaDeclaration(XPathNavigator nav, string rutaPrincipal)
        {
            _declarationMetaData = new DeclarationMetaData();
            try
            {
                XmlNamespaceManager ns = null;
                if (nav.NameTable != null)
                {
                    ns = new XmlNamespaceManager(nav.NameTable);
                    ns.AddNamespace("root", "urn:wco:datamodel:PE:DocumentMetaData:1");
                    ns.AddNamespace("dec", "urn:wco:datamodel:PE:Declaration:1");
                    ns.AddNamespace("ds", "urn:wco:datamodel:PE:Declaration_DS:1");
                }

                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:Declaration");

                Declaration declaration = new Declaration
                {
                    NumeroReferenciaEmisor = SelectNodeValue(rutaPrincipal, "/dec:FunctionalReferenceID", nav, ns)
                };
                _declarationMetaData.Declaration = declaration;

                LeerAreaDeclarationSubmitter(nav, ns, rutaPrincipal);
                LeerAreaDeclarationAdditionalDocument(nav, ns, rutaPrincipal);
                LeerAreaDeclarationBorderTransportMeans(nav, ns, rutaPrincipal);
                LeerAreaDeclarationConsignment(nav, ns, rutaPrincipal);
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
            return _declarationMetaData;

        }

        private void LeerAreaDeclarationSubmitter(XPathNavigator nav, XmlNamespaceManager ns, string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:Submitter");
                DeclarationSubmitter declarationSubmitter = new DeclarationSubmitter
                {
                    IdentificacionDelQueEnvia = SelectNodeValue(rutaPrincipal, "/dec:ID", nav, ns),
                    TipoOperadorQueEnviaMensaje = SelectNodeValue(rutaPrincipal, "/dec:RoleCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationSubmitter = declarationSubmitter;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationAdditionalDocument(XPathNavigator nav, XmlNamespaceManager ns, string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:AdditionalDocument");
                DeclarationAdditionalDocument785 declarationAdditionalDocument = new DeclarationAdditionalDocument785
                {
                    TipoManifiestoCarga = SelectNodeValue(rutaPrincipal, "/dec:CategoryCode", nav, ns),
                    AnioManifiestoCarga = SelectNodeValue(rutaPrincipal, "/dec:IssueDateTime/ds:DateTimeString", nav, ns),
                    CodigoAduanaManifiestoCarga = SelectNodeValue(rutaPrincipal, "/dec:issueLocationID", nav, ns),
                    NumeroManifiestoCarga = SelectNodeValue(rutaPrincipal, "/dec:ID", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationAdditionalDocument785 = declarationAdditionalDocument;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }


            //XPathNodeIterator nodosAdditionalDocument = nav.Select(rutaPrincipal, ns);
            //while (nodosAdditionalDocument.MoveNext())
            //{
            //    var categoryCode = SelectNodeValue("", "dec:CategoryCode", nodosAdditionalDocument.Current, ns);
            //    var issueDateTime = SelectNodeValue("", "dec:IssueDateTime/ds:DateTimeString", nodosAdditionalDocument.Current, ns);
            //    var issueLocationId = SelectNodeValue("", "dec:issueLocationID", nodosAdditionalDocument.Current, ns);
            //    var id = SelectNodeValue("", "dec:ID", nodosAdditionalDocument.Current, ns);
            //}

        }

        private void LeerAreaDeclarationBorderTransportMeans(XPathNavigator nav, XmlNamespaceManager ns,
            string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:BorderTransportMeans");
                DeclarationBorderTransportMeans declarationBorderTransportMeans = new DeclarationBorderTransportMeans
                {
                    ViaTransporte = SelectNodeValue(rutaPrincipal, "/dec:ModeCode", nav, ns)
                };
                _declarationMetaData.Declaration.DeclarationBorderTransportMeans = declarationBorderTransportMeans;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationConsignment(XPathNavigator nav, XmlNamespaceManager ns, string rutaPrincipal)
        {
            try
            {
                rutaPrincipal = String.Concat(rutaPrincipal, "/dec:Consignment");

                XPathNodeIterator nodosDeclarationConsignment = nav.Select(rutaPrincipal, ns);
                List<DeclarationConsignmentIrm> listaDeclarationConsignment = new List<DeclarationConsignmentIrm>();
                while (nodosDeclarationConsignment.MoveNext())
                {
                    DeclarationConsignmentIrm declarationConsignment = new DeclarationConsignmentIrm
                    {
                        NumeroDetalle = SelectNodeValue("", "dec:SequenceNumeric",
                            nodosDeclarationConsignment.Current, ns)
                    };

                    LeerAreaDeclarationConsignmentTransportContractDocument(nodosDeclarationConsignment.Current, ns,
                        ref declarationConsignment);

                    listaDeclarationConsignment.Add(declarationConsignment);
                }

                _declarationMetaData.Declaration.CantidadDeclarationConsignment = 0;
                //if (listaDeclarationConsignment.Any())
                //{
                //    _declarationMetaData.Declaration.CantidadDeclarationConsignment = listaDeclarationConsignment.Count;
                //}

                _declarationMetaData.Declaration.ListaDeclarationConsignmentIrm = listaDeclarationConsignment;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }
        }

        private void LeerAreaDeclarationConsignmentTransportContractDocument(XPathNavigator nav, XmlNamespaceManager ns, ref DeclarationConsignmentIrm declarationConsignment)
        {
            try
            {
                XPathNodeIterator nodosDeclarationConsignmentTransportContractDocument =
                    nav.Select("descendant::dec:TransportContractDocument", ns);
                List<DeclarationConsignmentTransportContractDocument>
                    listaDeclarationConsignmentTransportContractDocuments =
                        new List<DeclarationConsignmentTransportContractDocument>();
                while (nodosDeclarationConsignmentTransportContractDocument.MoveNext())
                {
                    DeclarationConsignmentTransportContractDocument declarationConsignmentTransportContractDocument = new DeclarationConsignmentTransportContractDocument
                    {
                        NumeroDocumentoTransporte =
                            SelectNodeValue("", "dec:ID", nodosDeclarationConsignmentTransportContractDocument.Current,
                                ns)
                    };
                    listaDeclarationConsignmentTransportContractDocuments.Add(
                        declarationConsignmentTransportContractDocument);
                }
                declarationConsignment.DeclarationConsignmentTransportContractDocument =
                    listaDeclarationConsignmentTransportContractDocuments.FirstOrDefault();
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
            }

        }

        private static string SelectNodeValue(string rutaPrincipal, string rutaComplemento, XPathNavigator nav, XmlNamespaceManager ns)
        {
            var nodo = nav.SelectSingleNode(String.Concat(rutaPrincipal, rutaComplemento), ns);
            return NodeValue(nodo);
        }

        public static string NodeValue(XPathItem node)
        {
            string defaultValue = string.Empty;
            if (node != null)
            {
                return node.Value ?? defaultValue;
            }

            return defaultValue;
        }
    }
}
