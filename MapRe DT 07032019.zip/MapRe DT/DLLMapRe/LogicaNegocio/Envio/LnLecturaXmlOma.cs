﻿using System;
using System.Linq;
using System.Xml;
using System.Xml.XPath;
using DLLMapRe.Configuracion.Proceso;
//using DLLMapRe.Entidades;
using DLLMapRe.Entidades.XmlOma;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnLecturaXmlOma: Logger
    {
        //http://www.sunat.gob.pe/operatividadaduanera/fast/estructuras/formato-Mani-Ingreso.html
        private DeclarationMetaData _declarationMetaData;
        public Boolean ValidarEstructura(string rutaCompletaXml, ref string codigoTransaccion)
        {
            try
            {

                XmlDocument doc = new XmlDocument();
                doc.Load(rutaCompletaXml);
                XPathDocument xmlComprobante = new XPathDocument(new XmlNodeReader(doc));
                var nav = xmlComprobante.CreateNavigator();

                XmlNamespaceManager ns = null;
                if (nav.NameTable != null)
                {
                    ns = new XmlNamespaceManager(nav.NameTable);
                    ns.AddNamespace("root", "urn:wco:datamodel:PE:DocumentMetaData:1");
                    ns.AddNamespace("ds", "urn:wco:datamodel:PE:MetaData_DS:1");
                }

                const string rutaPrincipal = "/root:DeclarationMetaData";

                var functionalDefinition = SelectNodeValue(rutaPrincipal, "/root:FunctionalDefinition", nav, ns);
                if (!String.IsNullOrEmpty(functionalDefinition))
                {
                    //Es OMA
                    codigoTransaccion = functionalDefinition;
                    return true;
                }
                else
                {
                    //Es Cuscar
                    codigoTransaccion = "";
                    return false;

                }
            }
            catch (Exception ex)
            {
                Log(Level.Info, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return false;
            }

        }

        public DeclarationMetaData LeerArchivoXml(string rutaCompletaXml, ref Entidades.AppTag.Envio envio)//  ref ENVIOS envio)
        {
            _declarationMetaData = new DeclarationMetaData();
            try
            {

                XmlDocument doc = new XmlDocument();
                doc.Load(rutaCompletaXml);
                XPathDocument xmlComprobante = new XPathDocument(new XmlNodeReader(doc));
                var nav = xmlComprobante.CreateNavigator();

                XmlNamespaceManager ns = null;
                if (nav.NameTable != null)
                {
                    ns = new XmlNamespaceManager(nav.NameTable);
                    ns.AddNamespace("root", "urn:wco:datamodel:PE:DocumentMetaData:1");
                    ns.AddNamespace("ds", "urn:wco:datamodel:PE:MetaData_DS:1");
                }

                const string rutaPrincipal = "/root:DeclarationMetaData";
                var functionalDefinition = SelectNodeValue(rutaPrincipal, "/root:FunctionalDefinition", nav, ns);

                switch (functionalDefinition)
                {
                    case "0121"://IRM Numeracion Maritima
                    case "0122"://IRM Rectificacion Maritima
                    case "0321"://IRM Numeracion Terrestre
                    case "0322"://IRM Rectificacion Terrestre
                    case "0421"://IRM Numeracion Aereo
                    case "0422"://IRM Rectificacion Aereo
                    case "0821"://IRM Numeracion Fluvial
                    case "0822"://IRM Rectificacion Fluvial
                    {
                        LnLecturaXmlOmaIrm lpLecturaXmlOmaIrm = new LnLecturaXmlOmaIrm();
                        _declarationMetaData = lpLecturaXmlOmaIrm.LeerAreaDeclaration(nav, rutaPrincipal);
                        break;
                    }
                    case "0115"://Acta Inventario Maritima (Por contenedor y carga suelta)
                    case "0315"://Acta Inventario Terrestre (Por contenedor y carga suelta)
                    case "0415"://Acta Inventario Aereo (Por carga suelta)
                    case "0815"://Acta Inventario Fluvial (Por contenedor y carga suelta)
                    {
                        LnLecturaXmlOmaActaInventario lpLecturaXmlOmaActaInventario = new LnLecturaXmlOmaActaInventario();
                        _declarationMetaData = lpLecturaXmlOmaActaInventario.LeerAreaDeclaration(nav, rutaPrincipal);
                        break;
                    }
                    case "0125"://IVA Numeracion Maritima
                    case "0325"://IVA Numeracion Terrestre
                    case "0425"://IVA Numeracion Aereo
                    case "0825"://IVA Numeracion Fluvial
                    {
                        LnLecturaXmlOmaIva lpLecturaXmlOmaIva = new LnLecturaXmlOmaIva();
                        _declarationMetaData = lpLecturaXmlOmaIva.LeerAreaDeclaration(nav, rutaPrincipal);
                        break;
                    }
                }

                if (_declarationMetaData != null) _declarationMetaData.NumeroTransaccion = functionalDefinition;
                AsignarValoresEnvio(functionalDefinition, ref envio);

                return _declarationMetaData;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return null;
            }
            
        }

        private void AsignarValoresEnvio(string codigoTransaccion, ref Entidades.AppTag.Envio envio)// ref ENVIOS envio)
        {
            if (_declarationMetaData != null)
            {
                envio.NumeroOrden = _declarationMetaData.Declaration.NumeroReferenciaEmisor;
                envio.RucAgenteAduana = _declarationMetaData.Declaration.DeclarationSubmitter.IdentificacionDelQueEnvia;
                envio.CodAduanaDeclaracion = _declarationMetaData.Declaration.DeclarationAdditionalDocument785.CodigoAduanaManifiestoCarga;
                envio.Nromanifiesto = _declarationMetaData.Declaration.DeclarationAdditionalDocument785.NumeroManifiestoCarga;
                envio.AnioManifiesto = _declarationMetaData.Declaration.DeclarationAdditionalDocument785.AnioManifiestoCarga;
                envio.IdUsuario = null;
                
            }

            switch (codigoTransaccion)
            {
                case "0121"://IRM Numeracion Maritima
                case "0122"://IRM Rectificacion Maritima
                case "0321"://IRM Numeracion Terrestre
                case "0322"://IRM Rectificacion Terrestre
                case "0421"://IRM Numeracion Aereo
                case "0422"://IRM Rectificacion Aereo
                case "0821"://IRM Numeracion Fluvial
                case "0822"://IRM Rectificacion Fluvial
                    {
                        if (_declarationMetaData != null)
                        {

                            if (_declarationMetaData.Declaration.ListaDeclarationConsignmentIrm.Any())
                            {

                                var nroDocumentoTransporte =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentIrm.First()
                                        .DeclarationConsignmentTransportContractDocument.NumeroDocumentoTransporte;
                                if (!String.IsNullOrEmpty(nroDocumentoTransporte))
                                {
                                    envio.NroDocumentoTransporte = nroDocumentoTransporte;
                                }

                                var sequenceNumeric =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentIrm.First().NumeroDetalle;
                                if (!String.IsNullOrEmpty(sequenceNumeric))
                                {
                                    envio.NroDetalle = Convert.ToInt32(sequenceNumeric);
                                }
                            }
                            
                        }
                        break;
                    }
                case "0115"://Acta Inventario Maritima (Por contenedor y carga suelta)
                case "0315"://Acta Inventario Terrestre (Por contenedor y carga suelta)
                case "0415"://Acta Inventario Aereo (Por carga suelta)
                case "0815"://Acta Inventario Fluvial (Por contenedor y carga suelta)
                    {
                        if (_declarationMetaData != null)
                        {
                            if (_declarationMetaData.Declaration.ListaDeclarationConsignmentActaInventario.Any())
                            {

                                var nroDocumentoTransporte =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentActaInventario.First()
                                        .DeclarationConsignmentTransportContractDocument.NumeroDocumentoTransporte;
                                if (!String.IsNullOrEmpty(nroDocumentoTransporte))
                                {
                                    envio.NroDocumentoTransporte = nroDocumentoTransporte;
                                }

                                var sequenceNumeric =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentActaInventario.First().NumeroDetalle;
                                if (!String.IsNullOrEmpty(sequenceNumeric))
                                {
                                    envio.NroDetalle = Convert.ToInt32(sequenceNumeric);
                                }
                            }
                            envio.CantidadCarga = Convert.ToInt32(_declarationMetaData.Declaration.CantidadDeclarationConsignment);
                        }
                        break;
                    }
                case "0125"://IVA Numeracion Maritima
                case "0325"://IVA Numeracion Terrestre
                case "0425"://IVA Numeracion Aereo
                case "0825"://IVA Numeracion Fluvial
                    {
                        if (_declarationMetaData != null)
                        {
                            if (_declarationMetaData.Declaration.ListaDeclarationConsignmentIva.Any())
                            {

                                var nroDocumentoTransporte =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentIva.First()
                                        .NumeroDocumentoTransporte;
                                if (!String.IsNullOrEmpty(nroDocumentoTransporte))
                                {
                                    envio.NroDocumentoTransporte = nroDocumentoTransporte;
                                }

                                var sequenceNumeric =
                                    _declarationMetaData.Declaration.ListaDeclarationConsignmentIva.First()
                                        .NumeroDetalle;
                                if (!String.IsNullOrEmpty(sequenceNumeric))
                                {
                                    envio.NroDetalle = Convert.ToInt32(sequenceNumeric);
                                }
                            }
                        }
                        break;
                    }  
            }
        }
        
        private static string SelectNodeValue(string rutaPrincipal, string rutaComplemento, XPathNavigator nav, XmlNamespaceManager ns)
        {
            var nodo = nav.SelectSingleNode(String.Concat(rutaPrincipal, rutaComplemento), ns);
            return NodeValue(nodo);
        }

        public static string NodeValue(XPathItem node)
        {
            string defaultValue = string.Empty;
            if (node != null)
            {
                return node.Value ?? defaultValue;
            }

            return defaultValue;
        }
    }
}
