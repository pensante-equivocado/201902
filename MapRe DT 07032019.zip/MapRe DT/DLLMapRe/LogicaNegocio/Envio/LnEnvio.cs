﻿using System;
using System.Collections.Generic;
using System.Transactions;
using DLLMapRe.AccesoDatos;
using DLLMapRe.AccesoDatos.AppTagEnvio;
using DLLMapRe.AccesoDatos.AppTagRespuesta;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades;
using DLLMapRe.Entidades.AppTag;
using DLLMapRe.Entidades.Maestro;
using DLLMapRe.Entidades.XmlOma;
using DLLMapRe.LogicaNegocio.Maestro;
using DLLTransWeb.Entidades.Respuesta;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnEnvio: Logger
    {
        private readonly AdEnvio _adEnvio = new AdEnvio();

        public Boolean RegistrarEnvioSql(Entidades.AppTag.Envio envio, //ENVIOS envio, 
            RespuestaTransWeb enRespuesta,
            Boolean bolValidacion, List<string> listaErrores, Boolean indicadorTipoAmbiente, string nombreZip, DeclarationMetaData lectura = null)
        {

            try
            {
                Int32 idEnvioNuevo = -1;
                AdEnvio adEnvio = new AdEnvio();
                using (TransactionScope transactionScope = new TransactionScope())
                {
                    //DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql);// strCadenaConexion);
                    envio.FechaTci = DateTime.Now;
                    if (bolValidacion)
                    {
                        envio.IdEstadoTci = enRespuesta.IdTransaccionEnvio > 0 ? 1 : 8;
                    }
                    else
                    {
                        envio.IdEstadoTci = 0;
                    }

                    envio.IdEstadoAcuse = 0;
                    envio.IdEstadoRespuesta = 0;
                    envio.IdTransaccion = enRespuesta.IdTransaccionEnvio;
                    envio.PasoEsquema = bolValidacion ? 1 : 0;
                    envio.TipoAmbiente = indicadorTipoAmbiente;

                    ObtenerDatosExtrasEnvio(ref envio, lectura);

                    Int32 envioResult = adEnvio.Registrar(envio, ref idEnvioNuevo);
                    //dbContext.ENVIOS.AddObject(envio);
                    //dbContext.SaveChanges();

                    if (envioResult > 0)
                    {
                        Log(Level.Info,
                            String.Format("{0} ; Se registro el envio con 'Estado TCI': {1}", nombreZip,
                                envio.IdEstadoTci));

                        Int32 intTipoRespuesta = enRespuesta.IdTransaccionEnvio > 0 ? 1 : 4;


                        if (bolValidacion)
                        {

                            RegistrarRespuestaSql(idEnvioNuevo, //envio.IdEnvio, 
                                enRespuesta, intTipoRespuesta, nombreZip);
                        }

                        if (listaErrores.Count > 0)
                        {
                            AdErrorEnvio adErrorEnvio = new AdErrorEnvio();
                            for (int i = 0; i <= listaErrores.Count - 1; i++)
                            {
                                ErrorEnvio errorEnvioSql = new ErrorEnvio();
                                //ERRORENVIO errorEnvioSql = new ERRORENVIO();
                                errorEnvioSql.IdEnvio = idEnvioNuevo;//envio.IdEnvio;
                                errorEnvioSql.Descripcion = listaErrores[i];
                                errorEnvioSql.FechaRegistro = DateTime.Now;
                                //dbContext.ERRORENVIO.AddObject(errorEnvioSql);
                                //dbContext.SaveChanges();

                                Int32 idErrorEnvioNuevo = -1;
                                adErrorEnvio.Registrar(errorEnvioSql, ref idErrorEnvioNuevo);
                            }
                        }

                        if (lectura != null)
                        {
                            if (idEnvioNuevo > 0)
                            {
                                RegistrarDocumentosTransporte(idEnvioNuevo, lectura);
                                
                            }
                            else
                            {
                                return false;
                            }
                        }

                        //dbContext.Dispose();
                        transactionScope.Complete();

                    }

                }
                
                return true;
            }
            catch (Exception ex)
            {
                Log(Level.Error, ex.Message + " - " + ex.InnerException);
                return false;
            }

        }

        private void RegistrarDocumentosTransporte(Int32 idEnvio, DeclarationMetaData lectura)
        {
            try
            {
                LnDocumentoTransporteEnvio lnDocumentoTransporteEnvio = new LnDocumentoTransporteEnvio();
                string transaccion = lectura.NumeroTransaccion;
                if (transaccion.Equals("0125")) //iva maritimo
                {
                    if (lectura.Declaration.ListaDeclarationConsignmentIva != null)
                    {
                        foreach (var iva in lectura.Declaration.ListaDeclarationConsignmentIva)
                        {
                            DocumentoTransporteEnvio documentoTransporteEnvio = new DocumentoTransporteEnvio();
                            documentoTransporteEnvio.IdEnvio = idEnvio;
                            if (String.IsNullOrEmpty(iva.NumeroDetalle))
                            {
                                documentoTransporteEnvio.NumeroDetalle = 0;
                            }
                            else
                            {
                                documentoTransporteEnvio.NumeroDetalle = Convert.ToInt32(iva.NumeroDetalle);
                            }
                            documentoTransporteEnvio.NumeroDocumentoTransporte = iva.NumeroDocumentoTransporte;
                            documentoTransporteEnvio.CodigoTipoCarga = iva.CodigoTipoCarga;
                            documentoTransporteEnvio.VinVehiculo = iva.VinDeVehiculo;
                            documentoTransporteEnvio.NumeroEquipamiento = iva.NumeroDeEquipamiento;

                            Int32 idDocumentoTransporteEnvioNuevo = -1;
                            lnDocumentoTransporteEnvio.Registrar(documentoTransporteEnvio,
                                ref idDocumentoTransporteEnvioNuevo);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, ex.Message + " - " + ex.InnerException);
            }
        }

        private void ObtenerDatosExtrasEnvio(ref Entidades.AppTag.Envio envio, DeclarationMetaData lectura)
        {
            try
            {
                LnTipoManifiesto lnTipoManifiesto = new LnTipoManifiesto();
                LnTipoOperador lnTipoOperador = new LnTipoOperador();
                LnTipoTransaccion lnTipoTransaccion = new LnTipoTransaccion();
                LnViaTransporte lnViaTransporte = new LnViaTransporte();
                LnTipoCarga lnTipoCarga = new LnTipoCarga();

                var tipoManifiesto =
                    lnTipoManifiesto.ObtenerPorCodigo(lectura.Declaration.DeclarationAdditionalDocument785.TipoManifiestoCarga);
                var tipoOperador = lnTipoOperador.ObtenerPorCodigo(lectura.Declaration.DeclarationSubmitter.TipoOperadorQueEnviaMensaje);
                var tipoTransaccion = lnTipoTransaccion.ObtenerPorCodigo(lectura.NumeroTransaccion);
                ViaTransporte viaTransporte = null;
                if (lectura.Declaration.DeclarationBorderTransportMeans != null)
                {
                    viaTransporte =
                        lnViaTransporte.ObtenerPorCodigo(lectura.Declaration.DeclarationBorderTransportMeans.ViaTransporte);
                }

                Int32? cantidadCarga = lectura.Declaration.CantidadDeclarationConsignment;

                if (tipoManifiesto != null || tipoOperador != null || tipoTransaccion != null || viaTransporte != null)
                {

                    if (tipoManifiesto != null) envio.IdTipoManifiesto = tipoManifiesto.IdTipoManifiesto;
                    if (tipoOperador != null) envio.IdTipoOperador = tipoOperador.IdTipoOperador;
                    if (tipoTransaccion != null) envio.CodTipoTransaccion = tipoTransaccion.CodTipoTransaccion;
                    if (viaTransporte != null) envio.IdViaTransporte = viaTransporte.IdViaTransporte;
                    envio.CantidadCarga = cantidadCarga;

                    

                    //ActualizarAnexos(idEnvio, idTipoOperador, idTipoManifiesto,
                    //    idViaTransporte, codTipoTransaccion, cantidadCarga, lectura.NumeroTransaccion);
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, ex.Message + " - " + ex.InnerException);
            }
        }

        //private void ObtenerDatosExtrasEnvio(Int32 idEnvio, DeclarationMetaData lectura)
        //{
        //    try
        //    {
        //        LnTipoManifiesto lnTipoManifiesto = new LnTipoManifiesto();
        //        LnTipoOperador lnTipoOperador = new LnTipoOperador();
        //        LnTipoTransaccion lnTipoTransaccion = new LnTipoTransaccion();
        //        LnViaTransporte lnViaTransporte = new LnViaTransporte();
                

        //        var tipoManifiesto =
        //            lnTipoManifiesto.ObtenerPorCodigo(lectura.Declaration.DeclarationAdditionalDocument785.TipoManifiestoCarga);
        //        var tipoOperador = lnTipoOperador.ObtenerPorCodigo(lectura.Declaration.DeclarationSubmitter.TipoOperadorQueEnviaMensaje);
        //        var tipoTransaccion = lnTipoTransaccion.ObtenerPorCodigo(lectura.NumeroTransaccion);
        //        ViaTransporte viaTransporte = null;
        //        if (lectura.Declaration.DeclarationBorderTransportMeans != null)
        //        {
        //            viaTransporte =
        //                lnViaTransporte.ObtenerPorCodigo(lectura.Declaration.DeclarationBorderTransportMeans.ViaTransporte);
        //        }

        //        Int32? cantidadCarga = lectura.Declaration.CantidadDeclarationConsignment;

        //        if (tipoManifiesto != null || tipoOperador != null || tipoTransaccion != null || viaTransporte != null)
        //        {
                    
        //            int? idTipoManifiesto = null;
        //            int? idTipoOperador = null;
        //            string codTipoTransaccion = null;
        //            int? idViaTransporte = null;
        //            if (tipoManifiesto != null) idTipoManifiesto = tipoManifiesto.IdTipoManifiesto;
        //            if (tipoOperador != null) idTipoOperador = tipoOperador.IdTipoOperador;
        //            if (tipoTransaccion != null) codTipoTransaccion = tipoTransaccion.CodTipoTransaccion;
        //            if (viaTransporte != null) idViaTransporte = viaTransporte.IdViaTransporte;

        //            ActualizarAnexos(idEnvio, idTipoOperador, idTipoManifiesto,
        //                idViaTransporte, codTipoTransaccion, cantidadCarga, lectura.NumeroTransaccion);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Log(Level.Error, ex.Message + " - " + ex.InnerException);
        //    }
        //}

        private void RegistrarRespuestaSql(Int32 idEnvio, RespuestaTransWeb entidadRespuestaTransWeb,
            Int32 intIdTipoRespuesta, String nombreZip)
        {
            //using (TransactionScope transactionScope = new TransactionScope())
            //{
            try
            {
                AdRespuesta adRespuesta = new AdRespuesta();
                AdDetalleRespuesta adDetalleRespuesta = new AdDetalleRespuesta();
                //DBAPPTAGSQLEntities dbContext = new DBAPPTAGSQLEntities(ConfigController.Conf.CnEntityFrameworkSql); //strCadenaConexion);
                //RESPUESTA respuestaSql = new RESPUESTA();
                //respuestaSql.FECHAACEPTACION = DateTime.Now;
                //respuestaSql.FECHAREGISTRO = DateTime.Now;
                //respuestaSql.IDENVIO = idEnvio;
                //respuestaSql.IDTIPORESPUESTA = intIdTipoRespuesta;
                //respuestaSql.IDESTADORESPUESTA = entidadRespuestaTransWeb.IdTransaccionEnvio > 0 ? 1 : 8;

                Entidades.AppTag.Respuesta respuestaSql = new Entidades.AppTag.Respuesta();
                respuestaSql.FechaAceptacion = DateTime.Now;
                respuestaSql.FechaRegistro = DateTime.Now;
                respuestaSql.IdEnvio = idEnvio;
                respuestaSql.IdTipoRespuesta = intIdTipoRespuesta;
                respuestaSql.IdEstadoRespuesta = entidadRespuestaTransWeb.IdTransaccionEnvio > 0 ? 1 : 8;

                Int32 idRespuestaNuevo = -1;
                Int32 respuestaResult = adRespuesta.Registrar(respuestaSql, ref idRespuestaNuevo);

                //dbContext.RESPUESTA.AddObject(respuestaSql);
                //dbContext.SaveChanges();
                if (respuestaResult > 0)
                {
                    if (entidadRespuestaTransWeb.LstErrores != null)
                    {
                        for (int i = 0; i <= entidadRespuestaTransWeb.LstErrores.Count - 1; i++)
                        {
                            Entidades.AppTag.DetalleRespuesta detalleRespuestaSql = new DetalleRespuesta();
                            //DETALLERESPUESTA detalleRespuestaSql = new DETALLERESPUESTA();
                            detalleRespuestaSql.Codigo = entidadRespuestaTransWeb.LstErrores[i].Codigo;
                            detalleRespuestaSql.Descripcion = entidadRespuestaTransWeb.LstErrores[i].Descripcion;
                            detalleRespuestaSql.IdRespuesta = idRespuestaNuevo;// respuestaSql.IdRespuesta;

                            Int32 idDetalleRespuestaNuevo = -1;
                            adDetalleRespuesta.Registrar(detalleRespuestaSql, ref idDetalleRespuestaNuevo);
                            //dbContext.DETALLERESPUESTA.AddObject(detalleRespuestaSql);
                            //dbContext.SaveChanges();
                        }
                    }

                    Log(Level.Info,
                        String.Format("{0} ; Se registro la respuesta con estado : {1}", nombreZip,
                            respuestaSql.IdEstadoRespuesta));
                    //dbContext.Dispose();
                    //transactionScope.Complete();
                    //return true;
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, ex.Message);
                //return false;
            }
            //}
        }

        public Int32 ActualizarAnexos(Int32 idEnvio, Int32? idTipoOperador, Int32? idTipoManifiesto,
            Int32? idViaTransporte, string codigoTipoTransaccion, Int32? cantidadCarga, string codigoTransaccion)
        {
            return _adEnvio.ActualizarAnexos(idEnvio, idTipoOperador, idTipoManifiesto, idViaTransporte,
                codigoTipoTransaccion, cantidadCarga, codigoTransaccion);
        }

        public Entidades.AppTag.Envio ObtenerEnvioPorId(Int32 idEnvio)
        {
            return _adEnvio.ObtenerPorId(idEnvio);
        }

        public Entidades.AppTag.Envio ObtenerPorIdTransaccion(Int32 idTransaccion)
        {
            return _adEnvio.ObtenerPorIdTransaccion(idTransaccion);
        }

    }
}
