﻿using System;
using DLLMapRe.AccesoDatos.AppTagEnvio;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnDocumentoTransporteEnvio
    {
        private readonly AdDocumentoTransporteEnvio _adDocumentoTransporteEnvio = new AdDocumentoTransporteEnvio();

        public Int32 Registrar(DocumentoTransporteEnvio documentoTransporteEnvio, ref Int32 idDocumentoTransporteEnvioNuevo)
        {
            return _adDocumentoTransporteEnvio.Registrar(documentoTransporteEnvio, ref idDocumentoTransporteEnvioNuevo);
        }
    }
}
