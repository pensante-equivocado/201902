﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Schema;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnValidarXml
    {

        #region
            private bool bol_ValidacionXml = true;
            private string strErr;
            XmlSchemaCollection myschemacoll;
            XmlValidatingReader vr;
            FileStream stream;
            int intlinea = 0;
            private List<string> lstError = new List<string>();
        #endregion
        
        public Boolean fbol_ValidarXML(string NombreArchivo, string strCustomsDeclarationPeru, string strReusableAggregateBusiness1, string strReusableAggregateBusiness6,  ref List<string> lstErrores)
        {
            
           try
            {
                lstError = new List<string>();
                bol_ValidacionXml = true;
                stream = new FileStream(NombreArchivo, FileMode.Open);
                vr = new XmlValidatingReader(stream, XmlNodeType.Element, null);
                myschemacoll = new XmlSchemaCollection();

                myschemacoll.Add("urn:peru:sunat:insi:data:standard:OACustomsManifest:1", strCustomsDeclarationPeru);
                myschemacoll.Add("urn:peru:sunat:insi:data:standard:ReusableAggregateBusinessInformationEntity:1", strReusableAggregateBusiness1);
                myschemacoll.Add("urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:6", strReusableAggregateBusiness6);

                vr.Schemas.Add(myschemacoll);
                vr.ValidationType = ValidationType.Schema;
                vr.ValidationEventHandler += new ValidationEventHandler(this.p_EventoValidacion_EventHandle);
                
                while (vr.Read())
                {
                    string xd = vr.ReadString();
                    intlinea = vr.LineNumber;
                }

                stream.Close();
            }
            catch (XmlException XmlExp)
            {
                lstError.Add("Linea # [" + intlinea + "]" + "\r\n" + XmlExp.Message);
                bol_ValidacionXml = false;
            }
            catch (XmlSchemaException XmlSchemaExp)
            {
                lstError.Add(XmlSchemaExp.Message);
                bol_ValidacionXml = false;
            }
            catch (Exception GeneralExp)
            {
                lstError.Add(GeneralExp.Message);
                bol_ValidacionXml = false;
            }
            finally
            {
                vr = null;
                myschemacoll = null;
                stream = null;
            }
            lstErrores = lstError;
            return bol_ValidacionXml;
         }

        
        private void p_EventoValidacion_EventHandle(object sender, ValidationEventArgs args)
        {
            bol_ValidacionXml = false;
            strErr += "Validation error";
            strErr += String.Format("Severity:{0}", args.Severity);
            strErr += String.Format("Message:{0}", args.Message);
            lstError.Add(strErr);
        }


    }
}
