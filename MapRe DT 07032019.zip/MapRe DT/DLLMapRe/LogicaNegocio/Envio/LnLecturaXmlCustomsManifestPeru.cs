﻿using System;
using System.Xml;
using System.Xml.XPath;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.LogicaNegocio.Envio
{
    public class LnLecturaXmlCustomsManifestPeru: Logger
    {
        private OACustomsManifestPeru _declarationMetaData;
        public Boolean ValidarEstructura(string rutaCompletaXml, ref string codigoTransaccion)
        {
            try
            {

                XmlDocument doc = new XmlDocument();
                doc.Load(rutaCompletaXml);
                XPathDocument xmlComprobante = new XPathDocument(new XmlNodeReader(doc));
                var nav = xmlComprobante.CreateNavigator();

                XmlNamespaceManager ns = null;
                if (nav.NameTable != null)
                {
                    ns = new XmlNamespaceManager(nav.NameTable);
                    ns.AddNamespace("rsm", "urn:peru:sunat:insi:data:standard:OACustomsManifest:1");
                    ns.AddNamespace("ram", "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:6");
                }

                const string rutaPrincipal = "/rsm:OACustomsManifestPeru";

                var functionalDefinition = SelectNodeValue(rutaPrincipal, "/rsm:SpecifiedExchangedDocumentContext", nav, ns);
                
                if (!String.IsNullOrEmpty(functionalDefinition))
                {
                    //Es OMA
                    codigoTransaccion = functionalDefinition;
                    return true;
                }
                else
                {
                    //Es Cuscar
                    codigoTransaccion = "";
                    return false;

                }
            }
            catch (Exception ex)
            {
                Log(Level.Info, ((ex.InnerException == null) ? ex.Message : ex.InnerException.Message));
                return false;
            }

        }

        private static string SelectNodeValue(string rutaPrincipal, string rutaComplemento, XPathNavigator nav, XmlNamespaceManager ns)
        {
            var nodo = nav.SelectSingleNode(String.Concat(rutaPrincipal, rutaComplemento), ns);
            return NodeValue(nodo);
        }

        public static string NodeValue(XPathItem node)
        {
            string defaultValue = string.Empty;
            if (node != null)
            {
                return node.Value ?? defaultValue;
            }

            return defaultValue;
        }
    }
}
