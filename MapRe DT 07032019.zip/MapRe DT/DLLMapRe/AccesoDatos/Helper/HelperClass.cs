﻿using System.Data;
using System.Data.SqlClient;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.AccesoDatos.Helper
{
    internal class HelperClass
    {

        internal static IDbConnection ObtenerConeccion()
        {

            return new SqlConnection(ConfigController.Conf.Cn);

        }

    }
}
