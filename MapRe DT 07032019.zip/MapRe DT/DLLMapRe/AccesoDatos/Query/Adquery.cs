﻿using System;
using System.Text;

namespace DLLMapRe.AccesoDatos.Query
{
    public static class Adquery
    {
        //public static string ObtenerConfiguracion()
        //{
        //    StringBuilder sb = new StringBuilder();

        //    sb.AppendLine("SELECT IDCONFIGURACION as IdConfiguracion ");
        //    sb.AppendLine("	,TIPONOMBREARCHIVO as TipoNombreArchivo ");
        //    sb.AppendLine("	,VALIDAESQUEMA as ValidaEsquema ");
        //    sb.AppendLine("	,CLAVECONFIGURACION as ClaveConfiguracion ");
        //    sb.AppendLine("FROM MAESTRO.CONFIGURACION ");
        //    sb.AppendLine("WHERE IDCONFIGURACION = 1 ");

        //    return sb.ToString();
        //}

        //SELECT * FROM MAESTRO.TIPOOPERADOR
        //public static string ObtenerTipoOperadorPorCodigo(string codigoTipoOperador)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 IDTIPOOPERADOR AS IdTipoOperador ");
        //    sb.AppendLine("     ,CODTIPOOPERADOR AS CodTipoOperador ");
        //    sb.AppendLine("	    ,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("FROM MAESTRO.TIPOOPERADOR ");
        //    sb.AppendLine("WHERE CODTIPOOPERADOR = '" + codigoTipoOperador + "' ");

        //    return sb.ToString();

        //}

        //SELECT * FROM MAESTRO.TIPOMANIFIESTO
        //public static string ObtenerTipoManifiestoPorCodigo(string codigoTipoManifiesto)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 IDTIPOMANIFIESTO AS IdTipoManifiesto ");
        //    sb.AppendLine("     ,CODTIPOMANIFIESTO AS CodTipoManifiesto ");
        //    sb.AppendLine("	    ,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("FROM MAESTRO.TIPOMANIFIESTO ");
        //    sb.AppendLine("WHERE CODTIPOMANIFIESTO = '" + codigoTipoManifiesto + "' ");

        //    return sb.ToString();

        //}

        //SELECT * FROM MAESTRO.VIATRANSPORTE
        //public static string ObtenerViaTransportePorCodigo(string codigoViaTransporte)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 IDVIATRANSPORTE AS IdViaTransporte ");
        //    sb.AppendLine("     ,CODVIATRANSPORTE AS CodViaTransporte ");
        //    sb.AppendLine("	    ,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("FROM MAESTRO.VIATRANSPORTE ");
        //    sb.AppendLine("WHERE CODVIATRANSPORTE = '" + codigoViaTransporte + "' ");

        //    return sb.ToString();

        //}

        //public static string ObtenerTipoCargaPorCodigo(string codigoTipoCarga)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 IDTIPOCARGA AS IdTipoCarga ");
        //    sb.AppendLine("	,CODTIPOCARGA AS CodTipoCarga ");
        //    sb.AppendLine("	,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("FROM MAESTRO.TIPOCARGA ");
        //    sb.AppendLine("WHERE CODTIPOCARGA = '" + codigoTipoCarga + "' ");

        //    return sb.ToString();

        //}

        //public static string ObtenerIndUltimoEnvioPorCodigo(string codigoIndUltimoEnvio)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 IDINDULTIMOENVIO AS IdIndUltimoEnvio ");
        //    sb.AppendLine("	,CODINDULTIMOENVIO AS CodIndUltimoEnvio ");
        //    sb.AppendLine("	,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("FROM MAESTRO.INDULTIMOENVIO ");
        //    sb.AppendLine("WHERE CODINDULTIMOENVIO = '" + codigoIndUltimoEnvio + "' ");

        //    return sb.ToString();

        //}

        //SELECT * FROM MAESTRO.TIPOTRANSACCION
        //public static string ObtenerTipoTransaccionPorCodigo(string codigoTipoTransaccion)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("SELECT TOP 1 CODTIPOTRANSACCION AS CodTipoTransaccion ");
        //    sb.AppendLine("     ,DESCRIPCION AS Descripcion ");
        //    sb.AppendLine("	    ,CODREGIMEN AS CodRegimen ");
        //    sb.AppendLine("FROM MAESTRO.TIPOTRANSACCION ");
        //    sb.AppendLine("WHERE CODTIPOTRANSACCION = '" + codigoTipoTransaccion + "' ");

        //    return sb.ToString();

        //}

        //public static string ActualizarEnvio(Int32 idEnvio, Int32? idTipoOperador, Int32? idTipoManifiesto,
        //    Int32? idViaTransporte, string codigoTipoTransaccion, Int32? cantidadCarga, string codigoTransaccion)
        //{

        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendLine("UPDATE APPTAG.ENVIOS ");

        //    if (idTipoOperador == null)
        //    {
        //        sb.AppendLine("SET IDTIPOOPERADOR = NULL ");
        //    }
        //    else
        //    {
        //        sb.AppendLine("SET IDTIPOOPERADOR = " + idTipoOperador + " ");
        //    }

        //    if (idTipoManifiesto == null)
        //    {
        //        sb.AppendLine("	,IDTIPOMANIFIESTO = NULL ");
        //    }
        //    else
        //    {
        //        sb.AppendLine("	,IDTIPOMANIFIESTO = " + idTipoManifiesto + " ");
        //    }
            

        //    //case "0125"://IVA Numeracion Maritima
        //    //case "0325"://IVA Numeracion Terrestre
        //    //case "0425"://IVA Numeracion Aereo
        //    //case "0825"://IVA Numeracion Fluvial
        //    //if (!codigoTransaccion.Equals("0125") && !codigoTransaccion.Equals("0325") && !codigoTransaccion.Equals("0425") && !codigoTransaccion.Equals("0825"))
        //    //{
        //    if (idViaTransporte == null)
        //    {
        //        sb.AppendLine("	,IDVIATRANSPORTE = NULL ");
        //    }
        //    else
        //    {
        //        sb.AppendLine("	,IDVIATRANSPORTE = " + idViaTransporte + " ");
        //    }

        //    //}

        //    if (String.IsNullOrEmpty(codigoTipoTransaccion))
        //    {
        //        sb.AppendLine("	,CODTIPOTRANSACCION = NULL ");
        //    }
        //    else
        //    {
        //        sb.AppendLine("	,CODTIPOTRANSACCION = '" + codigoTipoTransaccion + "' ");
        //    }
            

        //    if (cantidadCarga != null)
        //    {
        //        sb.AppendLine("	,CANTIDADCARGA = " + cantidadCarga + " ");
        //    }

        //    sb.AppendLine("WHERE IDENVIO = " + idEnvio + " ");

        //    return sb.ToString();

        //}

    }
}
