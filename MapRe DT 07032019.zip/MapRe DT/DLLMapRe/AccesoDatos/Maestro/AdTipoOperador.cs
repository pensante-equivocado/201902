﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Entidades.Maestro;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdTipoOperador : Logger
    {
        public TipoOperador ObtenerPorCodigo(string codigoTipoOperador)
        {
            TipoOperador resultado = new TipoOperador();
            try
            {
                const string query = "MAESTRO.usp_TipoOperador_ObtenerPorCodigo";//Query.Adquery.ObtenerTipoOperadorPorCodigo(codigoTipoOperador);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<TipoOperador>(query, new
                    {
                        CodigoTipoOperador = codigoTipoOperador
                    }, commandType: CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
