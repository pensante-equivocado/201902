﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.AccesoDatos.Query;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdConfiguracion: Logger
    {

        public Entidades.Maestro.Configuracion ObtenerPorId(Int32 idConfiguracion)
        {
            const string query = "MAESTRO.usp_Configuracion_ObtenerPorId";//Adquery.ObtenerConfiguracion();
            try
            {

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    var envio = cn.QueryFirstOrDefault<Entidades.Maestro.Configuracion>(query, new
                    {
                        IdConfiguracion = idConfiguracion
                    },
                    commandType: CommandType.StoredProcedure //,
                    //commandTimeout: 0
                    );

                    return envio;

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));

            }
            return null;
        }

    }
}
