﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.AccesoDatos.Query;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdIndUltimoEnvio: Logger
    {
        public IndUltimoEnvio ObtenerPorCodigo(string codigoIndUltimoEnvio)
        {
            IndUltimoEnvio resultado = new IndUltimoEnvio();
            try
            {
                const string query = "MAESTRO.usp_IndUltimoEnvio_ObtenerPorCodigo";//Adquery.ObtenerIndUltimoEnvioPorCodigo(codigoIndUltimoEnvio);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<IndUltimoEnvio>(query, new
                    {
                        CodigoIndUltimoEnvio = codigoIndUltimoEnvio
                    },commandType: CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
