﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Entidades.Maestro;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdTipoManifiesto : Logger
    {
        public TipoManifiesto ObtenerPorCodigo(string codigoTipoManifiesto)
        {
            TipoManifiesto resultado = new TipoManifiesto();
            try
            {
                const string query = "MAESTRO.usp_TipoManifiesto_ObtenerPorCodigo";//Query.Adquery.ObtenerTipoManifiestoPorCodigo(codigoTipoManifiesto);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<TipoManifiesto>(query, new
                    {
                        CodigoTipoManifiesto = codigoTipoManifiesto
                    }, commandType: CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
        
    }
}
