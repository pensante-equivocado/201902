﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Entidades.Maestro;
using DLLMapRe.Configuracion.Proceso;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdViaTransporte: Logger
    {
        public ViaTransporte ObtenerPorCodigo(string codigoViaTransporte)
        {
            ViaTransporte resultado = new ViaTransporte();
            try
            {
                const string query = "MAESTRO.usp_ViaTransporte_ObtenerPorCodigo";//Query.Adquery.ObtenerViaTransportePorCodigo(codigoViaTransporte);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<ViaTransporte>(query, new
                    {
                        CodigoViaTransporte = codigoViaTransporte
                    }, commandType: CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
