﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.AccesoDatos.Query;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.Maestro;

namespace DLLMapRe.AccesoDatos.Maestro
{
    public class AdTipoCarga: Logger
    {
        public TipoCarga ObtenerPorCodigo(string codigoTipoCarga)
        {
            TipoCarga resultado = new TipoCarga();
            try
            {
                const string query = "MAESTRO.usp_TipoCarga_ObtenerPorCodigo";// Adquery.ObtenerTipoCargaPorCodigo(codigoTipoCarga);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<TipoCarga>(query, new
                    {
                        CodigoTipoCarga = codigoTipoCarga
                    },commandType: CommandType.StoredProcedure);

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
