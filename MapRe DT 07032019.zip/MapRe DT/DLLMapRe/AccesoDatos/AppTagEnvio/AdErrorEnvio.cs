﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.AccesoDatos.AppTagEnvio
{
    public class AdErrorEnvio: Logger
    {
        public Int32 Registrar(ErrorEnvio errorEnvio, ref Int32 idErrorEnvioNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_ErrorEnvio_ins";

                var p = new DynamicParameters();
                p.Add("IdErrorEnvio", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("IdEnvio", errorEnvio.IdEnvio);
                p.Add("Descripcion", errorEnvio.Descripcion);
                p.Add("FechaRegistro", errorEnvio.FechaRegistro);
        
                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idErrorEnvioNuevo = p.Get<Int32>("IdErrorEnvio");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
