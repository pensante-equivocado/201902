﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
//using DLLMapRe.AccesoDatos.Query;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.AccesoDatos.AppTagEnvio
{
    public class AdEnvio: Logger
    {

        public Int32 Registrar(Envio envio, ref Int32 idEnvioNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_Envios_ins";

                var p = new DynamicParameters();
                p.Add("IdEnvio", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("FechaImportacion", envio.FechaImportacion);
                p.Add("IdUsuario", envio.IdUsuario);
                p.Add("CodRegimenRef", envio.CodRegimenRef);
                p.Add("CodRegimenGen", envio.CodRegimenGen);
                p.Add("NroCorrelativo", envio.NroCorrelativo);
                p.Add("FechaDeclaracion", envio.FechaDeclaracion);
                p.Add("CodAduanaDeclaracion", envio.CodAduanaDeclaracion);
                p.Add("CantidadSeries", envio.CantidadSeries);
                p.Add("NroDocumentoDeclarante", envio.NroDocumentoDeclarante);
                p.Add("TipoDocumentoDeclarante", envio.TipoDocumentoDeclarante);
                p.Add("RazonSocialDeclarante", envio.RazonSocialDeclarante);
                p.Add("CodModalidad", envio.CodModalidad);
                p.Add("CodAduanaPresentacion", envio.CodAduanaPresentacion);
                p.Add("IdEstadoRespuesta", envio.IdEstadoRespuesta);
                p.Add("IdEstadoAcuse", envio.IdEstadoAcuse);
                p.Add("IdEstadoTci", envio.IdEstadoTci);
                p.Add("NroTicket", envio.NroTicket);
                p.Add("FechaTci", envio.FechaTci);
                p.Add("FechaAcuse", envio.FechaAcuse);
                p.Add("FechaRespuesta", envio.FechaAcuse);
                p.Add("FechaGeneracion", envio.FechaAcuse);
                p.Add("ArchivoXml", envio.ArchivoXml);
                p.Add("NombreArchivo", envio.NombreArchivo);
                p.Add("IdTransaccion", envio.IdTransaccion);
                p.Add("PesoArchivo", envio.PesoArchivo);
                p.Add("PasoEsquema", envio.PasoEsquema);
                p.Add("CodTipoTransaccion", envio.CodTipoTransaccion);
                p.Add("NumeroOrden", envio.NumeroOrden);
                p.Add("TipoAforo", envio.TipoAforo);
                p.Add("FechaUltimoDiaPago", envio.FechaUltimoDiaPago);
                p.Add("TipoAmbiente", envio.TipoAmbiente);
                p.Add("RucAgenteAduana", envio.RucAgenteAduana);
                p.Add("IdTipoOperador", envio.IdTipoOperador);
                p.Add("IdViaTransporte", envio.IdViaTransporte);
                p.Add("IdIndUltimoEnvio", envio.IdIndUltimoEnvio);
                p.Add("IdTipoCarga", envio.IdTipoCarga);
                p.Add("Nromanifiesto", envio.Nromanifiesto);
                p.Add("AnioManifiesto", envio.AnioManifiesto);
                p.Add("IdTipoManifiesto", envio.IdTipoManifiesto);
                p.Add("NroDocumentoTransporte", envio.NroDocumentoTransporte);
                p.Add("NroDetalle", envio.NroDetalle);
                p.Add("CantidadCarga", envio.CantidadCarga);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idEnvioNuevo = p.Get<Int32>("IdEnvio");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

        public Int32 ActualizarAnexos(Int32 idEnvio, Int32? idTipoOperador, Int32? idTipoManifiesto,
            Int32? idViaTransporte, string codigoTipoTransaccion, Int32? cantidadCarga, string codigoTransaccion)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_Envios_ActualizarAnexos";//Adquery.ActualizarEnvio(idEnvio, idTipoOperador, idTipoManifiesto, idViaTransporte,
                    //codigoTipoTransaccion, cantidadCarga, codigoTransaccion);
                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query,new
                    {
                        IdEnvio = idEnvio,
                        IdTipoOperador = idTipoOperador,
                        IdTipoManifiesto = idTipoManifiesto,
                        IdViaTransporte = idViaTransporte,
                        CodigoTipoTransaccion = codigoTipoTransaccion,
                        CantidadCarga = cantidadCarga
                    }, commandType: CommandType.StoredProcedure);
                    //commandTimeout: 0,
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

        public Envio ObtenerPorId(Int32 idEnvio)
        {
            Envio resultado = new Envio();
            try
            {
                const string query = "APPTAG.usp_Envios_ObtenerPorId";

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<Envio>(query, new
                    {
                        IdEnvio = idEnvio
                    },
                        commandType: CommandType.StoredProcedure
                        );

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

        public Envio ObtenerPorIdTransaccion(Int32 idTransaccion)
        {
            Envio resultado = new Envio();
            try
            {
                const string query = "APPTAG.usp_Envios_ObtenerPorIdTransaccion";

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.QuerySingleOrDefault<Envio>(query, new
                    {
                        IdTransaccion = idTransaccion
                    },
                        commandType: CommandType.StoredProcedure
                        );

                }

            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

    }
}
