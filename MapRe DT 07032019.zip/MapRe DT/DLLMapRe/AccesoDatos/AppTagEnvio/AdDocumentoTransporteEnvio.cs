﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.AccesoDatos.AppTagEnvio
{
    public class AdDocumentoTransporteEnvio: Logger
    {
        public Int32 Registrar(DocumentoTransporteEnvio documentoTransporteEnvio, ref Int32 idDocumentoTransporteEnvioNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_DocumentoTransporteEnvio_ins";

                var p = new DynamicParameters();
                p.Add("IdDocumentoTransporteEnvio", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("IdEnvio", documentoTransporteEnvio.IdEnvio);
                p.Add("NumeroDetalle", documentoTransporteEnvio.NumeroDetalle);
                p.Add("NumeroDocumentoTransporte", documentoTransporteEnvio.NumeroDocumentoTransporte);
                p.Add("CodigoTipoCarga", documentoTransporteEnvio.CodigoTipoCarga);
                p.Add("VinVehiculo", documentoTransporteEnvio.VinVehiculo);
                p.Add("NumeroEquipamiento", documentoTransporteEnvio.NumeroEquipamiento);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idDocumentoTransporteEnvioNuevo = p.Get<Int32>("IdDocumentoTransporteEnvio");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

    }
}
