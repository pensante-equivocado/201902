﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.AccesoDatos.AppTagRespuesta
{
    public class AdRespuesta: Logger
    {
        public Int32 Registrar(Respuesta respuesta, ref Int32 idRespuestaNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_Respuesta_ins";

                var p = new DynamicParameters();
                p.Add("IdRespuesta", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("FechaAceptacion", respuesta.FechaAceptacion);
                p.Add("FechaRegistro", respuesta.FechaRegistro);
                p.Add("IdEnvio", respuesta.IdEnvio);
                p.Add("IdTipoRespuesta", respuesta.IdTipoRespuesta);
                p.Add("IdEstadoRespuesta", respuesta.IdEstadoRespuesta);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idRespuestaNuevo = p.Get<Int32>("IdRespuesta");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
