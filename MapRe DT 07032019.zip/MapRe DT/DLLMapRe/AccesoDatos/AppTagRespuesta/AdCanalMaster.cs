﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.Canal;
using CanalMaster = DLLMapRe.Entidades.AppTag.CanalMaster;

namespace DLLMapRe.AccesoDatos.AppTagRespuesta
{
    public class AdCanalMaster: Logger
    {
        public Int32 Registrar(CanalMaster canalMaster, ref Int32 idCanalMasterNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_CanalMaster_ins";

                var p = new DynamicParameters();
                p.Add("IdCanalMaster", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("CodAduana", canalMaster.CodAduana);
                p.Add("AnioManifiesto", canalMaster.AnioManifiesto);
                p.Add("NumManifiesto", canalMaster.NumManifiesto);
                p.Add("BlMaster", canalMaster.BlMaster);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idCanalMasterNuevo = p.Get<Int32>("IdCanalMaster");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }

        /// <summary>
        /// Este metodo sera remplazado por el de Registrar
        /// </summary>
        public ResultCanal RegistrarCanalMasterSql(DBAPPTAGSQLEntities context, Entidades.Canal.CanalMaster canalMaster, Int32 idTransaccionRespuestaObtenidoDesdeWs)
        {
            try
            {
                using (context)
                {
                    var aduana = new SqlParameter("@aduana", canalMaster.CodigoAduana);
                    var anioManifiesto = new SqlParameter("@anio", canalMaster.AnioManifiesto);
                    var numeroManifiesto = new SqlParameter("@numero", canalMaster.NumeroManifiesto);
                    var blMaster = new SqlParameter("@blMaster", canalMaster.BlMaster);

                    var result = context
                        .ExecuteStoreQuery<ResultCanal>
                        (
                            "Exec APPTAG.Usp_RegistrarCanalMaster @aduana,@anio,@numero,@blMaster"
                            , aduana
                            , anioManifiesto
                            , numeroManifiesto
                            , blMaster
                        )
                        .Select(q => new ResultCanal
                        {
                            Clave = q.Clave,
                            Valor = q.Valor
                        }
                        )
                        .FirstOrDefault();

                    Log(Level.Info,
                                String.Format(
                                    "{0} ; Se registro [CANALMASTER] en la base de datos segun el NSIGAD obtenido",
                                    idTransaccionRespuestaObtenidoDesdeWs));

                    return result;
                }

            }
            catch (Exception e)
            {
                Log(Level.Error, e.Message);
                //strMensaje = e.Message;
                return null;
            }
        }

    }
}
