﻿using System;
using System.Data;
using Dapper;
using DLLMapRe.AccesoDatos.Helper;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;

namespace DLLMapRe.AccesoDatos.AppTagRespuesta
{
    public class AdDetalleRespuesta:Logger
    {
        public Int32 Registrar(DetalleRespuesta detalleRespuesta, ref Int32 idDetalleRespuestaNuevo)
        {
            Int32 resultado = 0;
            try
            {
                const string query = "APPTAG.usp_DetalleRespuesta_ins";

                var p = new DynamicParameters();
                p.Add("IdDetalleRespuesta", 0, DbType.Int32, ParameterDirection.Output);
                p.Add("Codigo", detalleRespuesta.Codigo);
                p.Add("Descripcion", detalleRespuesta.Descripcion);
                p.Add("IdRespuesta", detalleRespuesta.IdRespuesta);

                using (var cn = HelperClass.ObtenerConeccion())
                {
                    if (cn.State == ConnectionState.Closed)
                    {
                        cn.Open();
                    }

                    resultado = cn.Execute(query, commandType: CommandType.StoredProcedure, param: p);
                    idDetalleRespuestaNuevo = p.Get<Int32>("IdDetalleRespuesta");
                }
            }
            catch (Exception ex)
            {
                Log(Level.Error, (ex.InnerException == null ? ex.Message : ex.InnerException.Message));
            }
            return resultado;
        }
    }
}
