﻿using System;
using System.Collections.Generic;
using System.Linq;
using DLLMapRe.Configuracion.Entidad;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades;
using DLLMapRe.Entidades.EnvioRegistro;
using DLLMapRe.Entidades.Respuesta;
using DLLMapRe.LogicaNegocio.Respuesta;
using DLLTransWeb.Entidades.Respuesta;
using DLLTransWeb.LogicaProceso;

namespace DLLMapRe.LogicaProceso
{
    public class LpMapReRespuesta
    {
        private readonly LpTransWebRespuesta _lpTransWebRespuesta = new LpTransWebRespuesta();
        private RESPUESTA _respuestaSql = new RESPUESTA();
        private DETALLERESPUESTA _detalleRespuestaSql = new DETALLERESPUESTA();

        public Boolean ProcesarRespuestasPendientesDeMarcacion(ParametroRespuestaMapRe prmInput,
            ref string refMensaje, ref List<ENRespuestaEnvio> listadoRespuestasProcesadas)
        {
            try
            {

                Config conf = new Config
                {
                    Servidor = prmInput.DataSource,
                    BaseDatos = prmInput.InitialCatalog,
                    Usuario = prmInput.UserId,
                    Contrasenia = prmInput.Password,
                    RutaLog = prmInput.RutaLog,

                    GestorBaseDatos = prmInput.GestorBaseDatos,
                    PuertoBaseDatos = prmInput.Port,
                    UrlSatServer = prmInput.UrlSatServer,
                    UrlSatServerAlternativa = prmInput.UrlSatServerAlternativa,
                    Casilla = prmInput.Casilla,
                    Pwdcasilla = prmInput.PwdCasilla,
                    TimeOut = prmInput.TimeOut
                };

                ConfigController.EstablecerConfiguracion(conf);

                ParametroRespuestaTransWeb requestTransWeb = ObtenerRequestTransWeb(prmInput);
                List<TransaccionRespuestaTransWeb> listadoIdTransaccionesRespuestaTransWeb = _lpTransWebRespuesta.ObtenerRespuestasPendientesDeMarcacion(requestTransWeb);
                if (listadoIdTransaccionesRespuestaTransWeb == null)
                {
                    refMensaje = "Se produjo un problema con la recepción del listado de respuestas";
                    Logger.Log(Logger.Level.Info, "Se produjo un problema con la recepción del listado de respuestas");
                }
                else if (!listadoIdTransaccionesRespuestaTransWeb.Any())
                {
                    refMensaje = "No se recuperaron respuestas";
                    Logger.Log(Logger.Level.Info, "No se recuperaron respuestas");
                }
                else //if (_listadoIdTransaccionesRespuestaTransWeb != null)
                {
                    Logger.Log(Logger.Level.Info,
                        String.Format("Se recuperaron {0} respuestas", listadoIdTransaccionesRespuestaTransWeb.Count));
                    for (int i = 0; i <= listadoIdTransaccionesRespuestaTransWeb.Count - 1; i++)
                    {
                        
                        requestTransWeb.IdTransaccion = listadoIdTransaccionesRespuestaTransWeb[i].IdTransaccion;
                        ProcesarRespuestasPendientesDeMarcacionIndividual(prmInput, requestTransWeb,
                            ref listadoRespuestasProcesadas, requestTransWeb.IdTransaccion, ref refMensaje);

                    }
                }

                refMensaje = "Termino sin errores";
                return true;
            }
            catch (Exception ex)
            {
                refMensaje = ex.Message;
                Logger.Log(Logger.Level.Error, ex.Message);
                return false;
            }
        }

        private void ProcesarRespuestasPendientesDeMarcacionIndividual(ParametroRespuestaMapRe prmInput, ParametroRespuestaTransWeb requestTransWeb,
            ref List<ENRespuestaEnvio> listadoRespuestasProcesadas, Int32 idTransaccionRespuestaObtenidoDesdeWs, ref string refMensaje)
        {
            try
            {
                RespuestaTransWeb respuestaPorTransaccionTransWeb = _lpTransWebRespuesta.ObtenerRespuestaPorIdTransaccion(requestTransWeb);

                if (respuestaPorTransaccionTransWeb == null)
                {
                    Logger.Log(Logger.Level.Info, "Se produjo un problema con la obtención de respuestas");
                }
                else if (respuestaPorTransaccionTransWeb.IdTransaccionEnvio == -1)
                {
                    Logger.Log(Logger.Level.Info,
                        String.Format("No se recupero DLLMapRe.Entidades.respuesta para la transacción :  {0}",
                            requestTransWeb.IdTransaccion));

                    if (prmInput.RegistrarDatos)
                    {
                        LnRespuesta lnRespuesta = new LnRespuesta();
                        Int32 idEnvioObtenidoMedianteTransaccion = 0;
                        if (!lnRespuesta.ObtenerEnvioSqlPorTransaccion(idTransaccionRespuestaObtenidoDesdeWs, ref idEnvioObtenidoMedianteTransaccion, ref refMensaje))
                        {
                            Logger.Log(Logger.Level.Info, refMensaje);
                            return;
                        }
                        lnRespuesta.RegistrarRespuestaSql(idEnvioObtenidoMedianteTransaccion,
                            respuestaPorTransaccionTransWeb, 4, ref _respuestaSql, ref _detalleRespuestaSql);
                    }

                }
                else
                {
                    MarcarRespuestaEnWebService(prmInput, requestTransWeb, ref listadoRespuestasProcesadas,
                        idTransaccionRespuestaObtenidoDesdeWs, ref refMensaje, respuestaPorTransaccionTransWeb);
                }
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }

        private void MarcarRespuestaEnWebService(ParametroRespuestaMapRe prmInput, ParametroRespuestaTransWeb requestTransWeb,
            ref List<ENRespuestaEnvio> listadoRespuestasProcesadas, Int32 idTransaccionRespuestaObtenidoDesdeWs, ref string refMensaje, RespuestaTransWeb respuestaPorTransaccionTransWeb)
        {
            try
            {
                Entidades.AppTag.Envio objEnvios = new Entidades.AppTag.Envio();
                ENRespuestaEnvio respuestaTransaccionProcesada = new ENRespuestaEnvio();
                RespuestaTransWeb respuestaMarcacionTransWeb = new RespuestaTransWeb();

                if (prmInput.RegistrarDatos)
                {
                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se procesará el archivo : {1} ",
                            idTransaccionRespuestaObtenidoDesdeWs,
                            respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta));

                    respuestaTransaccionProcesada.Registrado = false;

                    if (respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta.ToLower().StartsWith("acuse"))
                    {
                        LnRespuesta lnRespuesta = new LnRespuesta();
                        if (lnRespuesta.LeerXmlRespuestaAcuseTemp(respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta, respuestaPorTransaccionTransWeb.BytesDocumento,
                            respuestaPorTransaccionTransWeb.IdTransaccionEnvio, ref objEnvios, idTransaccionRespuestaObtenidoDesdeWs, ref _respuestaSql, ref _detalleRespuestaSql))
                        {
                            //respuestaMarcacionTransWeb = 
                            _lpTransWebRespuesta.MarcarRespuestaEnElWebService(requestTransWeb);
                            respuestaTransaccionProcesada.Registrado = true;
                            respuestaTransaccionProcesada.NombreArchivoXML = respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta;
                        }

                        //if (lnRespuesta.LeerXmlRespuestaAcuse(respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta, respuestaPorTransaccionTransWeb.BytesDocumento,
                        //    respuestaPorTransaccionTransWeb.IdTransaccionEnvio, ref objEnvios, idTransaccionRespuestaObtenidoDesdeWs, ref _respuestaSql, ref _detalleRespuestaSql))
                        //{
                        //    //respuestaMarcacionTransWeb = 
                        //    _lpTransWebRespuesta.MarcarRespuestaEnElWebService(requestTransWeb);
                        //    respuestaTransaccionProcesada.Registrado = true;
                        //    respuestaTransaccionProcesada.NombreArchivoXML = respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta;
                        //}
                    }
                    else if (respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta.ToLower().StartsWith("nsigad"))
                    {
                        LnRespuesta lnRespuesta = new LnRespuesta();
                        //Boolean respuestaProcesadaEnBd =
                        //    lnRespuesta.LeerXmlRespuestaNsigad(respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta,
                        //        respuestaPorTransaccionTransWeb.BytesDocumento,
                        //        respuestaPorTransaccionTransWeb.IdTransaccionEnvio, ref objEnvios, ref refMensaje,
                        //        idTransaccionRespuestaObtenidoDesdeWs, ref _respuestaSql, ref _detalleRespuestaSql);

                        Boolean respuestaProcesadaEnBd =
                            lnRespuesta.LeerXmlRespuestaNsigadTemp(respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta,
                                respuestaPorTransaccionTransWeb.BytesDocumento,
                                respuestaPorTransaccionTransWeb.IdTransaccionEnvio, ref objEnvios, ref refMensaje,
                                idTransaccionRespuestaObtenidoDesdeWs, ref _respuestaSql, ref _detalleRespuestaSql);

                        if (respuestaProcesadaEnBd)
                        {
                            respuestaMarcacionTransWeb = _lpTransWebRespuesta.MarcarRespuestaEnElWebService(requestTransWeb);
                            respuestaTransaccionProcesada.Registrado = true;
                        }
                        else
                        {
                            Logger.Log(Logger.Level.Error,
                                String.Format("El archivo : {0}  no ha sido generado correctamente ",
                                    respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta));
                            respuestaMarcacionTransWeb = _lpTransWebRespuesta.MarcarRespuestaEnElWebService(requestTransWeb);
                            Logger.Log(Logger.Level.Info, String.Format(
                                "Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                                requestTransWeb.IdTransaccion));
                        }
                    }

                    if (objEnvios != null)
                    {
                        respuestaTransaccionProcesada.NumeroOrden = objEnvios.NumeroOrden;
                    }
                }
                else
                {
                    respuestaMarcacionTransWeb = _lpTransWebRespuesta.MarcarRespuestaEnElWebService(requestTransWeb);
                    Logger.Log(Logger.Level.Info,
                        String.Format("Se marco la DLLMapRe.Entidades.respuesta con ID Transacción : {0} ",
                            requestTransWeb.IdTransaccion));

                }

                if (prmInput.GuardarRespuesta)
                {
                    LnRespuesta lnRespuesta = new LnRespuesta();
                    string nombreArchivo = respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta;
                    lnRespuesta.GuardarArchivoXmlEnDirectorioTemp(prmInput.RutaGuardarRespuesta, ref nombreArchivo,
                        respuestaPorTransaccionTransWeb.BytesDocumento, objEnvios, ref refMensaje, prmInput.CrearJeraquiaRespuesta);

                    //lnRespuesta.GuardarArchivoXmlEnDirectorio(prmInput.RutaGuardarRespuesta, ref nombreArchivo,
                    //    respuestaPorTransaccionTransWeb.BytesDocumento, objEnvios, ref refMensaje, prmInput.CrearJeraquiaRespuesta);

                    Logger.Log(Logger.Level.Info,
                        String.Format("IdTransaccion {0} ; Se guardo el archivo : {1} en la ruta : {2} ",
                        requestTransWeb.IdTransaccion,
                            respuestaPorTransaccionTransWeb.NombreDocumentoRespuesta, prmInput.RutaGuardarRespuesta));

                    respuestaTransaccionProcesada.NombreArchivoXML = nombreArchivo;
                    respuestaTransaccionProcesada.Descargado = true;
                }
                else
                {
                    respuestaTransaccionProcesada.Descargado = false;
                }

                listadoRespuestasProcesadas.Add(respuestaTransaccionProcesada);
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }
        
        private ParametroRespuestaTransWeb ObtenerRequestTransWeb(ParametroRespuestaMapRe oEnDatosGenerales)
        {
            ParametroRespuestaTransWeb requestRespuestaTransWeb = new ParametroRespuestaTransWeb();
            requestRespuestaTransWeb.Casilla = ConfigController.Conf.Casilla;//objENxmlSW.Casilla;
            requestRespuestaTransWeb.PwdCasilla = ConfigController.Conf.Pwdcasilla; //objENxmlSW.PwdCasilla;
            requestRespuestaTransWeb.UsuarioSistema = oEnDatosGenerales.UsuarioSistema;
            requestRespuestaTransWeb.IdUsuarioSistema = oEnDatosGenerales.IdUsuarioSistema;
            requestRespuestaTransWeb.IndicadorProxy = oEnDatosGenerales.IndicadorProxy;
            requestRespuestaTransWeb.IpProxy = oEnDatosGenerales.IpProxy;
            requestRespuestaTransWeb.UsuarioProxy = oEnDatosGenerales.UsuarioProxy;
            requestRespuestaTransWeb.PwdUsuarioProxy = oEnDatosGenerales.PwdUsuarioProxy;
            requestRespuestaTransWeb.Dominio = oEnDatosGenerales.Dominio;
            requestRespuestaTransWeb.UrlSatServer = ConfigController.Conf.UrlSatServer; //objENxmlSW.UrlSatServer;
            requestRespuestaTransWeb.UrlSatServerAlternativa = ConfigController.Conf.UrlSatServerAlternativa; //objENxmlSW.UrlSatServerAlternativa;
            requestRespuestaTransWeb.RutaLog = ConfigController.Conf.RutaLog;  //oEnDatosGenerales.RutaLog;
            requestRespuestaTransWeb.TimeOut = ConfigController.Conf.TimeOut; //objENxmlSW.TimeOut;
            return requestRespuestaTransWeb;
        }


    }
}
