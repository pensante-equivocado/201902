﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using DLLMapRe.Configuracion.Entidad;
using DLLMapRe.Configuracion.Proceso;
using DLLMapRe.Entidades.AppTag;
using DLLMapRe.Entidades.EnvioRegistro;
using DLLMapRe.Entidades.XmlOma;
using DLLMapRe.LogicaNegocio.Envio;
using DLLMapRe.LogicaNegocio.Maestro;
using DLLTransWeb.Entidades.Envio;
using DLLTransWeb.Entidades.Respuesta;
using DLLTransWeb.LogicaProceso;
using tciUtilitarios;

namespace DLLMapRe.LogicaProceso
{
    public class LpMapReEnvio
    {

        private readonly clsValidacionDatos _clsValidacionDatos = new clsValidacionDatos();
        private readonly LpTransWebEnvio _lpTransWebEnvio = new LpTransWebEnvio();
        private readonly clsUtilitarios _clsUtilitarios = new clsUtilitarios();
        private readonly LnValidarXml _lnValidarXml = new LnValidarXml();
        
        public Boolean TransmitirRegistro(ParametroEnvioMapRe prmInput, ref string strMensaje,
            ref List<ENRespuestaEnvio> listaEnviosProcesados)
        {
            Boolean seProcesoCorrectamente = false;
            try
            {
                ValidarParametrosEntrada(prmInput, ref strMensaje);
                if (!String.IsNullOrEmpty(strMensaje)) return false;
                
                if (!ValidarRutasEsquemas(prmInput, ref strMensaje))
                {
                    Logger.Log(Logger.Level.Error, strMensaje);
                    return false;
                }

                //Consultar desde la base de datos, el parametro validaesquema
                LnConfiguracion lnConfiguracion = new LnConfiguracion();
                Entidades.Maestro.Configuracion entidadConfiguracion = lnConfiguracion.ObtenerPorId(1);
                if (entidadConfiguracion != null)
                {
                    prmInput.ValidaEsquema = entidadConfiguracion.ValidaEsquema;
                    prmInput.NombreRespuesta = entidadConfiguracion.TipoNombreArchivo;
                }
                else
                {
                    Logger.Log(Logger.Level.Error, strMensaje);
                    return false;
                }


                string[] listaArchivosZip = Directory.GetFiles(prmInput.Directorio, "*.zip");
                Logger.Log(Logger.Level.Info,
                    String.Format("Se encontró {0} archivo(s) en la ruta : {1}", listaArchivosZip.Length,
                        prmInput.Directorio));

                foreach (string rutaCompletaArchivoZip in listaArchivosZip)
                {
                    TransmitirRegistroIndividual(rutaCompletaArchivoZip, prmInput, ref strMensaje,
                        ref listaEnviosProcesados, ref seProcesoCorrectamente);
                }
                return seProcesoCorrectamente;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                strMensaje = ex.Message;
                return false;
            }
        }

        private void ValidarParametrosEntrada(ParametroEnvioMapRe prmInput, ref string mensaje)
        {
            if (String.IsNullOrEmpty(prmInput.Servidor))
            {
                mensaje = "Parametro Servidor es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.BaseDatos))
            {
                mensaje = "Parametro BaseDatos es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.UsuarioBd))
            {
                mensaje = "Parametro UsuarioBd es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.ContraseniaBd))
            {
                mensaje = "Parametro ContraseniaBd es obligatorio";
                return;
            }
            //if (String.IsNullOrEmpty(prmInput.RutaLog))
            //{
            //    mensaje = "Parametro RutaLog es obligatorio";
            //    return;
            //}
            if (String.IsNullOrEmpty(prmInput.GestorBaseDatos))
            {
                mensaje = "Parametro GestorBaseDatos es obligatorio";
                return;
            }

            if (prmInput.GestorBaseDatos.Equals("2"))
            {
                if (String.IsNullOrEmpty(prmInput.PuertoMySql))
                {
                    mensaje = "Parametro PuertoMySql es obligatorio";
                    return;
                }
            }

            if (String.IsNullOrEmpty(prmInput.UrlSatServer))
            {
                mensaje = "Parametro UrlSatServer es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.UrlSatServerAlternativa))
            {
                mensaje = "Parametro UrlSatServerAlternativa es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.Casilla))
            {
                mensaje = "Parametro Casilla es obligatorio";
                return;
            }
            if (String.IsNullOrEmpty(prmInput.PwdCasilla))
            {
                mensaje = "Parametro PwdCasilla es obligatorio";
                return;
            }
            if (prmInput.TimeOut == 0)
            {
                mensaje = "Parametro TimeOut es obligatorio";
                return;
            }

            Config conf = new Config
            {
                Servidor = prmInput.Servidor,
                BaseDatos = prmInput.BaseDatos,
                Usuario = prmInput.UsuarioBd,
                Contrasenia = prmInput.ContraseniaBd,
                RutaLog = prmInput.RutaLog,

                GestorBaseDatos = prmInput.GestorBaseDatos,
                PuertoBaseDatos = prmInput.PuertoMySql,
                UrlSatServer = prmInput.UrlSatServer,
                UrlSatServerAlternativa = prmInput.UrlSatServerAlternativa,
                Casilla = prmInput.Casilla,
                Pwdcasilla = prmInput.PwdCasilla,
                TimeOut = prmInput.TimeOut
            };

            ConfigController.EstablecerConfiguracion(conf);
        }

        public void TransmitirRegistroIndividual(string rutaCompletaArchivoZip, ParametroEnvioMapRe prmInput, ref string strMensaje,
            ref List<ENRespuestaEnvio> listaEnviosProcesados, ref Boolean seProcesoCorrectamente)
        {
            string nombreArchivoZipConExtension = string.Empty;
            try
            {

                ENRespuestaEnvio respuestaEnvioEnProceso = new ENRespuestaEnvio();
                nombreArchivoZipConExtension = Path.GetFileName(rutaCompletaArchivoZip);
                string rutaDirectorioArchivoZip = Path.GetDirectoryName(rutaCompletaArchivoZip);
                string rutaCompletaArchivoXml = _clsUtilitarios.decompressFile(rutaDirectorioArchivoZip, nombreArchivoZipConExtension).Replace(@"/", @"\");
                string nombreArchivoXmlConExtension = Path.GetFileName(rutaCompletaArchivoXml);
                respuestaEnvioEnProceso.NombreArchivoZIP = nombreArchivoZipConExtension;
                respuestaEnvioEnProceso.NombreArchivoXML = nombreArchivoXmlConExtension;

                Logger.Log(Logger.Level.Info,
                    String.Format("{0} ; Se descomprimió el zip y se obtuvo el archivo: {1}.",
                        nombreArchivoZipConExtension, nombreArchivoXmlConExtension));

                OACustomsManifestPeru oCustomsDeclarationPeruType = null;

                if (prmInput.ValidaEsquema)
                {
                    //Leer XML
                    oCustomsDeclarationPeruType = LeerArchivoXmlMedianteEstructuraValidada(rutaCompletaArchivoXml);


                    if (oCustomsDeclarationPeruType != null)
                    {
                        seProcesoCorrectamente = true;
                        Logger.Log(Logger.Level.Info, String.Format("{0} ; Se mapeo el archivo.", nombreArchivoZipConExtension));
                    }
                    else
                    {
                        strMensaje =
                            string.Format("{0} ; Error al Mapear el archivo. Es incorrecto.", nombreArchivoZipConExtension);

                        Logger.Log(Logger.Level.Info, String.Format("{0} ; No se mapeo el archivo.", nombreArchivoZipConExtension));
                        EliminarArchivo(rutaCompletaArchivoXml);

                        MoverArchivo(rutaDirectorioArchivoZip, prmInput.DirectorioError, nombreArchivoZipConExtension);
                        Logger.Log(Logger.Level.Info,
                            String.Format("{0} ; Se movio el árchivo a la ruta {1}", nombreArchivoZipConExtension, prmInput.DirectorioError));

                        return;
                    }

                }

                ParametroEnvioTransWeb entidadEnvioTransWeb = ObtenerRequestEnvioTransWeb(prmInput);
                DocumentoEnvioTransWeb entidadDocumentoEnvioTransWeb = null;

                LnLecturaXmlOma lpLecturaXmlOma = new LnLecturaXmlOma();
                String codigoTransaccionDesdeXml = "";
                Boolean esEstructuraOma = lpLecturaXmlOma.ValidarEstructura(rutaCompletaArchivoXml, ref codigoTransaccionDesdeXml);

                DeclarationMetaData lectura = null;
                Entidades.AppTag.Envio envioSql = null;
                List<string> lstErrores = new List<string>();

                if (prmInput.ValidaEsquema)
                {
                    if (!esEstructuraOma)
                    {
                        //transfiere valores desde lo mapeado a la entidad envioSql
                        AsignarValoresConEsquemaCustomsManifestPeru(oCustomsDeclarationPeruType, null,
                            rutaDirectorioArchivoZip, nombreArchivoXmlConExtension,
                            ObtenerTamanioArchivo(rutaCompletaArchivoXml),
                            ref entidadDocumentoEnvioTransWeb,
                            ref envioSql,
                            ref lstErrores);
                    }
                    //JPT - 27/11/2014
                    if (oCustomsDeclarationPeruType != null)
                    {
                        respuestaEnvioEnProceso.NumeroOrden =
                            _clsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.HeaderExchangedDocument.TraderAssignedID[0].Value);
                    }
                }
                else
                {
                    //oEnviosSQL se crea una instancia
                    AsignarValoresSinEsquemaCustomsManifestPeru(null, rutaDirectorioArchivoZip, nombreArchivoXmlConExtension, 
                        ObtenerTamanioArchivo(rutaCompletaArchivoXml), ref entidadDocumentoEnvioTransWeb, ref envioSql);

                    lstErrores = new List<string>();

                    if (esEstructuraOma)
                    {
                        lectura = lpLecturaXmlOma.LeerArchivoXml(rutaCompletaArchivoXml, ref envioSql);
                        entidadDocumentoEnvioTransWeb.CodTransaccion = lectura.NumeroTransaccion;
                        Logger.Log(Logger.Level.Info,
                            String.Format("{0} ; Código de transacción es: {1}.", nombreArchivoZipConExtension,
                                lectura.NumeroTransaccion));
                    }

                }

                if (entidadEnvioTransWeb.IdUsuarioSistema > 0)
                {
                    if (envioSql != null)
                    {
                        envioSql.IdUsuario = entidadEnvioTransWeb.IdUsuarioSistema;
                    }
                }
                
                entidadEnvioTransWeb.DocumentoEnvio = entidadDocumentoEnvioTransWeb;

                bool bolValidar;
                if (prmInput.ValidaEsquema)
                {
                    bolValidar = _lnValidarXml.fbol_ValidarXML(rutaCompletaArchivoXml,
                        prmInput.RutaCustomsDeclarationPeru,
                        prmInput.RutaReusableAggregateBusiness1,
                        prmInput.RutaReusableAggregateBusiness6, ref lstErrores);
                    Logger.Log(Logger.Level.Info, String.Format("{0} ; Se validó el archivo contra los esquemas.", nombreArchivoZipConExtension));
                }
                else
                {
                    bolValidar = true;
                    Logger.Log(Logger.Level.Info, String.Format("{0} ; No se validó el archivo contra los esquemas.", nombreArchivoZipConExtension));
                }

                RespuestaTransWeb entidadRespuestaTransWeb = null;

                //bolValidar = ValidarCamposNotNullEnvio(envioSql);

                if (bolValidar)
                {
                    try
                    {
                        _lpTransWebEnvio.NombreZipProceso = nombreArchivoZipConExtension;
                        entidadRespuestaTransWeb = _lpTransWebEnvio.ProcesarTransmisionRegistro(entidadEnvioTransWeb);
                        if (entidadRespuestaTransWeb == null)
                        {
                            respuestaEnvioEnProceso.Transmitido = false;
                            prmInput.RegistrarDatos = false;
                            bolValidar = false;
                            Logger.Log(Logger.Level.Info,
                                String.Format("{0} ; Se produjo un problema con el envío del archivo.", nombreArchivoZipConExtension));
                        }
                        else
                        {
                            respuestaEnvioEnProceso.Transmitido = true;
                            Logger.Log(Logger.Level.Info, String.Format("{0} ; Se envió el archivo y el id transaccion obtenido es: {1}", nombreArchivoZipConExtension, entidadRespuestaTransWeb.IdTransaccionEnvio));

                        }
                    }
                    catch (Exception ee)
                    {
                        respuestaEnvioEnProceso.Transmitido = false;
                        Logger.Log(Logger.Level.Error, ee.Message);
                    }
                }
                else
                {
                    respuestaEnvioEnProceso.Transmitido = false;

                    for (int i = 0; i <= lstErrores.Count - 1; i++)
                    {
                        Logger.Log(Logger.Level.Error, lstErrores[i]);
                    }
                }

                if (prmInput.RegistrarDatos)
                {
                    LnEnvio lnEnvio = new LnEnvio();
                    if (lnEnvio.RegistrarEnvioSql(envioSql, entidadRespuestaTransWeb, bolValidar, lstErrores, prmInput.TipoAmbiente, nombreArchivoZipConExtension, lectura))
                    {
                        respuestaEnvioEnProceso.Registrado = true;
                        seProcesoCorrectamente = true;
                        Logger.Log(Logger.Level.Info, String.Format("{0} ; Se registró satisfactoriamente en la base de datos del sistema STACE.", nombreArchivoZipConExtension));
                    }
                    else
                    {
                        respuestaEnvioEnProceso.Registrado = false;
                        Logger.Log(Logger.Level.Info,
                            String.Format("{0} ; Ocurrio un error al registrar en la base de datos del sistema STACE.", nombreArchivoZipConExtension));
                    }

                }
                else
                {
                    respuestaEnvioEnProceso.Registrado = false;
                }

                listaEnviosProcesados.Add(respuestaEnvioEnProceso);

                Logger.Log(Logger.Level.Info,
                    String.Format("{0} ; Se procede a eliminar el archivo: {1}.", nombreArchivoZipConExtension,
                        nombreArchivoXmlConExtension));
                EliminarArchivo(rutaCompletaArchivoXml);

                if (bolValidar)
                {
                    MoverArchivo(rutaDirectorioArchivoZip, prmInput.DirectorioProcesados, nombreArchivoZipConExtension);
                    Logger.Log(Logger.Level.Info,
                        String.Format("{0} ; Se movio el árchivo a la ruta {1}", nombreArchivoZipConExtension,
                            prmInput.DirectorioProcesados));
                }
                else
                {
                    MoverArchivo(rutaDirectorioArchivoZip, prmInput.DirectorioError, nombreArchivoZipConExtension);
                    Logger.Log(Logger.Level.Info,
                        String.Format("{0} ; Se movio el árchivo a la ruta {1}", nombreArchivoZipConExtension,
                            prmInput.DirectorioError));
                }

            }
            catch (FileNotFoundException e)
            {
                Logger.Log(Logger.Level.Error,
                    String.Format("{0} ; {1}", nombreArchivoZipConExtension, e.Message));
            }
        }

        private Boolean ValidarCamposNotNullEnvio(Envio envio)
        {
            try
            {
                string mensajeValidacion = string.Empty;
                if (envio.FechaImportacion.Year < 2000)
                {
                    mensajeValidacion = String.Concat(mensajeValidacion,
                        String.Format("El valor de '{0}' es obligatorio. ", "FechaImportacion"));
                }
                if (String.IsNullOrEmpty(envio.AnioManifiesto))
                {
                    mensajeValidacion = String.Concat(mensajeValidacion,
                        String.Format("El valor de '{0}' es obligatorio. ", "Año Manifiesto"));
                }
                if (String.IsNullOrEmpty(envio.Nromanifiesto))
                {
                    mensajeValidacion = String.Concat(mensajeValidacion,
                        String.Format("El valor de '{0}' es obligatorio. ", "Numero de Manifiesto"));
                }
                if (String.IsNullOrEmpty(envio.NroDocumentoTransporte))
                {
                    mensajeValidacion = String.Concat(mensajeValidacion,
                        String.Format("El valor de '{0}' es obligatorio. ", "Numero Documento de Transporte"));
                }
                if (String.IsNullOrEmpty(mensajeValidacion))
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            catch
            {
                return false;
            }
        }

        private bool ValidarRutasEsquemas(ParametroEnvioMapRe envioRegistro, ref string mensaje)
        {
            if (!File.Exists(envioRegistro.RutaReusableAggregateBusiness1))
            {
                mensaje = "No existe el esquema en la ruta: " + envioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            if (!File.Exists(envioRegistro.RutaReusableAggregateBusiness6))
            {
                mensaje = "No existe el esquema en la ruta: " + envioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            if (!File.Exists(envioRegistro.RutaCustomsDeclarationPeru))
            {
                mensaje = "No existe el esquema en la ruta: " + envioRegistro.RutaReusableAggregateBusiness1;
                return false;
            }

            return true;
        }

        private void EliminarArchivo(string filename)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            File.Delete(filename);
        }

        private Int64 ObtenerTamanioArchivo(string rutaCompletaArchivo)
        {
            try
            {
                FileInfo info = new FileInfo(rutaCompletaArchivo);
                Int64 intLongitud = info.Length;
                return intLongitud;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        #region "SETEAR VALORES"

        private bool ValidarFecha(string sdate, ref string mensajeRetorno)
        {
            bool esFecha = true;
            try
            {
                DateTime.Parse(sdate);
            }
            catch (Exception ex)
            {
                mensajeRetorno = ex.Message;
                esFecha = false;
            }

            return esFecha;
        }


        /// <summary>
        /// Transfiere valores desde lo mapeado a la entidad envioSql
        /// </summary>
        private void AsignarValoresConEsquemaCustomsManifestPeru(OACustomsManifestPeru oCustomsDeclarationPeruType, byte[] bytesArchivoXml,
            string rutaDirectorioArchivoXml, string nombreArchivoXml, long? tamanioArchivo, ref DocumentoEnvioTransWeb entidadDocumentoEnvioTransWeb,
            //ref ENVIOS envioSql, 
            ref Entidades.AppTag.Envio envioSql,
            ref List<string> strLstError)
        {
            try
            {
                LnTipoOperador lnTipoOperador = new LnTipoOperador();
                LnViaTransporte lnViaTransporte = new LnViaTransporte();
                LnTipoManifiesto lnTipoManifiesto = new LnTipoManifiesto();
                LnTipoCarga lnTipoCarga = new LnTipoCarga();
                LnIndUltimoEnvio lnIndUltimoEnvio = new LnIndUltimoEnvio();

                string mensajeError = string.Empty;
                envioSql = new Entidades.AppTag.Envio();  //new ENVIOS(); // Objeto Envios EF
                Int32? intIdTipoOperador = null;
                Int32? intIdTipoManifiesto = null;
                Int32? intIdIndUltimoEnvio = null;
                Int32? intIdTipoCarga = null;
                Int32? intIdViaTransporte = null;
                Int32 intCantidad = 0;

                entidadDocumentoEnvioTransWeb = new DocumentoEnvioTransWeb // Objeto TransWeb
                {
                    CodTransaccion =
                        _clsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext.SpecifiedTransactionID.Value),
                    FechaCreacion = DateTime.Now,
                    Documento = bytesArchivoXml ?? ConvertirArchivoaBytes(rutaDirectorioArchivoXml + @"\" + nombreArchivoXml),
                    NombreDocumento = nombreArchivoXml,
                    Longitud = Convert.ToInt32(tamanioArchivo)
                };

                envioSql.FechaImportacion = DateTime.Now;
                envioSql.PesoArchivo = Convert.ToInt32(tamanioArchivo);
                envioSql.ArchivoXml = entidadDocumentoEnvioTransWeb.Documento;
                envioSql.NombreArchivo = nombreArchivoXml;

                if (oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext != null)
                {
                    envioSql.CodTipoTransaccion =
                        _clsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.SpecifiedExchangedDocumentContext.SpecifiedTransactionID.Value);
                }

                if (oCustomsDeclarationPeruType.HeaderExchangedDocument != null)
                {
                    if (ValidarFecha(oCustomsDeclarationPeruType.HeaderExchangedDocument.IssueDateTime.ToString(),
                        ref mensajeError))
                    {
                        envioSql.FechaGeneracion = oCustomsDeclarationPeruType.HeaderExchangedDocument.IssueDateTime;
                    }
                    else
                    {
                        strLstError.Add(mensajeError);
                    }

                    envioSql.NumeroOrden =
                        _clsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.HeaderExchangedDocument.TraderAssignedID[0].Value);
                    envioSql.RucAgenteAduana =
                        _clsValidacionDatos.fstr_ObtenDato(
                            oCustomsDeclarationPeruType.HeaderExchangedDocument.SenderTradeParty.ID[0].Value);


                    var entidadTipoOperador = lnTipoOperador.ObtenerPorCodigo(
                        oCustomsDeclarationPeruType.HeaderExchangedDocument.SenderTradeParty.TypeCode[0].Value);
                    if (entidadTipoOperador != null)
                    {
                        intIdTipoOperador = entidadTipoOperador.IdTipoOperador;
                    }

                    envioSql.IdTipoOperador = intIdTipoOperador;

                }

                if (oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement != null)
                {
                    var entidadViaTransporte =
                        lnViaTransporte.ObtenerPorCodigo(oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                            .ModeCode.Value.ToString()
                            .Replace("Item", ""));
                    if (entidadViaTransporte != null)
                    {
                        intIdViaTransporte = entidadViaTransporte.IdViaTransporte;
                    }

                    envioSql.IdViaTransporte = intIdViaTransporte;

                    if (
                        oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                            .ManifestRelatedReferencedDocument != null)
                    {
                        envioSql.Nromanifiesto =
                            _clsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].ID[0].Value);
                        envioSql.AnioManifiesto =
                            _clsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].AcceptanceDateTime.Year.ToString(
                                        CultureInfo.InvariantCulture));

                        var entidadTipoManifiesto =
                            lnTipoManifiesto.ObtenerPorCodigo(_clsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].CategoryCode.Value));
                        if (entidadTipoManifiesto != null)
                        {
                            intIdTipoManifiesto = entidadTipoManifiesto.IdTipoManifiesto;
                        }

                        envioSql.IdTipoManifiesto = intIdTipoManifiesto;

                        envioSql.CodAduanaDeclaracion =
                            _clsValidacionDatos.fstr_ObtenDato(
                                oCustomsDeclarationPeruType.SpecifiedLogisticsTransportMovement
                                    .ManifestRelatedReferencedDocument[0].LodgementLogisticsLocation.ID[0].Value);
                    }
                }


                if (oCustomsDeclarationPeruType.SpecifiedSupplyChainConsignment != null)
                {
                    foreach (
                        SupplyChainConsignmentType objSpecifiedSupplyChainConsignment in
                            oCustomsDeclarationPeruType.SpecifiedSupplyChainConsignment)
                    {
                        envioSql.NroDetalle = (int?) objSpecifiedSupplyChainConsignment.SequenceNumeric;

                        if (objSpecifiedSupplyChainConsignment.TransportContractReferencedDocument != null)
                        {
                            envioSql.NroDocumentoTransporte =
                                objSpecifiedSupplyChainConsignment.TransportContractReferencedDocument.ID[0].Value;
                        }

                        if (objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus != null)
                        {
                            if (
                                !string.IsNullOrEmpty(
                                    objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus[0].ConditionCode.Value))
                            {
                                var entidadIndUltimoEnvio =
                                    lnIndUltimoEnvio.ObtenerPorCodigo(
                                        objSpecifiedSupplyChainConsignment.ReportedLogisticsStatus[0].ConditionCode
                                            .Value);
                                if (entidadIndUltimoEnvio != null)
                                {
                                    intIdIndUltimoEnvio = entidadIndUltimoEnvio.IdIndUltimoEnvio;
                                }

                                envioSql.IdIndUltimoEnvio = intIdIndUltimoEnvio;
                            }
                            if (
                                !string.IsNullOrEmpty(
                                    objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value))
                            {

                                var entidadTipoCarga =
                                    lnTipoCarga.ObtenerPorCodigo(
                                        objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value);
                                if (entidadTipoCarga != null)
                                {
                                    intIdTipoCarga = entidadTipoCarga.IdTipoCarga;
                                }

                                envioSql.IdTipoCarga = intIdTipoCarga;

                                switch (objSpecifiedSupplyChainConsignment.TransportLogisticsPackage[0].TypeCode.Value)
                                {
                                    case "07": //Chasis
                                        if (objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem !=
                                            null)
                                        {
                                            intCantidad =
                                                objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem
                                                    .Count();
                                        }
                                        break;
                                    case "09": //Contenerizada
                                        if (objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem !=
                                            null)
                                        {
                                            intCantidad =
                                                objSpecifiedSupplyChainConsignment.IncludedSupplyChainConsignmentItem
                                                    .Count();
                                        }
                                        break;

                                }
                                envioSql.CantidadCarga = intCantidad;
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }


        private void AsignarValoresSinEsquemaCustomsManifestPeru(byte[] byteArchivo, string rutaDirectorioArchivoXml, string nombreArchivoXml,
            Nullable<Int64> intLongitud, ref DocumentoEnvioTransWeb enDocumentoEnvio, 
            //ref ENVIOS envio
            ref Entidades.AppTag.Envio envio
            )
        {
            try
            {
                
                enDocumentoEnvio = new DocumentoEnvioTransWeb();
                //enDocumentoEnvio.CodTransaccion = "";
                enDocumentoEnvio.FechaCreacion = DateTime.Now;
                if (byteArchivo != null)
                {
                    enDocumentoEnvio.Documento = byteArchivo;
                }
                else
                {
                    enDocumentoEnvio.Documento = ConvertirArchivoaBytes(rutaDirectorioArchivoXml + @"\" + nombreArchivoXml);
                }
                enDocumentoEnvio.NombreDocumento = nombreArchivoXml;
                enDocumentoEnvio.Longitud = Convert.ToInt32(intLongitud);


                envio = new Entidades.AppTag.Envio();
                envio.FechaImportacion = DateTime.Now;
                envio.PesoArchivo = Convert.ToInt32(intLongitud);
                envio.NumeroOrden = "";
                envio.RucAgenteAduana = "";
                envio.ArchivoXml = enDocumentoEnvio.Documento;
                envio.NombreArchivo = nombreArchivoXml;
                envio.Nromanifiesto = "";
                envio.AnioManifiesto = "";
                envio.NroDocumentoTransporte = "";
                envio.IdUsuario = null;

                //return true;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                //return false;
            }
        }

        private ParametroEnvioTransWeb ObtenerRequestEnvioTransWeb(ParametroEnvioMapRe prmInput)
        {
            ParametroEnvioTransWeb envioTransWeb = new ParametroEnvioTransWeb();
            envioTransWeb.Casilla = ConfigController.Conf.Casilla; //objENxmlSW.Casilla;
            envioTransWeb.PwdCasilla = ConfigController.Conf.Pwdcasilla; //objENxmlSW.PwdCasilla;
            envioTransWeb.UsuarioSistema = prmInput.UsuarioSistema;
            envioTransWeb.IdUsuarioSistema = prmInput.IdUsuarioSistema;
            envioTransWeb.IndicadorProxy = prmInput.IndicadorProxy;
            envioTransWeb.IpProxy = prmInput.IpProxy;
            envioTransWeb.PuertoProxy = prmInput.PuertoProxy;
            envioTransWeb.UsuarioProxy = prmInput.UsuarioProxy;
            envioTransWeb.PwdUsuarioProxy = prmInput.PwdUsuarioProxy;
            envioTransWeb.Dominio = prmInput.Dominio;
            envioTransWeb.UrlSatServer = ConfigController.Conf.UrlSatServer; //objENxmlSW.UrlSatServer;
            envioTransWeb.UrlSatServerAlternativa = ConfigController.Conf.UrlSatServerAlternativa; //objENxmlSW.UrlSatServerAlternativa;
            envioTransWeb.RutaLog = ConfigController.Conf.RutaLog;  //oENEnvioRegistro.RutaLog;
            envioTransWeb.TimeOut = ConfigController.Conf.TimeOut; //objENxmlSW.TimeOut;
            return envioTransWeb;
        }


        #endregion

        #region "MAPEO DE XML"


        private OACustomsManifestPeru LeerArchivoXmlMedianteEstructuraValidada(string rutaArchivoXml)
        {
            try
            {
                OACustomsManifestPeru oCustomsDeclarationPeruType;
                using (FileStream xmlStream = new FileStream(rutaArchivoXml, FileMode.Open))
                {
                    using (XmlReader xmlReader = XmlReader.Create(xmlStream))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof (OACustomsManifestPeru));
                        oCustomsDeclarationPeruType = serializer.Deserialize(xmlReader) as OACustomsManifestPeru;
                    }
                }
                return oCustomsDeclarationPeruType;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error,
                    (String.IsNullOrEmpty(ex.InnerException.Message) ? ex.Message : ex.InnerException.Message));
                return null;
            }
        }

        #endregion

        #region "METODOS UTILES"

        private byte[] ConvertirArchivoaBytes(string rutaCompletaArchivo)
        {
            try
            {
                FileStream fs = new FileStream(rutaCompletaArchivo, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(rutaCompletaArchivo).Length;
                byte[]  bytesResultante = br.ReadBytes((int)numBytes);
                fs.Dispose();
                fs.Close();
                br.Dispose();
                br.Close();
                return bytesResultante;
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
                return null;
            }

        }

        private void MoverArchivo(string rutaDirectorioOrigen, string rutaDirectorioDestino, string nombreArchivo)
        {
            try
            {
                string mensajeErrorAlCrearRuta = string.Empty;
                if (_clsUtilitarios.fbol_CrearRuta(rutaDirectorioDestino, ref mensajeErrorAlCrearRuta) == false)
                {
                    Logger.Log(Logger.Level.Error, mensajeErrorAlCrearRuta);
                    return;
                }
                string strtempo = DateTime.Now.Year + ExtraerCaracteresPorLaDerecha("0" + DateTime.Now.Month, 2) +
                                  ExtraerCaracteresPorLaDerecha("0" + DateTime.Now.Day, 2) + ExtraerCaracteresPorLaDerecha("0" + DateTime.Now.Hour, 2) +
                                  ExtraerCaracteresPorLaDerecha("0" + DateTime.Now.Minute, 2) + ExtraerCaracteresPorLaDerecha("0" + DateTime.Now.Second, 2) +
                                  ExtraerCaracteresPorLaDerecha("00" + DateTime.Now.Millisecond, 3);
                GC.Collect();
                File.Move(rutaDirectorioOrigen + @"\" + nombreArchivo,
                    rutaDirectorioDestino + @"\" + nombreArchivo.Replace(".zip", "") + strtempo + @".zip");
            }
            catch (Exception ex)
            {
                Logger.Log(Logger.Level.Error, ex.Message);
            }
        }

        private static string ExtraerCaracteresPorLaDerecha(string texto, int numeroCaracteres)
        {
            return texto.Substring(texto.Length - numeroCaracteres);
        }

        #endregion




    }
}
