﻿namespace DLLMapRe.Configuracion.Entidad
{
    public class Log
    {
        public string Usuario { get; set; }
        public string Ip { get; set; }
        public string Proyecto { get; set; }
        public string Clase { get; set; }
        public string Metodo { get; set; }
        public string NombreArchivo { get; set; }
    }
}
