﻿using System;

namespace DLLMapRe.Configuracion.Entidad
{
    public class Config
    {
        public string Servidor { get; set; }
        public string BaseDatos { get; set; }
        public string Usuario { get; set; }
        public string Contrasenia { get; set; }
        public string GestorBaseDatos { get; set; }
        public string PuertoBaseDatos { get; set; }


        public string Casilla { get; set; }
        public string Pwdcasilla { get; set; }
        public string UrlSatServer { get; set; }
        public string UrlSatServerAlternativa { get; set; }
        public Int32 TimeOut { get; set; }


        public string RutaLog { get; set; }
        public string RutaXml { get; set; }
        public string RutaArchivos { get; set; }


        public string Cn { get; set; }
        public string CnEntityFrameworkSql { get; set; }
        public string CnEntityFrameworkMySql { get; set; }
        public Boolean ConfiguracionValida { get; set; }
        public Boolean ConfiguracionModificada { get; set; }

        public Config()
        {
            RutaLog = string.Empty;
            TimeOut = 5000;
            CnEntityFrameworkSql = string.Empty;
            CnEntityFrameworkMySql = string.Empty;
        }
    }
}
