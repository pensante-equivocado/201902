﻿using System;
using System.Data.EntityClient;
using System.Data.SqlClient;
using System.IO;
using DLLMapRe.Configuracion.Entidad;

namespace DLLMapRe.Configuracion.Proceso
{
    public class ConfigController: Logger
    {
        public static Config Conf = new Config();
        private const string NombreArchivo = "ConfiguracionCom.xml";

        #region "Obtener Configuración"

        public static void EstablecerConfiguracion(Config prmInput)
        {
            try
            {

                Conf.RutaArchivos = AppDomain.CurrentDomain.BaseDirectory;
                Conf.RutaXml = Path.Combine(Conf.RutaArchivos, NombreArchivo);
                Conf.RutaLog = prmInput.RutaLog;

                    if (String.IsNullOrEmpty(Conf.RutaLog))
                    {
                        Conf.RutaLog = Path.Combine(Conf.RutaArchivos, "Log");
                    }


                Conf.Servidor = prmInput.Servidor;
                Conf.BaseDatos = prmInput.BaseDatos;
                Conf.Usuario = prmInput.Usuario;
                Conf.Contrasenia = prmInput.Contrasenia;
                Conf.Casilla = prmInput.Casilla; //NodeValue(tag, "Casilla");
                Conf.Pwdcasilla = prmInput.Pwdcasilla;  //NodeValue(tag, "Pwdcasilla"));
                Conf.UrlSatServer = prmInput.UrlSatServer; //NodeValue(tag, "UrlSatServer");
                Conf.UrlSatServerAlternativa = prmInput.UrlSatServerAlternativa; //NodeValue(tag, "UrlSatServerAlternativa");
                Conf.TimeOut = Convert.ToInt32(prmInput.TimeOut); // NodeValue(tag, "TimeOut", "5000"));


                Conf.Cn = ObtenerConeccionSql();
                Conf.GestorBaseDatos = prmInput.GestorBaseDatos;
                Conf.PuertoBaseDatos = prmInput.PuertoBaseDatos;

                if (Conf.GestorBaseDatos.Equals("1"))
                {
                    Conf.CnEntityFrameworkSql = ObtenerCadenaConeccionEntityFrameworkSql();
                }
                else
                {
                    Conf.CnEntityFrameworkMySql = ObtenerCadenaConeccionEntityFrameworkMySql();
                }


                Conf.ConfiguracionValida = true;


            }
            catch (Exception ex)
            {
                Conf.ConfiguracionValida = false;
                Log(Level.Error, ex.Message);

            }
        }

        #endregion


        #region Cadena - Conexion Base de Datos

        private static string ObtenerConeccionSql()
        {


            var cn = String.Format(
                "Data Source={0};Initial Catalog={1};Integrated Security=false;User ID={2};Password={3};",
                Conf.Servidor,
                Conf.BaseDatos,
                Conf.Usuario,
                Conf.Contrasenia);

            return cn;
        }

        private static string ObtenerCadenaConeccionEntityFrameworkSql()
        {
            string proveedor = "System.Data.SqlClient";
            string cadenaConeccion = new EntityConnectionStringBuilder
            {
                Metadata =
                    "res://*/AccesoDatos.APPTAGSQL.csdl|res://*/AccesoDatos.APPTAGSQL.ssdl|res://*/AccesoDatos.APPTAGSQL.msl",
                Provider = proveedor,
                ProviderConnectionString = new SqlConnectionStringBuilder
                {
                    InitialCatalog = Conf.BaseDatos,
                    DataSource = Conf.Servidor,
                    IntegratedSecurity = false,
                    UserID = Conf.Usuario,
                    Password = Conf.Contrasenia,
                }.ConnectionString
            }.ConnectionString;

            return cadenaConeccion;
        }

        private static string ObtenerCadenaConeccionEntityFrameworkMySql()
        {
            string proveedor = "MySql.Data.MySqlClient";
            string strRutaAplicacion = AppDomain.CurrentDomain.BaseDirectory;
            string cadenaConeccion = "metadata=" + strRutaAplicacion +
                                     "/AccesoDatos/APPTAGMYSQL.ssdl|res://*/AccesoDatos.APPTAGSQL.csdl|res://*/AccesoDatos.APPTAGSQL.msl;provider=" +
                                     proveedor + ";provider connection string='server=" + Conf.Servidor + ";Port=" +
                                     Conf.PuertoBaseDatos +
                                     ";user id=" + Conf.Usuario + ";password=" + Conf.Contrasenia +
                                     ";persist security info=True;database=" + Conf.BaseDatos + "'";
            return cadenaConeccion;

        }


        #endregion
    }
}
