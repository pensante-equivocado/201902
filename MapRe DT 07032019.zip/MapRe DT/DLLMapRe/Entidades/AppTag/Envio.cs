﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class Envio
    {
        public Int32 IdEnvio { get; set; }//IDENTITY(1,1) NOT NULL,
        public DateTime FechaImportacion { get; set; }//[datetime2](7) NOT NULL,
        public String Nromanifiesto { get; set; } //nvarchar(6) not null,
        public String AnioManifiesto { get; set; } //nvarchar(4) not null,
        public String NroDocumentoTransporte { get; set; } //nvarchar(25) not null,

        public Int32? IdUsuario { get; set; }//[int] NULL,
        public String CodRegimenRef { get; set; }//[nvarchar](3) NULL,
        public String CodRegimenGen { get; set; }//[nvarchar](3) NULL,
        public String NroCorrelativo { get; set; }//[nvarchar](10) NULL,
        public DateTime? FechaDeclaracion { get; set; } //datetime2(7) null,
        public String CodAduanaDeclaracion { get; set; } //nvarchar(3) null,
        public String CantidadSeries { get; set; } //nvarchar(4) null,
        public String NroDocumentoDeclarante { get; set; } //nvarchar(11) null,
        public String TipoDocumentoDeclarante { get; set; } //nvarchar(2) null,
        public String RazonSocialDeclarante { get; set; } //nvarchar(175) null,
        public String CodModalidad { get; set; } //nvarchar(3) null,
        public String CodAduanaPresentacion { get; set; } //nvarchar(3) null,
        public Int32? IdEstadoRespuesta { get; set; } //int null,
        public Int32? IdEstadoAcuse { get; set; } //int null,
        public Int32? IdEstadoTci { get; set; } //int null,
        public String NroTicket { get; set; } //nvarchar(17) null,
        public DateTime? FechaTci { get; set; } //datetime2(7) null,
        public DateTime? FechaAcuse { get; set; } //datetime2(7) null,
        public DateTime? FechaRespuesta { get; set; } //datetime2(7) null,
        public DateTime? FechaGeneracion { get; set; } //datetime2(7) null,
        public byte[] ArchivoXml { get; set; } //varbinary(max) null,
        public String NombreArchivo { get; set; } //nvarchar(200) null,
        public Int32? IdTransaccion { get; set; } //int null,
        public Int32? PesoArchivo { get; set; } //int null,
        public Int32? PasoEsquema { get; set; } //int null,
        public String CodTipoTransaccion { get; set; } //nvarchar(5) null,
        public String NumeroOrden { get; set; } //nvarchar(10) null,
        public String TipoAforo { get; set; } //nvarchar(5) null,
        public DateTime? FechaUltimoDiaPago { get; set; } //datetime2(7) null,
        public Boolean? TipoAmbiente { get; set; } //bit null,
        public String RucAgenteAduana { get; set; } //varchar(11) null,
        public Int32? IdTipoOperador { get; set; } //int null,
        public Int32? IdViaTransporte { get; set; } //int null,
        public Int32? IdIndUltimoEnvio { get; set; } //int null,
        public Int32? IdTipoCarga { get; set; } //int null,
        public Int32? IdTipoManifiesto { get; set; } //int null,
        public Int32? NroDetalle { get; set; } //int null,
        public Int32? CantidadCarga { get; set; } //int null

    }
}
