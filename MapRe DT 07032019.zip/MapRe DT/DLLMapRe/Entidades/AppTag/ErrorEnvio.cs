﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class ErrorEnvio
    {

        public Int32 IdErrorEnvio { get; set; }
        public Int32 IdEnvio { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaRegistro { get; set; }
        

    }
}
