﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class DetalleRespuesta
    {

        public Int32 IdDetalleRespuesta { get; set; } //int identity(1,1) not null,
        public String Codigo { get; set; } // nvarchar(10) null,
        public String Descripcion { get; set; } //nvarchar(1000) null,
        public Int32 IdRespuesta { get; set; } //int not null,
        public Int32? TipoMensaje { get; set; } //int null,
        public String NroManifiesto { get; set; } //nvarchar(6) null,
        public DateTime? FechaAceptacion { get; set; } //datetime2(7) null,
        public String TipoDocCda { get; set; } //nvarchar(2) null


    }
}
