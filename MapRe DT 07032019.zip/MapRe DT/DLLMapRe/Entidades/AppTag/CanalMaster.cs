﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class CanalMaster
    {
        public Int32 IdCanalMaster { get; set; } // int IDENTITY(1,1) NOT NULL,
        public String CodAduana { get; set; } //varchar(4) NULL,
        public String AnioManifiesto { get; set; } //varchar(4) NULL,
        public String NumManifiesto { get; set; } //varchar(8) NULL,
        public DateTime? FechaRegistro { get; set; } //datetime NULL,
        public String BlMaster { get; set; } //varchar(25) NULL,
        public Int32? IdEstado { get; set; } //int NULL
    }
}
