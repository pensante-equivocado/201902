﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class Respuesta
    {

        public Int32 IdRespuesta { get; set; } //int IDENTITY(1,1) NOT NULL,
        public Int32 IdEnvio { get; set; } //int NOT NULL,
        public Int32 IdEstadoRespuesta { get; set; } //int NOT NULL,
        public DateTime FechaAceptacion { get; set; } //datetime2(7) NULL,
        public Int32 IdTipoRespuesta { get; set; } //int NOT NULL,
        public String NombreArchivo { get; set; } //nvarchar(200) NULL,
        public byte?[] ArchivoXml { get; set; } //varbinary(max) NULL,
        public String NumeCorre { get; set; } //nvarchar(10) NULL,
        public String SdocCda { get; set; } //nvarchar(5) NULL,
        public String DigiVeri { get; set; } //nvarchar(2) NULL,
        public DateTime? FechaNumeracion { get; set; } //datetime2(7) NULL,
        public DateTime? FechaUltimoDiaPago { get; set; } //datetime2(7) NULL,
        public String Convenio { get; set; } //nvarchar(2) NULL,
        public String TdocCda { get; set; } //nvarchar(2) NULL,
        public String TipoAforo { get; set; } //nvarchar(5) NULL,
        public String MensajeNotificacion { get; set; } //nvarchar(220) NULL,
        public String FuncionResumen { get; set; } //nvarchar(50) NULL,
        public String CodRegimenDeclaracion { get; set; } //nvarchar(3) NULL,
        public String CodAduanaDeclaracion { get; set; } //nvarchar(3) NULL,
        public DateTime? FechaCancelacion { get; set; } //datetime2(7) NULL,
        public Decimal? MontoCancelados { get; set; } //decimal(15, 3) NULL,
        public String CodBanco { get; set; } //nvarchar(5) NULL,
        public Decimal? TipoCambio { get; set; } //decimal(15, 6) NULL,
        public DateTime? FechaTipoCambio { get; set; } //datetime2(7) NULL,
        public DateTime? FechaRegistro { get; set; } //datetime2(7) NULL,
        public Boolean IndAceptado { get; set; } //bit NOT NULL


    }
}
