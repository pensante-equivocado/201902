﻿using System;

namespace DLLMapRe.Entidades.AppTag
{
    public class DocumentoTransporteEnvio
    {
        public Int32 IdDocumentoTransporteEnvio { get; set; }
        public Int32 IdEnvio { get; set; }
        public Int32 NumeroDetalle { get; set; }
        public String NumeroDocumentoTransporte { get; set; }
        public String CodigoTipoCarga { get; set; }
        public String VinVehiculo { get; set; }
        public String NumeroEquipamiento { get; set; }

    }
}
