﻿namespace DLLMapRe.Entidades.XmlCustomsManifestPeru
{
    public class OaCustomsManifestPeru
    {
        public SpecifiedExchangedDocumentContext SpecifiedExchangedDocumentContext { get; set; }
    }
}
