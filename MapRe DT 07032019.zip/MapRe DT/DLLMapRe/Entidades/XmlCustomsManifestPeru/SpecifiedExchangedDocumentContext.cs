﻿namespace DLLMapRe.Entidades.XmlCustomsManifestPeru
{
    public class SpecifiedExchangedDocumentContext
    {
        public string SpecifiedTransactionId { get; set; }
    }
}
