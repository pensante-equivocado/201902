﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class TipoOperador
    {
        public Int32 IdTipoOperador { get; set; }
        public string CodTipoOperador { get; set; }
        public string Descripcion { get; set; }
    }
}
