﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class ViaTransporte
    {
        public Int32 IdViaTransporte { get; set; }
        public string CodViaTransporte { get; set; }
        public string Descripcion { get; set; }
    }
}
