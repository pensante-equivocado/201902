﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class IndUltimoEnvio
    {
        public Int32 IdIndUltimoEnvio { get; set; }
        public String CodIndUltimoEnvio { get; set; }
        public String Descripcion { get; set; }
    }
}
