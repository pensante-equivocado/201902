﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class TipoCarga
    {

        public Int32 IdTipoCarga { get; set; }
        public String CodTipoCarga{ get; set; }
        public String Descripcion { get; set; }

    }
}
