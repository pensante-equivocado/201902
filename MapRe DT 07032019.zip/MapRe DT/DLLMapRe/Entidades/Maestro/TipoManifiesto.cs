﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class TipoManifiesto
    {
        public Int32 IdTipoManifiesto { get; set; }
        public string CodTipoManifiesto { get; set; }
        public string Descripcion { get; set; }
    }
}
