﻿using System;

namespace DLLMapRe.Entidades.Maestro
{
    public class Configuracion
    {
        public Int32 IdConfiguracion { get; set; }
        public String TipoNombreArchivo { get; set; }
        public Boolean ValidaEsquema { get; set; }
        public String ClaveConfiguracion { get; set; }

    }
}
