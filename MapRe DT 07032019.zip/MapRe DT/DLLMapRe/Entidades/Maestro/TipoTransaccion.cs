﻿namespace DLLMapRe.Entidades.Maestro
{
    public class TipoTransaccion
    {
        public string CodTipoTransaccion { get; set; }
        public string Descripcion { get; set; }
        public string CodRegimen { get; set; }
    }
}
