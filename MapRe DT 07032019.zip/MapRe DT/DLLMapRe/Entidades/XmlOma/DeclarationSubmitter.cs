﻿namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationSubmitter
    {
        /// <summary>
        /// Id
        /// </summary>
        public string IdentificacionDelQueEnvia { get; set; }
        /// <summary>
        /// RoleCode
        /// </summary>
        public string TipoOperadorQueEnviaMensaje { get; set; }
    }
}
