﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationConsignmentIrm
    {
        /// <summary>
        /// SequenceNumeric
        /// </summary>
        public string NumeroDetalle { get; set; }
        public DeclarationConsignmentTransportContractDocument DeclarationConsignmentTransportContractDocument { get; set; }
    }
}
