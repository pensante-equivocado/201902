﻿using System;

namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationBorderTransportMeans
    {
        /// <summary>
        /// ModeCode
        /// </summary>
        public String ViaTransporte { get; set; }
        /// <summary>
        /// Datos de los contenedores - Cantidad Carga
        /// </summary>
        public Int32 CantidadTransportEquipment { get; set; }

        public DeclarationBorderTransportMeans()
        {
            CantidadTransportEquipment = 0;
        }
    }
}
