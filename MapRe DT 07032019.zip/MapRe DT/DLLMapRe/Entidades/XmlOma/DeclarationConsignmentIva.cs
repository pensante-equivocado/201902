﻿namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationConsignmentIva
    {
        /// <summary>
        /// SequenceNumeric
        /// </summary>
        public string NumeroDetalle { get; set; }
        /// <summary>
        /// TransportContractDocumentId
        /// </summary>
        public string NumeroDocumentoTransporte { get; set; }
        /// <summary>
        /// AdditionalInformationStatementCode
        /// </summary>
        public string CodigoTipoCarga { get; set; }
        /// <summary>
        /// ConsignmentItemCommodityProductCharacteristicsDescription
        /// </summary>
        public string VinDeVehiculo { get; set; }
        /// <summary>
        /// ConsignmentIemTransportEquipmentId
        /// </summary>
        public string NumeroDeEquipamiento { get; set; }
    }
}
