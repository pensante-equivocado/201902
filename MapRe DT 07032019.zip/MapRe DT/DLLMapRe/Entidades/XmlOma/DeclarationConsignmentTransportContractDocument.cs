﻿namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationConsignmentTransportContractDocument
    {
        /// <summary>
        /// Id
        /// </summary>
        public string NumeroDocumentoTransporte { get; set; }
    }
}
