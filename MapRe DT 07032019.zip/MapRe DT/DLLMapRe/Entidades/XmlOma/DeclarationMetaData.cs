﻿namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationMetaData
    {
        /// <summary>
        /// FunctionalDefinition
        /// </summary>
        public string NumeroTransaccion { get; set; }
        /// <summary>
        /// Solo uno
        /// </summary>
        public Declaration Declaration { get; set; }

        public DeclarationMetaData()
        {
            Declaration = new Declaration();
        }
    }
}
