﻿namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationConsignmentActaInventario
    {
        /// <summary>
        /// SequenceNumeric
        /// </summary>
        public string NumeroDetalle { get; set; }
        public DeclarationConsignmentTransportContractDocument DeclarationConsignmentTransportContractDocument { get; set; }
    }
}
