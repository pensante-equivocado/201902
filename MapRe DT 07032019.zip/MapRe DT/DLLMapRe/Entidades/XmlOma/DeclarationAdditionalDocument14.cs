﻿using System;

namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationAdditionalDocument14
    {
        /// <summary>
        /// Identifica el tipo 785, 14, etc.
        /// </summary>
        public String TypeCode { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        public String NumeroManifiestoCarga { get; set; }
    }
}
