﻿using System;

namespace DLLMapRe.Entidades.XmlOma
{
    public class DeclarationAdditionalDocument785
    {
        /// <summary>
        /// Identifica el tipo 785, 14, etc.
        /// </summary>
        public String TypeCode { get; set; }
        /// <summary>
        /// CategoryCode
        /// </summary>
        public String TipoManifiestoCarga { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        public String NumeroManifiestoCarga { get; set; }
        /// <summary>
        /// IssueDateTime
        /// </summary>
        public String AnioManifiestoCarga { get; set; }
        /// <summary>
        /// IssueLocationId
        /// </summary>
        public String CodigoAduanaManifiestoCarga { get; set; }
        
    }
}
