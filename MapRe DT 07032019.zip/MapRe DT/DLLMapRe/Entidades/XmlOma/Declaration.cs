﻿using System;
using System.Collections.Generic;

namespace DLLMapRe.Entidades.XmlOma
{
    public class Declaration
    {
        /// <summary>
        /// FunctionalReferenceID
        /// </summary>
        public string NumeroReferenciaEmisor { get; set; }
        /// <summary>
        /// Minimo 1 | Maximo 1
        /// </summary>
        public DeclarationSubmitter DeclarationSubmitter { get; set; }

        /// <summary>
        /// Minimo 1 | Maximo 1
        /// </summary>
        public DeclarationAdditionalDocument785 DeclarationAdditionalDocument785 { get; set; }

        /// <summary>
        /// Puede ser nulo | Maximo 1 ; solo aparece en IVA
        /// </summary>
        public DeclarationAdditionalDocument14 DeclarationAdditionalDocument14 { get; set; }

        /// <summary>
        /// Solo uno
        /// </summary>
        public DeclarationBorderTransportMeans DeclarationBorderTransportMeans { get; set; }
        /// <summary>
        /// Minimo 1 | Maximo ilimitado
        /// </summary>
        public List<DeclarationConsignmentActaInventario> ListaDeclarationConsignmentActaInventario { get; set; }
        public List<DeclarationConsignmentIrm> ListaDeclarationConsignmentIrm { get; set; }
        public List<DeclarationConsignmentIva> ListaDeclarationConsignmentIva { get; set; }
        /// <summary>
        /// Cantidad de items en la propiedad ListaDeclarationConsignment
        /// </summary>
        public Int32 CantidadDeclarationConsignment { get; set; }

        public Declaration()
        {
            DeclarationSubmitter = new DeclarationSubmitter();
            ListaDeclarationConsignmentActaInventario = new List<DeclarationConsignmentActaInventario>();
            ListaDeclarationConsignmentIrm = new List<DeclarationConsignmentIrm>();
            ListaDeclarationConsignmentIva = new List<DeclarationConsignmentIva>();
            DeclarationAdditionalDocument785 = new DeclarationAdditionalDocument785();
            CantidadDeclarationConsignment = 0;
        }
    }
}
