﻿namespace DLLMapRe.Entidades.Canal
{
  public  class ResultCanal
    {
        public int Clave    { get; set; }
        public string Valor { get; set; }
    }
}
