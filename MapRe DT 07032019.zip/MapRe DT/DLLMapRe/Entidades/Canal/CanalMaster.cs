﻿namespace DLLMapRe.Entidades.Canal
{
  public class CanalMaster
    {
      public string CodigoAduana     { get; set; }
      public string AnioManifiesto   { get; set; }
      public string NumeroManifiesto { get; set; }
      public string BlMaster         { get; set; }
    }
}
