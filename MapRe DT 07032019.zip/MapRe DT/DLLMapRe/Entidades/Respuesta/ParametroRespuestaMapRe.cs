﻿using System;

namespace DLLMapRe.Entidades.Respuesta
{
    public class ParametroRespuestaMapRe
    {
        public string Casilla { set; get; }
        public string PwdCasilla { set; get; }
        public string UsuarioSistema { set; get; }
        public Int32 IdUsuarioSistema { set; get; }
        public Boolean IndicadorProxy { set; get; }
        public string IpProxy { set; get; }
        public Int32 PuertoProxy { set; get; }
        public string UsuarioProxy { set; get; }
        public string PwdUsuarioProxy { set; get; }
        public string Dominio { set; get; }
        public string UrlSatServer { set; get; }
        public string UrlSatServerAlternativa { set; get; }
        public string RutaLog { set; get; }
        public string GestorBaseDatos { set; get; }

        public string DataSource { set; get; }
        public string Port { set; get; }
        public string InitialCatalog { set; get; }
        public string UserId { set; get; }
        public string Password { set; get; }

        public Boolean GuardarRespuesta { set; get; }
        public Boolean CrearJeraquiaRespuesta { set; get; }
        public Boolean RegistrarDatos { set; get; }
        public string RutaGuardarRespuesta { set; get; }
        public string RutaCustomsDeclarationPeru { set; get; }
        public string RutaReusableAggregateBusiness1 { set; get; }
        public string RutaReusableAggregateBusiness6 { set; get; }
        public Boolean TipoAmbiente { set; get; }
        public Int32 TimeOut { get; set; }
        public string NombreRespuesta { set; get; }
        public Boolean ValidaEsquema { set; get; }

        //public string Directorio { set; get; }
        //public string DirectorioError { set; get; }
        //public string DirectorioProcesados { set; get; }
    }
}
