﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace DLLMapRe.Entidades.Utilitarios
{
    public class Utilitario
    {
        public static string Desencriptar(string input)
        {
            if (String.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            const string sHeyHey = "Tç1 S.A. 2009";
            var tripleDes = new TripleDESCryptoServiceProvider();
            try
            {
                var encryptedBytes = Convert.FromBase64String(input);
                var ms = new MemoryStream();
                tripleDes.Key = TruncateHash(sHeyHey, tripleDes.KeySize / 8);
                tripleDes.IV = TruncateHash("", tripleDes.BlockSize / 8);
                var decStream = new CryptoStream(ms, tripleDes.CreateDecryptor(), CryptoStreamMode.Write);
                decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
                decStream.FlushFinalBlock();

                return Encoding.Unicode.GetString(ms.ToArray());
            }
            catch
            {
                return string.Empty;
            }
            //return null;
            //return string.Empty;
        }

        private static byte[] TruncateHash(string key, int length)
        {
            var sha1 = new SHA1CryptoServiceProvider();
            var keyBytes = Encoding.Unicode.GetBytes(key);
            var hash = sha1.ComputeHash(keyBytes);
            Array.Resize(ref hash, length);
            return hash;
        }

    }
}
