﻿using System;

namespace DLLMapRe.Entidades.EnvioRegistro
{
   public class ENRespuestaEnvio
    {
       public string NombreArchivoZIP { set; get; }
       public string NombreArchivoXML { set; get; }
       //JPT 27/11/2014
       public string NumeroOrden { set; get; }
       public Boolean Registrado { set; get; }
       public Boolean Transmitido { set; get; }
       //DICC 31/10/2014    
       public Boolean Descargado { set; get; }
    }
}
